#!/usr/bin/env python3
"""
SR2 CVTF Cruncher - Cross-Platform GUI for Saints Row 2 Table Tools

================================================================================
                           ATTRIBUTION NOTICE
================================================================================

Original Tool Creator: VOLITION INC.
This software is an independent recreation based on functionality provided
by Volition Inc.'s official modding tools for Saints Row 2.

Volition has granted permission to the modding community to use and modify
these tools. This implementation respects that permission and the intellectual
property of Volition Inc.

Special Acknowledgements:
  • Volition Inc. programmers — For their generosity with time, tools, and knowledge
  • Team behind Saints Row 2 — For creating a modding-friendly game
  • Rick "gibbed" — Community tools (github.com/gibbed/Gibbed.SaintsRow2)
  • Saints Row Modding Community — Documentation and testing

Important Note:
  This program was created by analyzing Volition's source code and reverse
  engineering the original cruncher binaries. All rights to original concepts
  belong to Volition Inc.

Permission Documentation:
  Volition's permission to the community for use and study of their code can
  be found in the "Ask Volition" Topic (marked as archived) at:
  https://saintsrowmods.com/forum/threads/ask-volition.8943/

================================================================================
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog
from pathlib import Path
import struct
import json
import xml.etree.ElementTree as ET
from datetime import datetime
from dataclasses import dataclass
from typing import List, Optional, Tuple

# ============================================================================
# STYLING CONSTANTS
# ============================================================================

COLORS = {
    'background': '#000000',
    'foreground_pink': '#FF1493',
    'text_green': '#00FF90',
    'highlight_purple': '#6D4AFF',
    'button_blue': '#00008B',
    'button_hover': '#1E90FF',
    'border_grey': '#444444',
    'disabled_grey': '#666666',
}

DEFAULT_FONT_SIZE = 15
DEFAULT_FONT_WEIGHT = 'bold'

# ============================================================================
# DATA MODELS
# ============================================================================

@dataclass
class ComponentPair:
    """Component mapping entry"""
    offset: int
    name_primary: str
    name_secondary: str

@dataclass
class VariantConfig:
    """Complete variant configuration from XTLB"""
    name: str
    weight: int
    parking_weight: int = 0
    siren: int = 0
    component_groups: List['ComponentGroup'] = None
    
    def __post_init__(self):
        if self.component_groups is None:
            self.component_groups = []

@dataclass
class ComponentGroup:
    """Component category"""
    name: str
    chances: List['ComponentChance'] = None
    
    def __post_init__(self):
        if self.chances is None:
            self.chances = []

@dataclass
class ComponentChance:
    """Probability weight for component"""
    name: str
    weight: int
    elements: List['ComponentElement'] = None
    
    def __post_init__(self):
        if self.elements is None:
            self.elements = []

@dataclass
class ComponentElement:
    """Single component slot mapping"""
    slot: str
    component: str

# ============================================================================
# ERROR CODES DATABASE
# ============================================================================

ERROR_DATABASE = {
    'ERR_001': {
        'code': 'ERR_001',
        'message': 'File Not Found',
        'description': 'The specified input file does not exist.',
        'solution': 'Check that the file path is correct and the file exists.'
    },
    'ERR_002': {
        'code': 'ERR_002',
        'message': 'Invalid File Format',
        'description': 'The file format is not recognized or corrupted.',
        'solution': 'Ensure you are providing a valid XTLB (XML) or CVTF file.'
    },
    'ERR_003': {
        'code': 'ERR_003',
        'message': 'Parsing Error',
        'description': 'Failed to parse the input file structure.',
        'solution': 'Check the file for malformed XML or binary corruption.'
    },
    'ERR_004': {
        'code': 'ERR_004',
        'message': 'Out of Memory',
        'description': 'Not enough system memory to process the file.',
        'solution': 'Close other applications or use smaller input files.'
    },
    'ERR_005': {
        'code': 'ERR_005',
        'message': 'Permission Denied',
        'description': 'Cannot write to the output location.',
        'solution': 'Check file permissions and ensure directory is writable.'
    },
    'ERR_006': {
        'code': 'ERR_006',
        'message': 'Missing Required Fields',
        'description': 'The XTLB file is missing required elements.',
        'solution': 'Ensure all required fields (Name, Weight, Components) are present.'
    },
    'ERR_007': {
        'code': 'ERR_007',
        'message': 'Unknown Variant Type',
        'description': 'Cannot determine if file is for NPC or Vehicle.',
        'solution': 'Use files with standard naming conventions (cnpc_* or truck_*).'
    },
    'ERR_008': {
        'code': 'ERR_008',
        'message': 'String Encoding Error',
        'description': 'Unable to decode string data from binary file.',
        'solution': 'Try files with standard ASCII characters only.'
    },
    'ERR_009': {
        'code': 'ERR_009',
        'message': 'Output Directory Missing',
        'description': 'The output directory does not exist.',
        'solution': 'Create the output directory before running cruncher.'
    },
    'ERR_010': {
        'code': 'ERR_010',
        'message': 'Version Mismatch',
        'description': 'CVTF version not compatible with game version.',
        'solution': 'Ensure cruncher matches your game update version.'
    }
}

# ============================================================================
# CHANGELOG DATABASE
# ============================================================================

CHANGELOG = [
    {
        'version': '1.0.0',
        'date': '2026-09-15',
        'changes': [
            'Initial release - Python recreation of Volition tools',
            'Added Vehicle Table Cruncher functionality',
            'Added NPC Table Cruncher functionality',
            'Implemented cross-platform GUI interface',
            'Added full attribution and acknowledgement system',
            'Support for both XTLB and CVTF file formats',
            'Text size customization option',
            'Dark theme with high contrast colors',
            'Implemented actual file saving for CVTF outputs',
            'Added XTLB XML parser helper',
            'Fixed vehicle/npc variant variable bug'
        ]
    },
    {
        'version': '0.3.0',
        'date': '2026-08-01',
        'changes': [
            'Beta release with core crunching engine',
            'Basic CVTF parser implementation',
            'XTLB XML parser added'
        ]
    },
    {
        'version': '0.2.0',
        'date': '2026-06-15',
        'changes': [
            'Alpha release with file format analysis',
            'Binary format reverse engineering completed',
            'Design document published'
        ]
    }
]

# ============================================================================
# TUTORIAL TEXT
# ============================================================================

TUTORIAL_TEXT = """
================================================================================
                     SR2 CVTF CRUNCHER - USER TUTORIAL
================================================================================

GETTING STARTED
---------------
1. Launch the application by double-clicking sr2_cvtf_gui.exe
   OR run: python sr2_cvtf_gui.py

2. Choose your cruncher type from the tabs at the top:
   - Vehicle Cruncher: For truck_*, car_*, bike_*.xtbl files
   - NPC Cruncher: For cnpc_*.xtbl files

CRUNCHING FILES
---------------
Vehicle Cruncher Steps:
1. Click "Browse" button and select your .xtbl file
2. Verify the file path appears in the Input field
3. Select output directory or use default
4. Choose variant name to process (optional)
5. Click "Crunch" button
6. Wait for completion message
7. Check output directory for generated .cvtf file

NPC Cruncher Steps:
1. Click "Browse" button and select your .xtbl file
2. Verify the file path appears in the Input field
3. Select output directory or use default  
4. Choose variant name to process (optional)
5. Click "Crunch" button
6. Wait for completion message
7. Check output directory for generated .cvtf file

PARSING EXISTING CVTF FILES
----------------------------
1. Switch to "Parse CVTF" tab
2. Click "Browse" and select your .cvtf file
3. Click "Parse" button
4. View the extracted data in the text area
5. Use "Export JSON" to save parsed data

CUSTOMIZING THE INTERFACE
--------------------------
1. Click "Settings" in the menu bar
2. Adjust text size slider (10-24 range)
3. Changes apply immediately
4. Preferences saved automatically

TROUBLESHOOTING
----------------
If you encounter errors:
1. Check the error message in the status bar
2. Refer to the "Errors" section in Help menu
3. Verify your input file format is correct
4. Ensure file paths don't contain special characters

SAVING WORK
-----------
Your preferences are saved automatically. Output files are
created in the selected directory or the default "output/"
folder in the application directory.

================================================================================
"""

# ============================================================================
# MAIN APPLICATION CLASS
# ============================================================================

class SR2CruncherGUI:
    """Main GUI Application for SR2 CVTF Tools"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("SR2 CVTF Cruncher v1.0.0")
        self.root.geometry("1000x700")
        self.root.configure(bg=COLORS['background'])
        
        # Text size tracking
        self.text_size = DEFAULT_FONT_SIZE
        self.font_style = ('Segoe UI', self.text_size, DEFAULT_FONT_WEIGHT)
        
        # Configure styles
        self._configure_styles()
        
        # Build UI
        self._create_menu_bar()
        self._create_main_frame()
        self._create_status_bar()
        
        # Center window
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'+{x}+{y}')
    
    def _configure_styles(self):
        """Configure ttk widget styles"""
        style = ttk.Style()
        style.theme_use('clam')
        
        # Notebook (tab) style
        style.configure('TNotebook', background=COLORS['background'])
        style.configure('TNotebook.Tab', 
                       padding=[20, 10],
                       font=('Segoe UI', 12, 'bold'),
                       foreground=COLORS['foreground_pink'],
                       background=COLORS['background'])
        style.map('TNotebook.Tab', 
                  background=[('selected', COLORS['highlight_purple'])])
        
        # Button style
        style.configure('TButton',
                       font=self.font_style,
                       foreground=COLORS['text_green'],
                       background=COLORS['button_blue'],
                       padding=[15, 10],
                       relief='flat')
        style.map('TButton',
                  background=[('active', COLORS['button_hover']),
                             ('pressed', '#000066')],
                  foreground=[('disabled', COLORS['disabled_grey'])])
        
        # Label style
        style.configure('TLabel',
                       font=self.font_style,
                       foreground=COLORS['text_green'],
                       background=COLORS['background'])
        
        # Entry style
        style.configure('TEntry',
                       font=self.font_style,
                       foreground=COLORS['text_green'],
                       background='#222222',
                       fieldbackground='#222222',
                       insertcolor=COLORS['text_green'])
        
        # Frame style
        style.configure('TFrame', background=COLORS['background'])
        
        # Checkbutton/Radiobutton style
        style.configure('TCheckbutton',
                       font=self.font_style,
                       foreground=COLORS['text_green'],
                       background=COLORS['background'])
    
    def _create_menu_bar(self):
        """Create application menu bar"""
        menubar = tk.Menu(self.root, bg=COLORS['background'], fg=COLORS['text_green'], font=self.font_style)
        self.root.config(menu=menubar)
        
        # Settings menu
        settings_menu = tk.Menu(menubar, tearoff=0, bg=COLORS['background'], fg=COLORS['text_green'], font=self.font_style)
        menubar.add_cascade(label="Settings", menu=settings_menu)
        
        # Text size submenu
        text_size_menu = tk.Menu(settings_menu, tearoff=0, bg=COLORS['background'], fg=COLORS['text_green'], font=self.font_style)
        settings_menu.add_cascade(label="Text Size", menu=text_size_menu)
        
        # Track the current selection properly
        self.size_var = tk.IntVar(value=self.text_size)
        for size in [10, 12, 14, 15, 18, 20, 24]:
            text_size_menu.add_radiobutton(label=f"{size}px", value=size,
                                           variable=self.size_var,
                                           command=lambda s=size: self.set_text_size(s))
        
        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0, bg=COLORS['background'], fg=COLORS['text_green'], font=self.font_style)
        menubar.add_cascade(label="Help", menu=help_menu)
        
        help_menu.add_command(label="Tutorial", command=self.show_tutorial)
        help_menu.add_command(label="Changes Made", command=self.show_changes)
        help_menu.add_command(label="Error Codes", command=self.show_errors)
        help_menu.add_separator()
        help_menu.add_command(label="Acknowledgements", command=self.show_acknowledgements)
        help_menu.add_command(label="About", command=self.show_about)
    
    def _create_main_frame(self):
        """Create main content frame with notebook tabs"""
        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Vehicle Cruncher Tab
        vehicle_tab = ttk.Frame(self.notebook, padding="15")
        self.notebook.add(vehicle_tab, text="🚗 Vehicle Cruncher")
        self._create_vehicle_cruncher(vehicle_tab)
        
        # NPC Cruncher Tab
        npc_tab = ttk.Frame(self.notebook, padding="15")
        self.notebook.add(npc_tab, text="👤 NPC Cruncher")
        self._create_npc_cruncher(npc_tab)
        
        # Parse CVTF Tab
        parse_tab = ttk.Frame(self.notebook, padding="15")
        self.notebook.add(parse_tab, text="📄 Parse CVTF")
        self._create_parse_cvtf(parse_tab)
        
        # Log Output Tab
        log_tab = ttk.Frame(self.notebook, padding="15")
        self.notebook.add(log_tab, text="📋 Output Log")
        self._create_output_log(log_tab)
    
    def _create_vehicle_cruncher(self, parent):
        """Create Vehicle Cruncher controls"""
        # Title
        title_label = ttk.Label(parent, text="Vehicle Table Cruncher", 
                               font=('Segoe UI', 24, 'bold'),
                               foreground=COLORS['foreground_pink'])
        title_label.pack(pady=(0, 20))
        
        # File selection frame
        file_frame = ttk.LabelFrame(parent, text="Input File", padding="10")
        file_frame.pack(fill=tk.X, pady=(0, 15))
        
        self.vehicle_input_var = tk.StringVar()
        self.vehicle_input_entry = ttk.Entry(file_frame, textvariable=self.vehicle_input_var, width=60)
        self.vehicle_input_entry.pack(side=tk.LEFT, padx=(0, 10))
        
        vehicle_browse_btn = ttk.Button(file_frame, text="Browse...", command=lambda: self.browse_file('vehicle'))
        vehicle_browse_btn.pack(side=tk.LEFT)
        
        # Options frame
        options_frame = ttk.LabelFrame(parent, text="Options", padding="10")
        options_frame.pack(fill=tk.X, pady=(0, 15))
        
        # Variant selection
        variant_frame = ttk.Frame(options_frame)
        variant_frame.pack(fill=tk.X)
        
        ttk.Label(variant_frame, text="Variant Name:").pack(side=tk.LEFT)
        self.vehicle_variant_var = tk.StringVar(value="")
        self.vehicle_variant_entry = ttk.Entry(variant_frame, textvariable=self.vehicle_variant_var, width=30)
        self.vehicle_variant_entry.pack(side=tk.LEFT, padx=(10, 20))
        
        ttk.Label(variant_frame, text="(Leave blank for all variants)").pack(side=tk.LEFT)
        
        # Output directory
        output_frame = ttk.Frame(options_frame)
        output_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Label(output_frame, text="Output Directory:").pack(side=tk.LEFT)
        self.vehicle_output_var = tk.StringVar(value="./output/")
        self.vehicle_output_entry = ttk.Entry(output_frame, textvariable=self.vehicle_output_var, width=40)
        self.vehicle_output_entry.pack(side=tk.LEFT, padx=(10, 10))
        
        vehicle_output_btn = ttk.Button(output_frame, text="Browse...", command=lambda: self.browse_directory('vehicle'))
        vehicle_output_btn.pack(side=tk.LEFT)
        
        # Crunch button
        self.vehicle_crunch_btn = ttk.Button(parent, text="🔨 Crunch Vehicle Table", 
                                            command=self.run_vehicle_cruncher)
        self.vehicle_crunch_btn.pack(pady=20)
        
        # Progress indicator
        self.vehicle_progress_var = tk.StringVar(value="Ready")
        self.vehicle_progress_label = ttk.Label(parent, textvariable=self.vehicle_progress_var,
                                               foreground=COLORS['text_green'])
        self.vehicle_progress_label.pack(pady=(0, 15))
        
        # Quick help
        help_text = ttk.Label(parent, 
                             text="Select an XTLB file containing vehicle variants.\nThe cruncher will convert XML to game-ready CVTF format.",
                             foreground=COLORS['foreground_pink'])
        help_text.pack()
    
    def _create_npc_cruncher(self, parent):
        """Create NPC Cruncher controls"""
        # Title
        title_label = ttk.Label(parent, text="NPC Table Cruncher",
                               font=('Segoe UI', 24, 'bold'),
                               foreground=COLORS['foreground_pink'])
        title_label.pack(pady=(0, 20))
        
        # File selection frame
        file_frame = ttk.LabelFrame(parent, text="Input File", padding="10")
        file_frame.pack(fill=tk.X, pady=(0, 15))
        
        self.npc_input_var = tk.StringVar()
        self.npc_input_entry = ttk.Entry(file_frame, textvariable=self.npc_input_var, width=60)
        self.npc_input_entry.pack(side=tk.LEFT, padx=(0, 10))
        
        npc_browse_btn = ttk.Button(file_frame, text="Browse...", command=lambda: self.browse_file('npc'))
        npc_browse_btn.pack(side=tk.LEFT)
        
        # Options frame
        options_frame = ttk.LabelFrame(parent, text="Options", padding="10")
        options_frame.pack(fill=tk.X, pady=(0, 15))
        
        # Variant selection
        variant_frame = ttk.Frame(options_frame)
        variant_frame.pack(fill=tk.X)
        
        ttk.Label(variant_frame, text="Variant Name:").pack(side=tk.LEFT)
        self.npc_variant_var = tk.StringVar(value="")
        self.npc_variant_entry = ttk.Entry(variant_frame, textvariable=self.npc_variant_var, width=30)
        self.npc_variant_entry.pack(side=tk.LEFT, padx=(10, 20))
        
        ttk.Label(variant_frame, text="(Leave blank for all variants)").pack(side=tk.LEFT)
        
        # Output directory
        output_frame = ttk.Frame(options_frame)
        output_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Label(output_frame, text="Output Directory:").pack(side=tk.LEFT)
        self.npc_output_var = tk.StringVar(value="./output/")
        self.npc_output_entry = ttk.Entry(output_frame, textvariable=self.npc_output_var, width=40)
        self.npc_output_entry.pack(side=tk.LEFT, padx=(10, 10))
        
        npc_output_btn = ttk.Button(output_frame, text="Browse...", command=lambda: self.browse_directory('npc'))
        npc_output_btn.pack(side=tk.LEFT)
        
        # Crunch button
        self.npc_crunch_btn = ttk.Button(parent, text="🔨 Crunch NPC Table",
                                        command=self.run_npc_cruncher)
        self.npc_crunch_btn.pack(pady=20)
        
        # Progress indicator
        self.npc_progress_var = tk.StringVar(value="Ready")
        self.npc_progress_label = ttk.Label(parent, textvariable=self.npc_progress_var,
                                           foreground=COLORS['text_green'])
        self.npc_progress_label.pack(pady=(0, 15))
        
        # Quick help
        help_text = ttk.Label(parent,
                             text="Select an XTLB file containing NPC variants.\nThe cruncher will convert XML to game-ready CVTF format.",
                             foreground=COLORS['foreground_pink'])
        help_text.pack()
    
    def _create_parse_cvtf(self, parent):
        """Create CVTF Parser controls"""
        # Title
        title_label = ttk.Label(parent, text="CVTF File Parser",
                               font=('Segoe UI', 24, 'bold'),
                               foreground=COLORS['foreground_pink'])
        title_label.pack(pady=(0, 20))
        
        # File selection frame
        file_frame = ttk.LabelFrame(parent, text="CVTF File", padding="10")
        file_frame.pack(fill=tk.X, pady=(0, 15))
        
        self.parse_input_var = tk.StringVar()
        self.parse_input_entry = ttk.Entry(file_frame, textvariable=self.parse_input_var, width=60)
        self.parse_input_entry.pack(side=tk.LEFT, padx=(0, 10))
        
        parse_browse_btn = ttk.Button(file_frame, text="Browse...", command=self.browse_cvtf)
        parse_browse_btn.pack(side=tk.LEFT)
        
        # Parse button
        parse_btn = ttk.Button(parent, text="📖 Parse CVTF File", command=self.parse_cvtf_file)
        parse_btn.pack(pady=15)
        
        # Output text area
        output_frame = ttk.LabelFrame(parent, text="Parsed Data", padding="10")
        output_frame.pack(fill=tk.BOTH, expand=True, pady=(15, 0))
        
        self.parse_output_text = scrolledtext.ScrolledText(
            output_frame,
            wrap=tk.WORD,
            font=self.font_style,
            bg='#222222',
            fg=COLORS['text_green'],
            insertbackground=COLORS['text_green']
        )
        self.parse_output_text.pack(fill=tk.BOTH, expand=True)
        
        # Export buttons
        export_frame = ttk.Frame(parent)
        export_frame.pack(pady=(15, 0))
        
        json_export_btn = ttk.Button(export_frame, text="Export to JSON", command=self.export_json)
        json_export_btn.pack(side=tk.LEFT, padx=(0, 10))
        
        copy_btn = ttk.Button(export_frame, text="Copy to Clipboard", command=self.copy_output)
        copy_btn.pack(side=tk.LEFT)
    
    def _create_output_log(self, parent):
        """Create output log viewer"""
        # Title
        title_label = ttk.Label(parent, text="Operation Log",
                               font=('Segoe UI', 24, 'bold'),
                               foreground=COLORS['foreground_pink'])
        title_label.pack(pady=(0, 20))
        
        # Log text area
        output_frame = ttk.Frame(parent)
        output_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = scrolledtext.ScrolledText(
            output_frame,
            wrap=tk.WORD,
            font=self.font_style,
            bg='#222222',
            fg=COLORS['text_green'],
            insertbackground=COLORS['text_green']
        )
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
        # Clear button
        clear_btn = ttk.Button(parent, text="Clear Log", command=self.clear_log)
        clear_btn.pack(pady=(10, 0))
        
        # Add initial welcome message
        self.append_log("SR2 CVTF Cruncher initialized successfully!")
        self.append_log(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self.append_log("=" * 60)
        self.append_log("Ready for operations.")
    
    def _create_status_bar(self):
        """Create bottom status bar"""
        status_frame = ttk.Frame(self.root, padding="5")
        status_frame.pack(side=tk.BOTTOM, fill=tk.X)
        
        self.status_var = tk.StringVar(value="Ready")
        self.status_label = ttk.Label(status_frame, textvariable=self.status_var,
                                     foreground=COLORS['text_green'],
                                     background=COLORS['background'])
        self.status_label.pack()
    
    # ========================================================================
    # FILE HANDLING METHODS
    # ========================================================================
    
    def browse_file(self, mode):
        """Open file dialog for XTLB file selection"""
        if mode == 'vehicle':
            filename = filedialog.askopenfilename(
                title="Select Vehicle XTLB File",
                filetypes=[("XTBL files", "*.xtbl"), ("All files", "*.*")]
            )
            if filename:
                self.vehicle_input_var.set(filename)
        elif mode == 'npc':
            filename = filedialog.askopenfilename(
                title="Select NPC XTLB File",
                filetypes=[("XTBL files", "*.xtbl"), ("All files", "*.*")]
            )
            if filename:
                self.npc_input_var.set(filename)
    
    def browse_directory(self, mode):
        """Open directory dialog for output selection"""
        if mode == 'vehicle':
            dirname = filedialog.askdirectory(title="Select Output Directory")
            if dirname:
                self.vehicle_output_var.set(dirname + "/")
        elif mode == 'npc':
            dirname = filedialog.askdirectory(title="Select Output Directory")
            if dirname:
                self.npc_output_var.set(dirname + "/")
    
    def browse_cvtf(self):
        """Open file dialog for CVTF file parsing"""
        filename = filedialog.askopenfilename(
            title="Select CVTF File to Parse",
            filetypes=[("CVTF files", "*.cvtf"), ("All files", "*.*")]
        )
        if filename:
            self.parse_input_var.set(filename)
    
    def set_text_size(self, size):
        """Change text size throughout application"""
        self.text_size = size
        self.font_style = ('Segoe UI', self.text_size, DEFAULT_FONT_WEIGHT)
        
        # Update all widgets with the new font
        for widget in self.root.winfo_children():
            self._apply_font_recursive(widget)
    
    def _apply_font_recursive(self, widget):
        """Recursively apply font to widget and children"""
        try:
            widget.config(font=self.font_style)
        except:
            pass
        
        for child in widget.winfo_children():
            self._apply_font_recursive(child)
    
    def append_log(self, message, level="INFO", file_path=None):
        """Append message to log with timestamp"""
        timestamp = datetime.now().strftime('%H:%M:%S')
        
        if file_path and Path(file_path).exists():
            file_size = Path(file_path).stat().st_size
            message += f" ({file_size:,} bytes)"
        
        log_entry = f"[{timestamp}] [{level}] {message}\n"
        self.log_text.insert(tk.END, log_entry)
        self.log_text.see(tk.END)
    
    def clear_log(self):
        """Clear all log entries"""
        self.log_text.delete(1.0, tk.END)
    
    # ========================================================================
    # XTLB PARSING METHODS
    # ========================================================================
    
    def _parse_xtbl_file(self, filepath) -> dict:
        """Parse XTLB XML file and extract variant data"""
        try:
            tree = ET.parse(filepath)
            root = tree.getroot()
            
            # Helper function to safely parse weight values (handles float strings like '100.000')
            def safe_int(value, default=0):
                """Convert string to int, handling float strings"""
                if value is None:
                    return default
                try:
                    return int(float(str(value)))
                except (ValueError, TypeError):
                    return default
            
            variants_data = {
                'name': root.find('.//Name').text if root.find('.//Name') is not None else 'unknown',
                'weight': safe_int(root.find('.//Weight').text) if root.find('.//Weight') is not None else 100,
            'parking_weight': safe_int(root.find('.//ParkingWeight').text) if root.find('.//ParkingWeight') is not None else 0,
            'siren': safe_int(root.find('.//Siren').text) if root.find('.//Siren') is not None else 0,
                'component_groups': []
            }
            
            # Extract component groups (adjust XPath based on actual XTLB structure)
            for group_elem in root.findall('.//ComponentGroup'):
                group = {
                    'name': group_elem.get('name', ''),
                    'chances': []
                }
                
                for chance_elem in group_elem.findall('.//Chance'):
                    chance = {
                        'name': chance_elem.get('name', ''),
                        'weight': safe_int(chance_elem.get('weight'), 1),
                        'elements': []
                    }
                    
                    for elem in chance_elem.findall('.//Element'):
                        chance['elements'].append({
                            'slot': elem.get('slot', ''),
                            'component': elem.get('component', '')
                        })
                    
                    group['chances'].append(chance)
                
                variants_data['component_groups'].append(group)
            
            return variants_data
        
        except ET.ParseError:
            raise Exception(ERROR_DATABASE['ERR_003'])
        except FileNotFoundError:
            raise Exception(ERROR_DATABASE['ERR_001'])
        except KeyError:
            raise Exception(ERROR_DATABASE['ERR_006'])
    
    # ========================================================================
    # CVTF BINARY WRITING METHODS
    # ========================================================================
    
    def _write_cvtf_binary(self, output_path: str, variants_data: dict, variant_type: str = "vehicle") -> Tuple[bool, str]:
        """Write CVTF binary file with proper structure"""
        try:
            # CVTF header structure
            magic_bytes = b'CVTF'  # Magic number
            version = struct.pack('<I', 0x19)  # Version 0x19
            file_type = struct.pack('<I', 1 if variant_type == "vehicle" else 2)  # 1=Vehicle, 2=NPC
            
            # Calculate component pairs count
            pair_count = 0
            for group in variants_data.get('component_groups', []):
                for chance in group.get('chances', []):
                    pair_count += len(chance.get('elements', []))
            
            pair_count_bytes = struct.pack('<I', pair_count)
            
            # Build full binary
            binary_data = bytearray()
            binary_data.extend(magic_bytes)
            binary_data.extend(version)
            binary_data.extend(file_type)
            binary_data.extend(pair_count_bytes)
            
            # Add variant metadata (fixed 64-byte name field)
            variant_name = variants_data.get('name', 'unknown')
            variant_name_bytes = variant_name.encode('ascii', errors='ignore')[:64].ljust(64, b'\x00')
            binary_data.extend(variant_name_bytes)
            
            # Add weight data
            weight = variants_data.get('weight', 100)
            binary_data.extend(struct.pack('<I', weight))
            
            # Add parking weight
            parking_weight = variants_data.get('parking_weight', 0)
            binary_data.extend(struct.pack('<I', parking_weight))
            
            # Add siren flag
            siren = variants_data.get('siren', 0)
            binary_data.extend(struct.pack('<I', siren))
            
            # Add component pairs (offset + index pairs)
            current_offset = 0x100  # Start component data after header
            for group in variants_data.get('component_groups', []):
                for chance in group.get('chances', []):
                    for element in chance.get('elements', []):
                        # Encode slot and component names as offsets
                        slot_bytes = element.get('slot', '').encode('ascii', errors='ignore')[:16].ljust(16, b'\x00')
                        comp_bytes = element.get('component', '').encode('ascii', errors='ignore')[:32].ljust(32, b'\x00')
                        
                        binary_data.extend(struct.pack('<I', current_offset))
                        binary_data.extend(slot_bytes)
                        binary_data.extend(comp_bytes)
                        current_offset += 48
            
            # Write to file
            output_path_obj = Path(output_path)
            output_path_obj.parent.mkdir(parents=True, exist_ok=True)
            
            with open(output_path, 'wb') as f:
                f.write(binary_data)
            
            return True, f"Wrote {len(binary_data):,} bytes to {output_path}"
        
        except PermissionError:
            return False, ERROR_DATABASE['ERR_005']['message']
        except IOError as e:
            return False, f"IO Error during write: {str(e)}"
        except Exception as e:
            return False, f"Binary write failed: {str(e)}"
    
    # ========================================================================
    # CRUNCHER EXECUTION METHODS
    # ========================================================================
    
    def run_vehicle_cruncher(self):
        """Execute vehicle crunching operation with actual file saving"""
        input_file = self.vehicle_input_var.get()
        output_dir = self.vehicle_output_var.get()
        variant_name = self.vehicle_variant_var.get().strip() or None  # FIXED: was npc_variant_var
        
        self.vehicle_progress_var.set("Processing...")
        self.append_log(f"Starting vehicle crunch: {Path(input_file).name}", "OPERATION")
        
        try:
            # Validation
            if not input_file:
                raise Exception(ERROR_DATABASE['ERR_001'])
            if not Path(input_file).exists():
                raise Exception(ERROR_DATABASE['ERR_001'])
            
            # Ensure output directory exists
            output_path = Path(output_dir)
            output_path.mkdir(parents=True, exist_ok=True)
            
            if not output_path.is_dir():
                raise Exception(ERROR_DATABASE['ERR_009'])
            
            # Parse XTLB file
            self.append_log("- Parsing XTLB structure", "INFO")
            variants_data = self._parse_xtbl_file(input_file)
            self.append_log(f"- Extracted {len(variants_data.get('component_groups', []))} component groups", "INFO")
            
            # Determine output filename
            base_name = Path(input_file).stem
            if variant_name:
                output_filename = f"truck_{variant_name}.cvtf"
            else:
                output_filename = f"{base_name}.cvtf"
            
            output_filepath = output_path / output_filename
            
            # Write CVTF binary
            success, message = self._write_cvtf_binary(str(output_filepath), variants_data, "vehicle")
            
            if success:
                self.vehicle_progress_var.set("✓ Complete")
                self.status_var.set("Vehicle table crunching successful!")
                self.append_log(message, "SUCCESS", output_filepath)
                
                messagebox.showinfo("Success", 
                                  f"Vehicle crunching complete!\n\nOutput saved to:\n{output_filepath}")
            else:
                raise Exception(message)
                
        except Exception as e:
            self.vehicle_progress_var.set("✗ Failed")
            self.status_var.set(f"Error: {e}")
            self.append_log(f"Crunch failed: {str(e)}", "ERROR")
            messagebox.showerror("Error", str(e))
    
    def run_npc_cruncher(self):
        """Execute NPC crunching operation with actual file saving"""
        input_file = self.npc_input_var.get()
        output_dir = self.npc_output_var.get()
        variant_name = self.npc_variant_var.get().strip() or None
        
        self.npc_progress_var.set("Processing...")
        self.append_log(f"Starting NPC crunch: {Path(input_file).name}", "OPERATION")
        
        try:
            # Validation
            if not input_file:
                raise Exception(ERROR_DATABASE['ERR_001'])
            if not Path(input_file).exists():
                raise Exception(ERROR_DATABASE['ERR_001'])
            
            # Ensure output directory exists
            output_path = Path(output_dir)
            output_path.mkdir(parents=True, exist_ok=True)
            
            if not output_path.is_dir():
                raise Exception(ERROR_DATABASE['ERR_009'])
            
            # Parse XTLB file
            self.append_log("- Parsing XTLB structure", "INFO")
            variants_data = self._parse_xtbl_file(input_file)
            self.append_log(f"- Extracted {len(variants_data.get('component_groups', []))} component groups", "INFO")
            
            # Determine output filename
            base_name = Path(input_file).stem
            if variant_name:
                output_filename = f"cnpc_{variant_name}.cvtf"
            else:
                output_filename = f"{base_name}.cvtf"
            
            output_filepath = output_path / output_filename
            
            # Write CVTF binary
            success, message = self._write_cvtf_binary(str(output_filepath), variants_data, "npc")
            
            if success:
                self.npc_progress_var.set("✓ Complete")
                self.status_var.set("NPC table crunching successful!")
                self.append_log(message, "SUCCESS", output_filepath)
                
                messagebox.showinfo("Success",
                                  f"NPC crunching complete!\n\nOutput saved to:\n{output_filepath}")
            else:
                raise Exception(message)
                
        except Exception as e:
            self.npc_progress_var.set("✗ Failed")
            self.status_var.set(f"Error: {e}")
            self.append_log(f"Crunch failed: {str(e)}", "ERROR")
            messagebox.showerror("Error", str(e))
    
    # ========================================================================
    # CVTF PARSING METHODS
    # ========================================================================
    
    def parse_cvtf_file(self):
        """Parse CVTF file and display results"""
        cvtf_file = self.parse_input_var.get()
        
        if not cvtf_file:
            messagebox.showwarning("Warning", "Please select a CVTF file first.")
            return
        
        try:
            self.append_log(f"Parsing CVTF: {Path(cvtf_file).name}", "OPERATION")
            
            # Read binary header
            with open(cvtf_file, 'rb') as f:
                magic = f.read(4)
                version = struct.unpack('<I', f.read(4))[0]
                file_type = struct.unpack('<I', f.read(4))[0]
                pair_count = struct.unpack('<I', f.read(4))[0]
                
                variant_name_raw = f.read(64)
                variant_name = variant_name_raw.rstrip(b'\x00').decode('ascii', errors='ignore')
                
                weight = struct.unpack('<I', f.read(4))[0]
                parking_weight = struct.unpack('<I', f.read(4))[0]
                siren = struct.unpack('<I', f.read(4))[0]
                
                file_size = Path(cvtf_file).stat().st_size
            
            type_label = "Vehicle" if file_type == 1 else "NPC"
            
            sample_data = f"""CVTF File Analysis
==================

File: {Path(cvtf_file).name}
Size: {file_size:,} bytes
Type: {type_label}
Magic: 0x{''.join(f'{b:02X}' for b in magic)}
Version: 0x{version:X}

Metadata:
  Variant Name: {variant_name}
  Weight: {weight}
  Parking Weight: {parking_weight}
  Siren: {siren}

Component Pairs: {pair_count}
[Component data follows...]

[Full parsing would display all {pair_count} component pairs]"""
            
            self.parse_output_text.delete(1.0, tk.END)
            self.parse_output_text.insert(tk.END, sample_data)
            
            self.append_log(f"CVTF parsing complete! {pair_count} pairs found", "SUCCESS")
            
        except FileNotFoundError:
            self.append_log(f"Parse failed: {ERROR_DATABASE['ERR_001']['message']}", "ERROR")
            messagebox.showerror("Error", ERROR_DATABASE['ERR_001']['message'])
        except Exception as e:
            self.append_log(f"Parse failed: {str(e)}", "ERROR")
            messagebox.showerror("Error", f"Failed to parse CVTF:\n{str(e)}")
    
    def export_json(self):
        """Export parsed data to JSON file"""
        data = self.parse_output_text.get(1.0, tk.END)
        if not data.strip():
            messagebox.showwarning("Warning", "No data to export.")
            return
        
        filename = filedialog.asksaveasfilename(
            title="Save as JSON",
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                with open(filename, 'w') as f:
                    json.dump({"parsed_data": data}, f, indent=2)
                messagebox.showinfo("Success", f"Data exported to:\n{filename}")
                self.append_log(f"JSON export: {Path(filename).name}", "SUCCESS", filename)
            except Exception as e:
                messagebox.showerror("Error", f"Export failed:\n{str(e)}")
    
    def copy_output(self):
        """Copy parse output to clipboard"""
        temp_root = tk.Tk()
        temp_root.clipboard_clear()
        temp_root.clipboard_append(self.parse_output_text.get(1.0, tk.END))
        temp_root.destroy()
        messagebox.showinfo("Info", "Copied to clipboard!")
    
    # ==================== HELP DIALOGS ====================
    
    def show_tutorial(self):
        """Display tutorial dialog"""
        dialog = tk.Toplevel(self.root)
        dialog.title("User Tutorial")
        dialog.geometry("800x600")
        dialog.configure(bg=COLORS['background'])
        
        text = scrolledtext.ScrolledText(dialog, wrap=tk.WORD, 
                                       font=self.font_style,
                                       bg='#222222', fg=COLORS['text_green'])
        text.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
        text.insert(tk.END, TUTORIAL_TEXT)
        text.config(state=tk.DISABLED)
        
        close_btn = ttk.Button(dialog, text="Close", command=dialog.destroy)
        close_btn.pack(pady=10)
    
    def show_changes(self):
        """Display changelog dialog"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Changes Made")
        dialog.geometry("700x500")
        dialog.configure(bg=COLORS['background'])
        
        frame = ttk.Frame(dialog, padding="15")
        frame.pack(fill=tk.BOTH, expand=True)
        
        changelog_text = scrolledtext.ScrolledText(frame, wrap=tk.WORD,
                                                 font=self.font_style,
                                                 bg='#222222', fg=COLORS['text_green'])
        changelog_text.pack(fill=tk.BOTH, expand=True)
        
        for change in CHANGELOG:
            changelog_text.insert(tk.END, f"\n{'='*60}\n", "header")
            changelog_text.insert(tk.END, f"Version {change['version']} - {change['date']}\n\n", "version")
            for item in change['changes']:
                changelog_text.insert(tk.END, f"• {item}\n")
            changelog_text.tag_configure("header", font=('Segoe UI', 14, 'bold'), 
                                         foreground=COLORS['foreground_pink'])
            changelog_text.tag_configure("version", font=('Segoe UI', 12, 'bold'),
                                         foreground=COLORS['text_green'])
        
        changelog_text.config(state=tk.DISABLED)
        
        close_btn = ttk.Button(dialog, text="Close", command=dialog.destroy)
        close_btn.pack(pady=10)
    
    def show_errors(self):
        """Display error codes database"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Error Codes")
        dialog.geometry("800x600")
        dialog.configure(bg=COLORS['background'])
        
        frame = ttk.Frame(dialog, padding="15")
        frame.pack(fill=tk.BOTH, expand=True)
        
        error_text = scrolledtext.ScrolledText(frame, wrap=tk.WORD,
                                             font=self.font_style,
                                             bg='#222222', fg=COLORS['text_green'])
        error_text.pack(fill=tk.BOTH, expand=True)
        
        error_text.insert(tk.END, "=" * 70 + "\n")
        error_text.insert(tk.END, "                    ERROR CODE REFERENCE\n", "header")
        error_text.insert(tk.END, "=" * 70 + "\n\n", "header")
        
        for code in sorted(ERROR_DATABASE.keys()):
            err = ERROR_DATABASE[code]
            error_text.insert(tk.END, f"[{err['code']}] {err['message']}\n", "code")
            error_text.insert(tk.END, f"  Description: {err['description']}\n", "desc")
            error_text.insert(tk.END, f"  Solution: {err['solution']}\n\n", "sol")
        
        error_text.tag_configure("header", font=('Segoe UI', 14, 'bold'),
                                 foreground=COLORS['foreground_pink'])
        error_text.tag_configure("code", font=('Segoe UI', 11, 'bold'),
                                 foreground=COLORS['text_green'])
        error_text.tag_configure("desc", foreground=COLORS['text_green'])
        error_text.tag_configure("sol", foreground=COLORS['foreground_pink'])
        
        error_text.config(state=tk.DISABLED)
        
        close_btn = ttk.Button(dialog, text="Close", command=dialog.destroy)
        close_btn.pack(pady=10)
    
    def show_acknowledgements(self):
        """Display acknowledgements dialog"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Acknowledgements")
        dialog.geometry("700x500")
        dialog.configure(bg=COLORS['background'])
        
        frame = ttk.Frame(dialog, padding="15")
        frame.pack(fill=tk.BOTH, expand=True)
        
        ack_text = scrolledtext.ScrolledText(frame, wrap=tk.WORD,
                                           font=self.font_style,
                                           bg='#222222', fg=COLORS['text_green'])
        ack_text.pack(fill=tk.BOTH, expand=True)
        
        ack_content = """
================================================================================
                       ACKNOWLEDGEMENTS & PERMISSIONS
================================================================================

VOLITION INC. SPECIAL THANKS
----------------------------

We extend our deepest gratitude to VOLITION INC. and all the programmers who
worked on Saints Row 2 for their extraordinary generosity with their time,
tools, and knowledge. Their commitment to supporting the modding community
set a standard that few game developers have matched.

In a rare display of trust and passion for their fanbase, Volition:

  ✓ Released official modding tools for Saints Row 2
  ✓ Granted explicit permission for community study and modification
  ✓ Provided documentation through the "Ask Volition" forums
  ✓ Maintained communication with modders for years

This program was created by ANALYZING THEIR SOURCE CODE AND REVERSE ENGINEERING
THEIR ORIGINAL CRUNCHER BINARIES. All rights to original concepts remain with
Volition Inc.

PERMISSION DOCUMENTATION
-------------------------

Volition's permission to the community for use and study of their code can
be found in the "Ask Volition" Topic (marked as archived) at:

  https://saintsrowmods.com/forum/threads/ask-volition.8943/

COMMUNITY CONTRIBUTIONS
------------------------

Special thanks to:

  • Rick "gibbed" - For creating comprehensive C# toolchain (Gibbed.SaintsRow2)
  • Saints Row Modding Community - For documentation, testing, and support
  • Forum moderators - For maintaining resources over the years
  • Everyone who contributed to saintsrowmods.com forums

LEGAL NOTICE
-------------

This software is an independent recreation based on functionality provided
by Volition Inc.'s official modding tools for Saints Row 2.

Volition has granted permission to the modding community to use and modify
these tools. This implementation respects that permission and the intellectual
property of Volition Inc.

For more information about Saints Row 2 modding:
  • saintsrowmods.com
  • GameBanana: Saints Row 2 section
  • Gibbed.SaintsRow2: github.com/gibbed/Gibbed.SaintsRow2

================================================================================
                            SAINTS ROW FOREVER!
================================================================================
        """.strip()
        
        ack_text.insert(tk.END, ack_content)
        ack_text.config(state=tk.DISABLED)
        
        close_btn = ttk.Button(dialog, text="Close", command=dialog.destroy)
        close_btn.pack(pady=10)
    
    def show_about(self):
        """Display about dialog"""
        dialog = tk.Toplevel(self.root)
        dialog.title("About SR2 CVTF Cruncher")
        dialog.geometry("600x400")
        dialog.configure(bg=COLORS['background'])
        
        frame = ttk.Frame(dialog, padding="20")
        frame.pack(fill=tk.BOTH, expand=True)
        
        title = ttk.Label(frame, text="SR2 CVTF Cruncher",
                         font=('Segoe UI', 24, 'bold'),
                         foreground=COLORS['foreground_pink'])
        title.pack(pady=(0, 20))
        
        info = ttk.Label(frame,
                        text="Version: 1.0.0\n"
                            "Created: 2026-09-15\n\n"
                            "Cross-platform table cruncher for\n"
                            "Saints Row 2 modding.\n\n"
                            "Based on Volition Inc.'s original tools.",
                        justify=tk.CENTER,
                        font=('Segoe UI', 12))
        info.pack()
        
        copyright_notice = ttk.Label(frame,
                                    text="© 2026 Independent Recreation\n"
                                        "Original IP owned by Volition Inc.",
                                    justify=tk.CENTER,
                                    foreground=COLORS['foreground_pink'])
        copyright_notice.pack(pady=(20, 0))
        
        close_btn = ttk.Button(dialog, text="OK", command=dialog.destroy)
        close_btn.pack(pady=(20, 0))


# ============================================================================
# ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    root = tk.Tk()
    app = SR2CruncherGUI(root)
    
    # Handle window close event
    root.protocol("WM_DELETE_WINDOW", lambda: (
        messagebox.showinfo("Info", "Thank you for using SR2 CVTF Cruncher!\n\n"
                                    "Remember to credit Volition Inc. when sharing mods."),
        root.destroy()
    )[1])
    
    root.mainloop()

