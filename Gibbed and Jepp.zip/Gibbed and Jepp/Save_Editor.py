"""
Saints Row 2 Save Editor
Python 3.10 Port with Custom Dark Theme

Colors:
- Background: #000000 (Black)
- Foreground: #00FF90 (Bright Green)
- Buttons/Highlights: Dark Purple (#4B0082)
- Text Size: 15px
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import sys

from Sr2_Helpers import (
    SaveFileHandler, 
    SR2SaveError, 
    HelpData, 
    get_error_message
)


class StyledFrame(ttk.Frame):
    """Reusable frame with consistent styling."""
    
    def __init__(self, container, **kwargs):
        super().__init__(container, **kwargs)
        self.configure(style="Dark.TFrame")


class SR2SaveEditor:
    """Main application class."""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Saints Row 2 Save Editor")
        self.root.geometry("500x600")
        self.root.minsize(450, 550)
        
        self.handler = SaveFileHandler()
        self.current_values = {}
        
        self._setup_styles()
        self._create_widgets()
        self._create_menu()
        
    def _setup_styles(self):
        """Configure tkinter styles for dark theme."""
        style = ttk.Style()
        
        # Configure base colors
        bg_color = "#000000"
        fg_color = "#00FF90"
        highlight_bg = "#4B0082"  # Dark purple
        highlight_fg = "#FFFFFF"
        
        # Root window
        self.root.configure(bg=bg_color)
        
        # Frames
        style.configure("Dark.TFrame", background=bg_color)
        style.configure("Dark.TLabel", background=bg_color, foreground=fg_color, font=("Consolas", 15))
        style.configure("Title.TLabel", background=bg_color, foreground=fg_color, 
                       font=("Consolas", 18, "bold"))
        style.configure("Section.TLabel", background=bg_color, foreground=fg_color,
                       font=("Consolas", 14, "bold"))
        style.configure("Small.TLabel", background=bg_color, foreground=fg_color,
                       font=("Consolas", 11))
        
        # Buttons
        style.configure("Action.TButton", 
                       background=highlight_bg, 
                       foreground=highlight_fg,
                       font=("Consolas", 15, "bold"),
                       padding=(20, 10))
        style.map("Action.TButton",
                 background=[("active", "#6A0DAD"), ("pressed", "#3D0066")])
        
        # Spinboxes
        style.configure("Dark.TSpinbox",
                       fieldbackground="#1A1A1A",
                       background=highlight_bg,
                       foreground=fg_color,
                       arrowcolor=fg_color)
        
        # Entry widgets
        style.configure("Dark.TEntry",
                       fieldbackground="#1A1A1A",
                       foreground=fg_color)
        
        # Scrollbars
        style.configure("Dark.TScrollbar",
                       background=highlight_bg,
                       troughcolor=bg_color)
        
        # Menus
        style.configure("Dark.TMenubutton",
                       background=bg_color,
                       foreground=fg_color,
                       font=("Consolas", 14))
        
    def _create_menu(self):
        """Create menubar with help options."""
        menubar = tk.Menu(self.root, bg="#000000", fg="#00FF90", 
                         font=("Consolas", 13), tearoff=0)
        
        # File menu
        file_menu = tk.Menu(menubar, bg="#1A1A1A", fg="#00FF90", tearoff=0)
        file_menu.add_command(label="Open Save File...", command=self.load_file, 
                             accelerator="Ctrl+O")
        file_menu.add_command(label="Save Changes", command=self.save_changes,
                             accelerator="Ctrl+S")
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=file_menu)
        
        # Help menu
        help_menu = tk.Menu(menubar, bg="#1A1A1A", fg="#00FF90", tearoff=0)
        help_menu.add_command(label="Change Log", command=self.show_changelog)
        help_menu.add_command(label="Error Codes", command=self.show_error_codes)
        help_menu.add_command(label="Tutorial", command=self.show_tutorial)
        help_menu.add_separator()
        help_menu.add_command(label="Acknowledgements", command=self.show_acknowledgements)
        help_menu.add_separator()
        help_menu.add_command(label="About", command=self.show_about)
        menubar.add_cascade(label="Help", menu=help_menu)
        
        self.root.config(menu=menubar)
        
        # Keyboard shortcuts
        self.root.bind("<Control-o>", lambda e: self.load_file())
        self.root.bind("<Control-s>", lambda e: self.save_changes())
        
    def _create_widgets(self):
        """Create all GUI widgets."""
        main_frame = StyledFrame(self.root, padding=(20, 20, 20, 20))
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_label = ttk.Label(main_frame, text="Saints Row 2 Save Editor", 
                               style="Title.TLabel")
        title_label.pack(pady=(0, 20))
        
        # Status bar
        self.status_var = tk.StringVar(value="Ready - Select a save file")
        status_label = ttk.Label(main_frame, textvariable=self.status_var,
                                style="Small.TLabel")
        status_label.pack(pady=(0, 15))
        
        # Money section
        money_frame = StyledFrame(main_frame, padding=(10, 10))
        money_frame.pack(fill=tk.X, pady=(10, 10))
        
        ttk.Label(money_frame, text="Money:", style="Section.TLabel").pack(anchor=tk.W)
        
        self.money_spinbox = ttk.Spinbox(money_frame, from_=0, to=21474836,
                                        width=15, font=("Consolas", 15),
                                        state="readonly")
        self.money_spinbox.pack(pady=(5, 0))
        self.money_spinbox.set(0)
        
        # Weapons section
        weapons_notebook = ttk.Notebook(main_frame, style="Dark.TNotebook")
        weapons_notebook.pack(fill=tk.BOTH, expand=True, pady=(10, 10))
        
        weapons = [
            ("Pistol", "pistol"),
            ("SMG", "smg"),
            ("Shotgun", "shotgun"),
            ("Rifle", "rifle"),
            ("Special", "special"),
            ("Thrown", "thrown")
        ]
        
        self.weapon_widgets = {}
        for display_name, key in weapons:
            wframe = StyledFrame(weapons_notebook, padding=(15, 15))
            weapons_notebook.add(wframe, text=display_name)
            
            ttk.Label(wframe, text=f"{display_name}", 
                     style="Section.TLabel").pack(anchor=tk.W, pady=(0, 10))
            
            # Clip
            clip_frame = StyledFrame(wframe)
            clip_frame.pack(fill=tk.X)
            ttk.Label(clip_frame, text="Clip:", style="Small.TLabel").pack(side=tk.LEFT, padx=(0, 10))
            clip_spinbox = ttk.Spinbox(clip_frame, from_=0, to=2147483647,
                                      width=12, font=("Consolas", 14),
                                      state="readonly")
            clip_spinbox.pack(side=tk.LEFT)
            clip_spinbox.set(0)
            
            # Ammo
            ammo_frame = StyledFrame(wframe)
            ammo_frame.pack(fill=tk.X, pady=(5, 0))
            ttk.Label(ammo_frame, text="Ammo:", style="Small.TLabel").pack(side=tk.LEFT, padx=(0, 10))
            ammo_spinbox = ttk.Spinbox(ammo_frame, from_=0, to=2147483647,
                                      width=12, font=("Consolas", 14),
                                      state="readonly")
            ammo_spinbox.pack(side=tk.LEFT)
            ammo_spinbox.set(0)
            
            self.weapon_widgets[key] = {'clip': clip_spinbox, 'ammo': ammo_spinbox}
        
        # Action buttons
        btn_frame = StyledFrame(main_frame, padding=(10, 15))
        btn_frame.pack(fill=tk.X, pady=(10, 0))
        
        btn_frame.columnconfigure(0, weight=1)
        btn_frame.columnconfigure(1, weight=1)
        
        load_btn = ttk.Button(btn_frame, text="Load Save File", 
                             command=self.load_file,
                             style="Action.TButton", width=15)
        load_btn.grid(row=0, column=0, padx=5, pady=5)
        
        save_btn = ttk.Button(btn_frame, text="Save Changes",
                             command=self.save_changes,
                             style="Action.TButton", width=15)
        save_btn.grid(row=0, column=1, padx=5, pady=5)
        
        reset_btn = ttk.Button(btn_frame, text="Reset Changes",
                              command=self.reset_changes,
                              style="Action.TButton", width=15)
        reset_btn.grid(row=1, column=0, columnspan=2, padx=5, pady=5)
    
    def update_spinbox_state(self, enabled: bool):
        """Enable/disable all spinboxes based on whether file is loaded."""
        state = "normal" if enabled else "readonly"
        self.money_spinbox.config(state=state)
        for widgets in self.weapon_widgets.values():
            widgets['clip'].config(state=state)
            widgets['ammo'].config(state=state)
    
    def load_file(self):
        """Load save file dialog handler."""
        filepath = filedialog.askopenfilename(
            title="Open Save File",
            filetypes=[("Saints Row 2 Saves", "*.bbsave"), ("All Files", "*.*")],
            initialdir=str(Path.home() / "Documents" / "Saints Row 2")
        )
        
        if not filepath:
            return
        
        try:
            self.status_var.set(f"Loading: {Path(filepath).name}...")
            self.root.update()
            
            values = self.handler.load_file(filepath)
            self.current_values = values
            
            # Update UI with loaded values
            self.money_spinbox.set(values['money'])
            
            for weapon_key, widgets in self.weapon_widgets.items():
                widgets['clip'].set(values[f'{weapon_key}_clip'])
                widgets['ammo'].set(values[f'{weapon_key}_ammo'])
            
            self.update_spinbox_state(True)
            self.status_var.set(f"Loaded: {Path(filepath).name}")
            
        except SR2SaveError as e:
            error_code = self._get_error_code_from_message(str(e))
            messagebox.showerror("Load Error", 
                               f"Error Code {error_code}: {e}\n\nSee Help → Error Codes")
            self.status_var.set("Load failed")
        except Exception as e:
            messagebox.showerror("Unexpected Error", f"An unexpected error occurred:\n{e}")
            self.status_var.set("Load failed")
    
    def _get_error_code_from_message(self, message: str) -> int:
        """Extract error code from error message if present, else guess."""
        for code, desc in HelpData.ERROR_CODES.items():
            if desc.split(" - ")[0] in message:
                return code
        return 0  # Unknown
    
    def save_changes(self):
        """Save modifications to file."""
        if not self.handler.active_file:
            messagebox.showwarning("No File", "Please load a save file first.")
            return
        
        try:
            # Validate and update money
            money = int(self.money_spinbox.get())
            valid, msg = self.handler.validate_range('money', money)
            if not valid:
                raise SR2SaveError(msg)
            self.handler.write_money(money)
            
            # Validate and update all weapon stats
            for weapon_key, widgets in self.weapon_widgets.items():
                clip = int(widgets['clip'].get())
                ammo = int(widgets['ammo'].get())
                
                valid, msg = self.handler.validate_range('clip', clip)
                if not valid:
                    raise SR2SaveError(f"Clip: {msg}")
                valid, msg = self.handler.validate_range('ammo', ammo)
                if not valid:
                    raise SR2SaveError(f"Ammo: {msg}")
                
                self.handler.write_value(self.handler.OFFSETS[f'{weapon_key}_clip'], clip)
                self.handler.write_value(self.handler.OFFSETS[f'{weapon_key}_ammo'], ammo)
            
            # Save file with backup
            self.status_var.set("Saving changes...")
            self.root.update()
            
            self.handler.save_file(create_backup=True)
            self.status_var.set("Saved successfully!")
            self.handler.original_data = self.handler.file_data[:]
            
            messagebox.showinfo("Success", "Save file updated successfully!\nA backup was created (.bak file).")
            
        except SR2SaveError as e:
            error_code = self._get_error_code_from_message(str(e))
            messagebox.showerror("Save Error", 
                               f"Error Code {error_code}: {e}\n\nSee Help → Error Codes")
            self.status_var.set("Save failed")
        except Exception as e:
            messagebox.showerror("Unexpected Error", f"An unexpected error occurred:\n{e}")
            self.status_var.set("Save failed")
    
    def reset_changes(self):
        """Revert all changes to original values."""
        if self.handler.original_data:
            if messagebox.askyesno("Confirm Reset", 
                                  "This will discard all unsaved changes. Continue?"):
                self.handler.reset_changes()
                
                # Reload original values
                values = {}
                values['money'] = self.handler.read_money()
                for weapon in ['pistol', 'smg', 'shotgun', 'rifle', 'special', 'thrown']:
                    values[f'{weapon}_clip'] = self.handler.read_value(
                        self.handler.OFFSETS[f'{weapon}_clip'])
                    values[f'{weapon}_ammo'] = self.handler.read_value(
                        self.handler.OFFSETS[f'{weapon}_ammo'])
                
                self.current_values = values
                self.money_spinbox.set(values['money'])
                for weapon_key, widgets in self.weapon_widgets.items():
                    widgets['clip'].set(values[f'{weapon_key}_clip'])
                    widgets['ammo'].set(values[f'{weapon_key}_ammo'])
                
                self.status_var.set("Changes reverted to original")
        else:
            messagebox.showinfo("No Changes", "No unsaved changes to revert.")
    
    # Help Menu Functions
    def show_changelog(self):
        """Display changelog dialog."""
        self._show_help_dialog("Change Log", HelpData.CHANGELOG)
    
    def show_error_codes(self):
        """Display error codes dialog."""
        error_text = "\n\n".join([f"Code {code}: {desc}" 
                                 for code, desc in sorted(HelpData.ERROR_CODES.items())])
        self._show_help_dialog("Error Codes", error_text)
    
    def show_tutorial(self):
        """Display tutorial dialog."""
        self._show_help_dialog("Tutorial", HelpData.TUTORIAL)
    
    def show_acknowledgements(self):
        """Display acknowledgements dialog."""
        self._show_help_dialog("Acknowledgements", HelpData.ACKNOWLEDGEMENTS)
    
    def show_about(self):
        """Display about dialog."""
        about_text = """
Saints Row 2 Save Editor v2.0

A Python port of the original C# editor
by Rick Gibbed (GibbedTools) and Thomas Jepp (JeppTools)

Features:
• Money editing
• Weapon clip/ammo modification
• Automatic backups
• Value validation
• Dark themed interface

Licensed under MIT License
        """.strip()
        messagebox.showinfo("About", about_text)
    
    def _show_help_dialog(self, title: str, content: str):
        """Generic help dialog creator."""
        dialog = tk.Toplevel(self.root)
        dialog.title(title)
        dialog.geometry("600x500")
        dialog.configure(bg="#000000")
        
        # Add scrollbar
        canvas = tk.Canvas(dialog, bg="#000000", highlightthickness=0)
        scrollbar = ttk.Scrollbar(dialog, orient="vertical", command=canvas.yview)
        scrollable_frame = StyledFrame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Text widget for content
        text_widget = tk.Text(scrollable_frame, bg="#000000", fg="#00FF90",
                            font=("Consolas", 12), wrap=tk.WORD,
                            padx=20, pady=20, borderwidth=0, relief=tk.FLAT)
        text_widget.insert("1.0", content)
        text_widget.configure(state="disabled")
        text_widget.pack(fill=tk.BOTH, expand=True)
        
        close_btn = ttk.Button(dialog, text="Close", command=dialog.destroy,
                              style="Action.TButton")
        close_btn.pack(pady=10)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
    
    def run(self):
        """Start the application."""
        self.root.mainloop()


if __name__ == "__main__":
    # Set UTF-8 encoding for console (Windows compatibility)
    if sys.platform.startswith("win"):
        import locale
        locale.setlocale(locale.LC_ALL, "")
    
    app = SR2SaveEditor()
    app.run()

