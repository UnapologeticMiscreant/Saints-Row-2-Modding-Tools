#!/usr/bin/env python3
"""
ptoolcli.py — Saints Row 2 PEG texture extractor (CLI, Linux-ready).

Requirements:  Python 3.9+, Pillow (pip install pillow)
Optional:      libsquish.so / libsquish.dylib for faster DXT decompression

Usage:
  python3 ptoolcli.py <file.peg_pc>              — unpack single file
  python3 ptoolcli.py *.peg_pc                   — wildcards from inside folder
  python3 ptoolcli.py /path/to/dir/              — extract all PEGs in directory
  python3 ptoolcli.py -r /path/to/dir/           — recursive extraction
  python3 ptoolcli.py                            — scan current directory

Output files for each texture frame:
  {name}_{index}.png     — decoded PNG image
  {name}_{index}.raw     — raw compressed data (lossless)
  {file}.peg_desc        — XML metadata description

Supported formats: DXT1, DXT3, DXT5, R5G6B5, A8R8G8B8
"""

from __future__ import annotations

import os
import struct
import sys
import argparse
import ctypes
from dataclasses import dataclass, field
from enum import IntEnum
from typing import BinaryIO, List, Optional, Tuple
import xml.etree.ElementTree as ET
import glob

try:
    from PIL import Image
except ImportError:
    raise SystemExit("Pillow is required: pip install pillow")

# =============================================================================
# Structures
# =============================================================================

class PegFormat(IntEnum):
    UNKNOWN   = 0
    DXT1      = 0x0190
    DXT3      = 0x0191
    DXT5      = 0x0192
    R5G6B5    = 0x0193
    A1R5G5B5  = 0x0194
    A4R4G4B4  = 0x0195
    R8G8B8    = 0x0196
    A8R8G8B8  = 0x0197
    V8U8      = 0x0198
    CXV8U8    = 0x0199
    A8        = 0x019A

@dataclass
class PegFrame:
    offset:          int = 0
    width:           int = 0
    height:          int = 0
    format:          int = 0
    unknown_0a:      int = 0
    unknown_0c:      int = 0
    frames:          int = 0
    unknown_12:      int = 0
    unknown_16:      int = 0
    unknown_flags1a: int = 0
    size:            int = 0
    unknown_20:      int = 0
    unknown_24:      int = 0
    unknown_28:      int = 0
    unknown_2c:      int = 0

@dataclass
class PegEntry:
    name: str = ""
    frames: List[PegFrame] = field(default_factory=list)

# =============================================================================
# PEG File Parser
# =============================================================================

class PEGError(Exception):
    pass

class PegFile:
    def __init__(self, big_endian: bool = False):
        self.entries: List[PegEntry] = []
        self.file_size: int = 0
        self.data_file_size: int = 0
        self.unknown06: int = 0
        self.unknown12: int = 0
        self.unknown16: int = 0
        self.big_endian: bool = big_endian
        self.size_mismatch: bool = False

    def _read_u16(self, stream: BinaryIO) -> int:
        return struct.unpack((">" if self.big_endian else "<") + "H", stream.read(2))[0]

    def _read_u32(self, stream: BinaryIO) -> int:
        return struct.unpack((">" if self.big_endian else "<") + "I", stream.read(4))[0]

    def _read_asciiz(self, stream: BinaryIO) -> str:
        chars = bytearray()
        while True:
            b = stream.read(1)
            if not b or b == b"\x00":
                break
            chars += b
        return chars.decode("ascii", "replace")

    def read(self, stream: BinaryIO) -> None:
        magic = self._read_u32(stream)
        if magic != 0x564B4547:  # "GEKV"
            raise PEGError("Not a PEG file (invalid header magic)")

        version = self._read_u16(stream)
        if version != 10:
            raise PEGError(f"Unsupported PEG version: {version} (only v10 supported)")

        self.unknown06 = self._read_u16(stream)
        self.file_size = self._read_u32(stream)

        pos = stream.tell()
        stream.seek(0, 2)
        if stream.tell() != self.file_size:
            print(f"  WARNING: Header size {self.file_size} != actual file size {stream.tell()}")
        stream.seek(pos)

        self.data_file_size = self._read_u32(stream)
        entry_count = self._read_u16(stream)
        self.unknown12 = self._read_u16(stream)
        frame_count = self._read_u16(stream)
        self.unknown16 = self._read_u16(stream)

        names: List[str] = []
        stream.seek(0x18 + 0x30 * frame_count)
        for _ in range(entry_count):
            names.append(self._read_asciiz(stream))

        total_frames = 0
        stream.seek(0x18)
        for i in range(entry_count):
            entry = PegEntry(name=names[i])
            frame = self._read_frame(stream)
            entry.frames.append(frame)
            total_frames += 1

            if frame.frames == 0:
                raise PEGError(f"Frame count is 0 for entry '{entry.name}'")
            elif frame.frames > 1:
                for _ in range(1, frame.frames):
                    entry.frames.append(self._read_frame(stream))
                    total_frames += 1

            self.entries.append(entry)

        if total_frames != frame_count:
            print(f"  WARNING: Frame count mismatch (header={frame_count}, read={total_frames})")

    def _read_frame(self, stream: BinaryIO) -> PegFrame:
        data = stream.read(0x30)
        if len(data) < 0x30:
            data = data + b"\x00" * (0x30 - len(data))
        fmt = ">" if self.big_endian else "<"
        return PegFrame(*struct.unpack(fmt + "IHHHHIHIIHIIIII", data[:0x30]))

# =============================================================================
# Image Decompression
# =============================================================================

_BLOCK_SIZE = {PegFormat.DXT1: 8, PegFormat.DXT3: 16, PegFormat.DXT5: 16}

_squish = None
for _name in ("squish.dll", "libsquish.dll", "libsquish.so", "libsquish.dylib"):
    try:
        _dll = ctypes.CDLL(_name)
        getattr(_dll, "DecompressImage").argtypes = [
            ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p, ctypes.c_int]
        _squish = _dll
        break
    except OSError:
        continue

def _expand565(v: int) -> Tuple[int, int, int]:
    r = (v >> 11) & 0x1F
    g = (v >> 5) & 0x3F
    b = v & 0x1F
    return (r << 3) | (r >> 2), (g << 2) | (g >> 4), (b << 3) | (b >> 2)

def _pad_dims(w: int, h: int) -> Tuple[int, int]:
    return (w + 3) & ~3, (h + 3) & ~3

def _fix_block_endianness(data: bytes, fmt: PegFormat) -> bytes:
    bs = _BLOCK_SIZE.get(fmt, 16)
    out = bytearray(data)
    for base in range(0, len(data) - bs + 1, bs):
        cbase = base if fmt == PegFormat.DXT1 else base + 8
        out[cbase], out[cbase + 1] = data[cbase + 1], data[cbase]
        out[cbase + 2], out[cbase + 3] = data[cbase + 3], data[cbase + 2]
        if fmt == PegFormat.DXT3:
            for wb in range(4):
                o = base + wb * 2
                out[o], out[o + 1] = data[o + 1], data[o]
    return bytes(out)

def _pure_decompress(compressed: bytes, width: int, height: int, fmt: PegFormat) -> bytes:
    out_w, out_h = _pad_dims(width, height)
    out = bytearray(out_w * out_h * 4)
    blocks_x = out_w // 4
    bs = _BLOCK_SIZE[fmt]

    for brow in range(out_h // 4):
        for bcol in range(blocks_x):
            off = (brow * blocks_x + bcol) * bs
            alphas = None

            if fmt == PegFormat.DXT3:
                ab = compressed[off:off + 8]
                alphas = [((ab[i >> 1] >> ((i & 1) * 4)) & 0xF) * 17 for i in range(16)]
            elif fmt == PegFormat.DXT5:
                a0, a1 = compressed[off], compressed[off + 1]
                abits = int.from_bytes(compressed[off + 2:off + 8], "little")
                apal = [a0, a1]
                if a0 > a1:
                    apal.extend([((7 - k) * a0 + k * a1) // 7 for k in range(1, 7)])
                else:
                    apal.extend([((5 - k) * a0 + k * a1) // 5 for k in range(1, 5)] + [0, 255])
                alphas = [apal[(abits >> (3 * i)) & 7] for i in range(16)]

            coff = off if fmt == PegFormat.DXT1 else off + 8
            c0, c1, cbits = struct.unpack_from("<HHI", compressed, coff)
            p0, p1 = _expand565(c0), _expand565(c1)

            if c0 > c1:
                cpal = [(*p0, 255), (*p1, 255),
                        ((2*p0[0]+p1[0])//3, (2*p0[1]+p1[1])//3, (2*p0[2]+p1[2])//3, 255),
                        ((p0[0]+2*p1[0])//3, (p0[1]+2*p1[1])//3, (p0[2]+2*p1[2])//3, 255)]
            else:
                cpal = [(*p0, 255), (*p1, 255),
                        ((p0[0]+p1[0])//2, (p0[1]+p1[1])//2, (p0[2]+p1[2])//2, 255),
                        (0, 0, 0, 0)]

            for i in range(16):
                ci = (cbits >> (2 * i)) & 3
                r, g, b = cpal[ci][:3]
                a = alphas[i] if alphas else cpal[ci][3]
                pos = ((brow * 4 + i // 4) * out_w + (bcol * 4 + i % 4)) * 4
                out[pos:pos + 4] = bytes((r, g, b, a))

    if width != out_w or height != out_h:
        cropped = bytearray(width * height * 4)
        for y in range(height):
            cropped[y * width * 4:(y + 1) * width * 4] = \
                out[y * out_w * 4:(y * out_w + width) * 4]
        return bytes(cropped)
    return bytes(out)

def decompress(compressed: bytes, width: int, height: int, fmt: PegFormat,
               big_endian: bool = False) -> bytes:
    if fmt not in _BLOCK_SIZE:
        raise PEGError(f"Unsupported DXT format: {fmt}")
    if big_endian:
        compressed = _fix_block_endianness(compressed, fmt)
    if _squish:
        flags = {PegFormat.DXT1: 1, PegFormat.DXT3: 2, PegFormat.DXT5: 4}[fmt]
        src = (ctypes.c_char * len(compressed)).from_buffer_copy(compressed)
        dst = (ctypes.c_char * (width * height * 4))()
        _squish.DecompressImage(dst, width, height, src, flags)
        return bytes(dst)
    return _pure_decompress(compressed, width, height, fmt)

def byte_swap(data: bytes, fmt: PegFormat) -> bytes:
    out = bytearray(data)
    if fmt == PegFormat.DXT1:
        for i in range(0, len(data), 8):
            out[i], out[i+1] = data[i+1], data[i]
            out[i+2], out[i+3] = data[i+3], data[i+2]
    elif fmt == PegFormat.A8R8G8B8:
        for i in range(0, len(data), 4):
            out[i:i+4] = data[i:i+4][::-1]
    elif fmt == PegFormat.R5G6B5:
        for i in range(0, len(data), 2):
            out[i], out[i+1] = data[i+1], data[i]
    else:
        raise PEGError(f"Cannot byte-swap format: {fmt}")
    return bytes(out)

def decode_image(raw: bytes, width: int, height: int, fmt: PegFormat,
                 big_endian: bool = False) -> Image.Image:
    if fmt in (PegFormat.DXT1, PegFormat.DXT3, PegFormat.DXT5):
        rgba = decompress(raw, width, height, fmt, big_endian)
        return Image.frombytes("RGBA", (width, height), rgba)
    elif fmt == PegFormat.R5G6B5:
        if big_endian:
            raw = byte_swap(raw, fmt)
        words = struct.unpack(f"<{width*height}H", raw[:width*height*2])
        data = bytearray()
        for v in words:
            r = ((v >> 11) & 0x1F) << 3 | (v >> 11) & 0x7
            g = ((v >> 5) & 0x3F) << 2 | (v >> 5) & 0x3
            b = (v & 0x1F) << 3 | v & 0x7
            data.extend((r, g, b))
        return Image.frombytes("RGB", (width, height), bytes(data))
    elif fmt == PegFormat.A8R8G8B8:
        if big_endian:
            raw = byte_swap(raw, fmt)
        return Image.frombytes("RGBA", (width, height), raw, "raw", "BGRA")
    else:
        raise PEGError(f"Cannot decode format: {fmt.name} ({fmt})")

# =============================================================================
# XML Description Writer
# =============================================================================

def write_peg_description(peg: PegFile, path: str) -> None:
    root = ET.Element("PegDescription")
    frame_count = sum(len(e.frames) for e in peg.entries)

    ET.SubElement(root, "BigEndian").text = str(peg.big_endian)
    ET.SubElement(root, "Magic").text = "GEKV"
    ET.SubElement(root, "Version").text = "10"
    ET.SubElement(root, "Unknown06").text = str(peg.unknown06)
    ET.SubElement(root, "FileSize").text = str(peg.file_size)
    ET.SubElement(root, "DataFileSize").text = str(peg.data_file_size)
    ET.SubElement(root, "EntryCount").text = str(len(peg.entries))
    ET.SubElement(root, "Unknown12").text = str(peg.unknown12)
    ET.SubElement(root, "FrameCount").text = str(frame_count)
    ET.SubElement(root, "Unknown16").text = str(peg.unknown16)

    entries_el = ET.SubElement(root, "Entries")
    for entry in peg.entries:
        entry_el = ET.SubElement(entries_el, "Entry")
        ET.SubElement(entry_el, "Name").text = entry.name
        frames_el = ET.SubElement(entry_el, "Frames")
        for fr in entry.frames:
            f = ET.SubElement(frames_el, "Frame")
            ET.SubElement(f, "Offset").text = str(fr.offset)
            ET.SubElement(f, "Width").text = str(fr.width)
            ET.SubElement(f, "Height").text = str(fr.height)
            ET.SubElement(f, "Format").text = PegFormat(fr.format).name
            ET.SubElement(f, "Size").text = str(fr.size)

    tree = ET.ElementTree(root)
    ET.indent(tree, space="\t")
    tree.write(path, encoding="utf-8", xml_declaration=True)

# =============================================================================
# Companion Data File Lookup  (THE KEY FIX)
# =============================================================================

def find_data_file(peg_path: str, is_xbox: bool) -> Optional[str]:
    """
    Find the companion data file for a PEG header file.

    Saints Row 2 typically pairs:
        foo.peg_pc      with  foo.g_peg_pc
        foo.peg_xbox2   with  foo.g_peg_xbox2
    Some older tools/rrips use shorter variants, so those are fallbacks.
    """
    stem, _ = os.path.splitext(peg_path)
    platform = "xbox2" if is_xbox else "pc"
    candidates = [
        stem + f".g_peg_{platform}",   # foo.g_peg_pc  /  foo.g_peg_xbox2  (standard)
        stem + ".g_peg",               # foo.g_peg     (old script's guess)
        stem + f".gpeg_{platform}",    # occasional variant
        stem + ".gpeg",                # rare variant
    ]
    for cand in candidates:
        if os.path.isfile(cand):
            return cand
    return None

# =============================================================================
# Extraction Functions
# =============================================================================

def extract_single(peg_path: str, force_width_512: bool = False, quiet: bool = False) -> dict:
    """Extract a single PEG file. Returns stats dict."""
    stats = {"textures": 0, "frames": 0, "errors": 0}

    ext = os.path.splitext(peg_path)[1].lower()
    is_xbox = (ext == ".peg_xbox2")
    if ext not in (".peg_pc", ".peg_xbox2"):
        if not quiet:
            print(f"SKIP: {os.path.basename(peg_path)} (not a PEG file: {ext})")
        return stats

    data_path = find_data_file(peg_path, is_xbox)
    if data_path is None:
        if not quiet:
            print(f"SKIP: {os.path.basename(peg_path)} (no companion data file found)")
        return stats

    if not quiet:
        print(f"Processing: {os.path.basename(peg_path)}")

    peg = PegFile(is_xbox)

    # Read the header first (header file can close after this)
    with open(peg_path, "rb") as fs:
        peg.read(fs)

    stem, _ = os.path.splitext(peg_path)
    desc_path = stem + ".peg_desc"
    write_peg_description(peg, desc_path)

    out_dir = os.path.dirname(os.path.abspath(peg_path)) or "."

    # Keep the DATA file open for the entire extraction loop
    with open(data_path, "rb") as dfs:
        for entry in peg.entries:
            plural = "" if len(entry.frames) == 1 else "s"
            if not quiet:
                print(f"  {entry.name} ({len(entry.frames)} frame{plural}):")

            for i, fr in enumerate(entry.frames):
                png_path = os.path.join(out_dir, f"{entry.name}_{i}.png")
                raw_path = os.path.join(out_dir, f"{entry.name}_{i}.raw")

                try:
                    dfs.seek(fr.offset)
                    raw = dfs.read(fr.size)

                    with open(raw_path, "wb") as rf:
                        rf.write(raw)

                    if force_width_512 and is_xbox and fr.width == 0:
                        fr.width = 512

                    img = decode_image(raw, fr.width, fr.height, PegFormat(fr.format), is_xbox)
                    img.save(png_path, "PNG")
                    stats["frames"] += 1

                except Exception as e:
                    if not quiet:
                        print(f"    - FAILED [{type(e).__name__}]: {e}")
                    stats["errors"] += 1

            stats["textures"] += 1

    if not quiet:
        print(f"  Extracted {stats['frames']} frame(s)")
    return stats

def collect_peg_files(inputs: List[str], recursive: bool = False, quiet: bool = False) -> List[Tuple[str, bool]]:
    """
    Collect PEG files from various input types:
    - Single file
    - Directory
    - Unexpanded wildcard pattern (contains * or ?)
    - Shell-expanded file lists (already plain filenames)

    Returns list of (file_path, is_xbox) tuples.
    """
    peg_files: List[Tuple[str, bool]] = []

    for item in inputs:
        # Unexpanded wildcard (when the shell hasn't expanded it, e.g. quoted)
        if '*' in item or '?' in item:
            expanded = sorted(glob.glob(item))
            if not expanded:
                if not quiet:
                    print(f"WARN: Wildcard matched nothing: {item}")
                continue
            if not quiet:
                print(f"Expanded wildcard '{item}' to {len(expanded)} item(s)")
            for match in expanded:
                ext = os.path.splitext(match)[1].lower()
                if ext in (".peg_pc", ".peg_xbox2"):
                    peg_files.append((match, ext == ".peg_xbox2"))
            continue

        if not os.path.exists(item):
            if not quiet:
                print(f"ERROR: Path not found: {item}")
            continue

        if os.path.isfile(item):
            ext = os.path.splitext(item)[1].lower()
            if ext in (".peg_pc", ".peg_xbox2"):
                peg_files.append((item, ext == ".peg_xbox2"))
            elif not quiet:
                print(f"SKIP: Ignoring non-PEG file: {item}")
        elif os.path.isdir(item):
            if not quiet:
                print(f"Scanning directory: {item}")
            for root, dirs, files in os.walk(item):
                if not recursive:
                    dirs[:] = []
                for f in files:
                    ext = os.path.splitext(f)[1].lower()
                    if ext in (".peg_pc", ".peg_xbox2"):
                        full_path = os.path.join(root, f)
                        peg_files.append((full_path, ext == ".peg_xbox2"))

    # Deduplicate while preserving order
    seen = set()
    unique: List[Tuple[str, bool]] = []
    for p, x in peg_files:
        rp = os.path.realpath(p)
        if rp not in seen:
            seen.add(rp)
            unique.append((p, x))
    peg_files = unique

    # Warn about missing companion data files (now using correct lookup)
    missing = [p for p, x in peg_files if find_data_file(p, x) is None]
    if missing and not quiet:
        print(f"WARN: {len(missing)} PEG file(s) have no companion data file:")
        for p in missing[:5]:
            print(f"       {os.path.basename(p)}")
        if len(missing) > 5:
            print(f"       ... and {len(missing) - 5} more")

    if not peg_files and not quiet:
        print("No PEG files found in provided paths.")

    return peg_files

def extract_batch(peg_files: List[Tuple[str, bool]], force_width_512: bool = False, quiet: bool = False) -> dict:
    """Extract multiple PEG files. Returns aggregated stats."""
    total = {"files": 0, "textures": 0, "frames": 0, "errors": 0}

    if not quiet:
        print(f"\n{'='*60}")
        print(f"BATCH EXTRACTION: {len(peg_files)} PEG file(s)")
        print(f"{'='*60}\n")

    for peg_path, is_xbox in peg_files:
        if not quiet:
            print(f"[{total['files']+1}/{len(peg_files)}] {os.path.basename(peg_path)} {'(XBOX)' if is_xbox else ''}")

        stats = extract_single(peg_path, force_width_512, quiet)
        total["files"] += 1
        total["textures"] += stats["textures"]
        total["frames"] += stats["frames"]
        total["errors"] += stats["errors"]

    if not quiet:
        print(f"\n{'='*60}")
        print(f"COMPLETE: {total['files']} files | {total['textures']} textures | {total['frames']} frames")
        if total["errors"]:
            print(f"Failed: {total['errors']}")
        elif total["files"] > 0:
            print("All extractions successful!")
        print(f"{'='*60}\n")

    return total

# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Saints Row 2 PEG Texture Extractor (Linux)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Usage Examples:
  %(prog)s logo.peg_pc              # Single file
  %(prog)s *.peg_pc                 # Wildcard (from inside folder)
  %(prog)s *                        # Everything (PEG files auto-filtered)
  %(prog)s .                        # Current directory
  %(prog)s /path/to/folder/         # Specific directory
  %(prog)s -r /path/to/folder/      # Recursive scan
        """
    )
    parser.add_argument("inputs", nargs="*", metavar="FILE/DIR/*",
                        help=".peg_pc/.peg_xbox2 files, directories, or wildcards")
    parser.add_argument("-r", "--recursive", action="store_true",
                        help="Recursively scan directories")
    parser.add_argument("-w512", "--force-width-512", action="store_true",
                        help="Force zero-width Xbox frames to 512 (compatibility mode)")
    parser.add_argument("-q", "--quiet", action="store_true",
                        help="Suppress progress output")
    parser.add_argument("--list", "-l", action="store_true", dest="just_list",
                        help="List PEG files found without extracting")

    args = parser.parse_args()

    # If no arguments provided, default to current directory
    if not args.inputs:
        args.inputs = ["."]

    # Collect all PEG files
    peg_files = collect_peg_files(args.inputs, args.recursive, args.quiet)

    if not peg_files:
        print("\nERROR: No PEG files found to process.")
        print("Make sure .peg_pc AND matching .g_peg_pc files exist in the target directory.")
        sys.exit(1)

    # Just list if requested
    if args.just_list:
        print("\nPEG files found:")
        for path, is_xbox in peg_files:
            marker = "(XBOX)" if is_xbox else ""
            data = find_data_file(path, is_xbox)
            status = "OK" if data else "NO DATA FILE"
            print(f"  {os.path.basename(path)} {marker} [{status}]")
        print(f"\nTotal: {len(peg_files)} file(s)")
        sys.exit(0)

    # Batch extraction
    extract_batch(peg_files, args.force_width_512, args.quiet)

if __name__ == "__main__":
    main()
