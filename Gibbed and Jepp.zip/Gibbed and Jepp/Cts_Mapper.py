import re
import traceback
import tkinter as tk
from pathlib import Path
from tkinter import messagebox
from tkinter.scrolledtext import ScrolledText

from PIL import Image, ImageDraw, ImageFont


# Original coordinate conversion values
WORLD_WIDTH = 5800.0
WORLD_HEIGHT = 5700.0
OFFSET_X = 1256.0
OFFSET_Y = 1132.0



class EmeraldFileChooser(tk.Toplevel):
    """Black-and-emerald themed replacement for tkinter.filedialog."""

    def __init__(self, parent, title, save=False, initial_path=""):
        super().__init__(parent)

        self.background = "#000000"
        self.foreground = "#50C878"

  
        self.parent = parent
        self.save_mode = save
        self.result = None
        self.current_directory = Path(initial_path).expanduser()

        if self.current_directory.is_file():
            self.current_directory = self.current_directory.parent

        if not self.current_directory.is_dir():
            self.current_directory = Path.cwd()

        self.title(title)
        self.geometry("760x500")
        self.minsize(600, 350)
        self.configure(bg=self.background)
        self.transient(parent)
        self.grab_set()

        self.option_add("*Font", "Arial 14")
        self.option_add("*Foreground", self.foreground)
        self.option_add("*Background", self.background)  
  

        self.path_var = tk.StringVar(value=str(self.current_directory))
        self.filename_var = tk.StringVar()

        self.create_widgets()
        self.refresh()

        self.protocol("WM_DELETE_WINDOW", self.cancel)
        self.wait_window(self)

    def create_widgets(self):
        top = tk.Frame(self, bg="#000000")
        top.pack(fill="x", padx=10, pady=10)

        path_entry = tk.Entry(
            top,
            textvariable=self.path_var,
            bg="#050505",
            fg="#50C878",
            insertbackground="#50C878",
            selectbackground="#4B0082",
            selectforeground="#FFFFFF"
        )
        path_entry.pack(side="left", fill="x", expand=True)
        path_entry.bind("<Return>", lambda event: self.go_to_path())

        go_button = tk.Button(
            top,
            text="Go",
            command=self.go_to_path,
            bg="#4B0082",
            fg="#FFFFFF",
            activebackground="#6A0DAD",
            activeforeground="#FFFFFF"
        )
        go_button.pack(side="left", padx=(6, 0))

        up_button = tk.Button(
            top,
            text="Up",
            command=self.go_up,
            bg="#4B0082",
            fg="#FFFFFF",
            activebackground="#6A0DAD",
            activeforeground="#FFFFFF"
        )
        up_button.pack(side="left", padx=(6, 0))

        self.listbox = tk.Listbox(
            self,
            bg="#050505",
            fg="#50C878",
            selectbackground="#4B0082",
            selectforeground="#FFFFFF",
            highlightbackground="#50C878",
            highlightcolor="#50C878",
            activestyle="none"
        )
        self.listbox.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=(0, 8)
        )
        self.listbox.bind("<Double-Button-1>", self.double_click)
        self.listbox.bind("<Return>", self.double_click)

        bottom = tk.Frame(self, bg="#000000")
        bottom.pack(fill="x", padx=10, pady=(0, 10))

        filename_label = tk.Label(
            bottom,
            text="File:",
            bg="#000000",
            fg="#50C878"
        )
        filename_label.pack(side="left")

        filename_entry = tk.Entry(
            bottom,
            textvariable=self.filename_var,
            bg="#050505",
            fg="#50C878",
            insertbackground="#50C878",
            selectbackground="#4B0082",
            selectforeground="#FFFFFF"
        )
        filename_entry.pack(
            side="left",
            fill="x",
            expand=True,
            padx=6
        )
        filename_entry.bind("<Return>", lambda event: self.accept())

        button_text = "Save" if self.save_mode else "Open"

        accept_button = tk.Button(
            bottom,
            text=button_text,
            command=self.accept,
            width=10,
            bg="#4B0082",
            fg="#FFFFFF",
            activebackground="#6A0DAD",
            activeforeground="#FFFFFF"
        )
        accept_button.pack(side="left", padx=(0, 6))

        cancel_button = tk.Button(
            bottom,
            text="Cancel",
            command=self.cancel,
            width=10,
            bg="#4B0082",
            fg="#FFFFFF",
            activebackground="#6A0DAD",
            activeforeground="#FFFFFF"
        )
        cancel_button.pack(side="left")

    def refresh(self):
        self.listbox.delete(0, tk.END)
        
        try:
            entries = sorted(
                self.current_directory.iterdir(),
                key=lambda item: (not item.is_dir(), item.name.lower())
            )

            for entry in entries:
                if entry.is_dir():
                    self.listbox.insert(tk.END, "[DIR] " + entry.name)
                else:
                    self.listbox.insert(tk.END, entry.name)

            self.path_var.set(str(self.current_directory))

        except OSError as error:
            messagebox.showerror(
                "Unable to read folder",
                str(error),
                parent=self
            )

    def go_to_path(self):
        selected_path = Path(self.path_var.get()).expanduser()

        if selected_path.is_dir():
            self.current_directory = selected_path
            self.refresh()
        else:
            messagebox.showerror(
                "Invalid folder",
                "The selected path is not a valid folder.",
                parent=self
            )

    def go_up(self):
        parent = self.current_directory.parent

        if parent != self.current_directory:
            self.current_directory = parent
            self.refresh()

    def double_click(self, event=None):
        selection = self.listbox.curselection()

        if not selection:
            return

        selected_text = self.listbox.get(selection[0])

        if selected_text.startswith("[DIR] "):
            directory_name = selected_text[6:]
            directory_path = self.current_directory / directory_name

            if directory_path.is_dir():
                self.current_directory = directory_path
                self.refresh()
        else:
            self.filename_var.set(selected_text)

            if not self.save_mode:
                self.accept()

    def accept(self):
        filename = self.filename_var.get().strip()

        if not filename:
            selection = self.listbox.curselection()

            if selection:
                selected_text = self.listbox.get(selection[0])

                if not selected_text.startswith("[DIR] "):
                    filename = selected_text

        if not filename:
            messagebox.showwarning(
                "No file selected",
                "Select a file or enter a file name.",
                parent=self
            )
            return

        selected_path = Path(filename).expanduser()

        if not selected_path.is_absolute():
            selected_path = self.current_directory / selected_path

        if self.save_mode:
            self.result = selected_path
            self.destroy()
            return

        if selected_path.is_file():
            self.result = selected_path
            self.destroy()
        else:
            messagebox.showerror(
                "File not found",
                str(selected_path),
                parent=self
            )

    def cancel(self):
        self.result = None
        self.destroy()


class CtsMapperApp(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("ctsMapper")
        self.geometry("900x650")
        self.minsize(760, 500)

        self.background = "#000000"
        self.foreground = "#50C878"
        self.highlight = "#4B0082"       # Deep Purple
        self.highlight_text = "#FFFFFF"

        self.configure(bg=self.background)

        self.input_file = tk.StringVar()
        self.map_file = tk.StringVar(
            value=str(Path(__file__).resolve().parent /
                      "ui_map_world_city.tga_0")
        )
        self.output_file = tk.StringVar()

        self.create_styles()
        self.create_menu()
        self.create_widgets()

    def create_styles(self):
        self.option_add("*Background", self.background)
        self.option_add("*Foreground", self.foreground)
        self.option_add("*Entry.Background", "#101010")
        self.option_add("*Entry.Foreground", self.foreground)
        self.option_add("*Text.Background", "#101010")
        self.option_add("*Text.Foreground", self.foreground)
        self.option_add("*Button.Background", self.highlight)
        self.option_add("*Button.Foreground", self.highlight_text)
        self.option_add("*Button.ActiveBackground", "#6A0DAD")
        self.option_add("*Button.ActiveForeground", self.highlight_text)

    def create_menu(self):
        menu_bar = tk.Menu(
            self,
            bg=self.background,
            fg=self.foreground,
            activebackground=self.highlight,
            activeforeground=self.highlight_text
        )

        help_menu = tk.Menu(
            menu_bar,
            tearoff=False,
            bg=self.background,
            fg=self.foreground,
            activebackground=self.highlight,
            activeforeground=self.highlight_text
        )

        help_menu.add_command(
            label="Documentation",
            command=self.show_documentation
        )
        help_menu.add_command(
            label="Errors and Meanings",
            command=self.show_errors
        )
        help_menu.add_command(
            label="Tutorial",
            command=self.show_tutorial
        )
        help_menu.add_command(
            label="Acknowledgements",
            command=self.show_acknowledgements
        )

        menu_bar.add_cascade(label="Help", menu=help_menu)
        self.config(menu=menu_bar)

    def create_widgets(self):
        title = tk.Label(
            self,
            text="ctsMapper",
            bg=self.background,
            fg=self.foreground,
            font=("Arial", 18, "bold")
        )
        title.pack(pady=(12, 8))

        main_frame = tk.Frame(self, bg=self.background)
        main_frame.pack(fill="x", padx=15)

        self.add_file_row(
            main_frame,
            "Input coordinate file:",
            self.input_file,
            self.browse_input
        )

        self.add_file_row(
            main_frame,
            "Map image:",
            self.map_file,
            self.browse_map
        )

        self.add_file_row(
            main_frame,
            "Output PNG:",
            self.output_file,
            self.browse_output
        )

        button_frame = tk.Frame(main_frame, bg=self.background)
        button_frame.pack(fill="x", pady=12)

        self.run_button = tk.Button(
            button_frame,
            text="Create Map",
            command=self.run_mapper,
            width=18,
            relief=tk.RAISED
        )
        self.run_button.pack(side="left", padx=(0, 8))

        clear_button = tk.Button(
            button_frame,
            text="Clear Log",
            command=self.clear_log,
            width=18
        )
        clear_button.pack(side="left")

        log_label = tk.Label(
            self,
            text="Messages:",
            bg=self.background,
            fg=self.foreground,
            anchor="w"
        )
        log_label.pack(fill="x", padx=15)

        self.log_box = ScrolledText(
            self,
            wrap=tk.WORD,
            height=20,
            bg="#101010",
            fg=self.foreground,
            insertbackground=self.foreground,
            selectbackground=self.highlight,
            selectforeground=self.highlight_text
        )
        self.log_box.pack(fill="both", expand=True, padx=15, pady=(3, 15))

    def add_file_row(self, parent, label_text, variable, browse_command):
        row = tk.Frame(parent, bg=self.background)
        row.pack(fill="x", pady=4)

        label = tk.Label(
            row,
            text=label_text,
            width=22,
            anchor="w",
            bg=self.background,
            fg=self.foreground
        )
        label.pack(side="left")

        entry = tk.Entry(
            row,
            textvariable=variable,
            bg="#101010",
            fg=self.foreground,
            insertbackground=self.foreground
        )
        entry.pack(side="left", fill="x", expand=True, padx=5)

        button = tk.Button(
            row,
            text="Browse",
            command=browse_command,
            width=10
        )
        button.pack(side="right")

    def browse_input(self):
        chooser = EmeraldFileChooser(
            self,
            "Select coordinate input file",
            save=False,
            initial_path=self.input_file.get() or Path.cwd()
        )

        if chooser.result:
            filename = str(chooser.result)
            self.input_file.set(filename)

            if not self.output_file.get():
                self.output_file.set(
                    str(Path(filename).with_suffix(".png"))
                )

    def browse_map(self):
        chooser = EmeraldFileChooser(
            self,
            "Select map image",
            save=False,
            initial_path=self.map_file.get() or Path.cwd()
        )

        if chooser.result:
            self.map_file.set(str(chooser.result))

    def browse_output(self):
        chooser = EmeraldFileChooser(
            self,
            "Select output PNG",
            save=True,
            initial_path=self.output_file.get() or Path.cwd()
        )

        if chooser.result:
            output_path = chooser.result

            if output_path.suffix.lower() != ".png":
                output_path = output_path.with_suffix(".png")

            self.output_file.set(str(output_path))

    def log(self, message):
        self.log_box.insert(tk.END, message + "\n")
        self.log_box.see(tk.END)
        self.update_idletasks()

    def clear_log(self):
        self.log_box.delete("1.0", tk.END)

    def run_mapper(self):
        input_name = self.input_file.get().strip()
        map_name = self.map_file.get().strip()
        output_name = self.output_file.get().strip()

        if not input_name:
            self.show_error(
                "No input file was selected.",
                "Select the file containing the Navpoint and Pos data."
            )
            return

        if not map_name:
            self.show_error(
                "No map image was selected.",
                "Select ui_map_world_city.tga_0.png."
            )
            return

        if not output_name:
            input_path = Path(input_name)
            output_name = str(input_path.with_suffix(".png"))
            self.output_file.set(output_name)

        input_path = Path(input_name).expanduser()

        map_path = Path(map_name).expanduser()

        # Normalize the map-image path.
        # If the user entered ui_map_world_city.tga_0,
        # also try ui_map_world_city.tga_0.png.
        if map_path.suffix.lower() != ".png":
            png_candidate = Path(str(map_path) + ".png")

            if png_candidate.is_file():
                map_path = png_candidate

        input_path = input_path.resolve()
        map_path = map_path.resolve()

        output_path = Path(output_name).expanduser().resolve()

        if not input_path.is_file():
            self.show_error(
                "Input file was not found.",
                str(input_path)
            )
            return

        if not map_path.is_file():
            expected_name = "ui_map_world_city.tga_0.png"

            self.show_error(
                "Map image was not found.",
                "The program looked for:\n\n"
                + str(map_path)
                + "\n\n"
                "Expected filename:\n"
                + expected_name
            )
            return

        self.run_button.config(state=tk.DISABLED)
        self.clear_log()

        try:
            self.create_map(input_path, map_path, output_path)

            self.log("")
            self.log("Done!")
            self.log("Output saved to:")
            self.log(str(output_path.resolve()))

            messagebox.showinfo(
                "Mapping complete",
                "The map was created successfully."
            )

        except Exception as error:
            self.log("")
            self.log("ERROR: " + str(error))
            self.log(traceback.format_exc())

            messagebox.showerror(
                "Mapping failed",
                str(error)
            )

        finally:
            self.run_button.config(state=tk.NORMAL)

    def create_map(self, input_path, map_path, output_path):
        self.log("Reading input file:")
        self.log(str(input_path))

        text = input_path.read_text(
            encoding="utf-8-sig",
            errors="replace"
        )

        # Accepts negative values, decimals, and flexible whitespace.
        regex = re.compile(
            r'\$Navpoint:.*?"(?P<name>.*?)"'
            r'.*?\$Pos:.*?<\s*'
            r'(?P<x>[+-]?(?:\d+(?:\.\d*)?|\.\d+))\s+'
            r'(?P<z>[+-]?(?:\d+(?:\.\d*)?|\.\d+))\s+'
            r'(?P<y>[+-]?(?:\d+(?:\.\d*)?|\.\d+))\s*>',
            re.IGNORECASE | re.DOTALL
        )

        matches = list(regex.finditer(text))
        self.log(f"Found {len(matches)} coordinates.")

        if not matches:
            raise ValueError(
                "No Navpoint/Pos entries were found. "
                "Check the input file format."
            )

        self.log("Loading map image:")
        self.log(str(map_path))

        # Converting to RGBA fixes drawing failures with indexed PNG files.
        with Image.open(map_path) as source:
            image = source.convert("RGBA")

        draw = ImageDraw.Draw(image)

        try:
            font = ImageFont.truetype("verdana.ttf", 15)
        except OSError:
            try:
                font = ImageFont.truetype("DejaVuSans.ttf", 12)
            except OSError:
                font = ImageFont.load_default()

        # Origin marker
        self.draw_cross(
            draw,
            image,
            0.0,
            0.0,
            "(0, 0, 0)",
            "#FF0000",
            font
        )

        valid_count = 0

        for match in matches:
            name = match.group("name").strip()

            try:
                x = float(match.group("x"))
                z = float(match.group("z"))
                y = float(match.group("y"))
            except ValueError:
                self.log(f"Skipped invalid coordinates: {name}")
                continue

            self.log(f"{name}: ({x}, {y}, {z})")

            self.draw_cross(
                draw,
                image,
                x,
                y,
                name,
                "#00FF00",
                font
            )

            valid_count += 1

        output_path.parent.mkdir(parents=True, exist_ok=True)
        image.save(output_path, "PNG")

        self.log(f"Mapped {valid_count} coordinates.")

    def draw_cross(self, draw, image, world_x, world_y,
                   name, color, font):
        # Preserve the original C# behavior: X is inverted, Y is not.
        x = -world_x
        y = world_y

        x = ((x / WORLD_WIDTH) * image.width) + OFFSET_X
        y = ((y / WORLD_HEIGHT) * image.height) + OFFSET_Y

        draw.line(
            [(x - 4, y - 4), (x + 4, y + 4)],
            fill=color,
            width=2
        )
        draw.line(
            [(x - 4, y + 4), (x + 4, y - 4)],
            fill=color,
            width=2
        )

        draw.text(
            (x + 6, y + 6),
            name,
            fill=color,
            font=font
        )

        if (
            x < 0 or x >= image.width or
            y < 0 or y >= image.height
        ):
            self.log(f"Warning: {name} is outside the map image.")

        self.log(f"Translated {name}: ({x:.2f}, {y:.2f})")

    def show_help_window(self, title, text):
        window = tk.Toplevel(self)
        window.title(title)
        window.geometry("760x520")
        window.configure(bg=self.background)
        window.transient(self)

        text_box = ScrolledText(
            window,
            wrap=tk.WORD,
            bg="#101010",
            fg=self.foreground,
            insertbackground=self.foreground,
            selectbackground=self.highlight,
            selectforeground=self.highlight_text
        )
        text_box.pack(fill="both", expand=True, padx=12, pady=12)
        text_box.insert("1.0", text)
        text_box.config(state=tk.DISABLED)

        close_button = tk.Button(
            window,
            text="Close",
            command=window.destroy,
            width=15
        )
        close_button.pack(pady=(0, 12))

    def show_documentation(self):
        self.show_help_window(
            "ctsMapper Documentation",
            """ctsMapper Documentation

Purpose
-------
ctsMapper reads Navpoint and Pos entries from a text file and places
cross markers and labels on ui_map_world_city.tga_0.png.

Changes made
------------
1. Added a graphical user interface using Tkinter.
2. Added file-selection dialogs for the input, map, and output files.
3. Added validation for missing files and invalid selections.
4. Added support for indexed PNG images by converting them to RGBA.
5. Added culture-independent numeric parsing through Python float parsing.
6. Added handling for invalid coordinate entries.
7. Added automatic output-file selection.
8. Added logging of translated coordinates.
9. Added Help documentation.
10. Added proper image handling and exception reporting.

Coordinate behavior
-------------------
The original coordinate transformation is retained:

    X is inverted.
    Y is not inverted.

The map conversion uses the original world dimensions and offsets.
"""
        )

    def show_errors(self):
        self.show_help_window(
            "Errors and Their Meanings",
            """Errors and Their Meanings

No input file was selected
--------------------------
Select the source text file containing Navpoint and Pos data.

Input file was not found
------------------------
The selected source file no longer exists or the path is invalid.

No map image was selected
-------------------------
Select the map image used as the background.

Map image was not found
-----------------------
The selected PNG file does not exist.

No Navpoint/Pos entries were found
----------------------------------
The input file did not match the expected format.

Mapping failed
--------------
An unexpected error occurred. The detailed Python traceback is shown
in the main log window.

Warning: <name> is outside the map image
----------------------------------------
The coordinate was translated, but its position falls outside the
visible image boundaries.

Pillow is not installed
-----------------------
Install it with:

    python -m pip install Pillow
"""
        )

    def show_tutorial(self):
        self.show_help_window(
            "ctsMapper Tutorial",
            """Small Tutorial

1. Start the program:

       python cts_mapper.py

2. Click Browse beside Input coordinate file.

3. Select the file containing the Navpoint and Pos definitions.

4. Confirm that the map image points to:

       ui_map_world_city.tga_0.png

5. Choose an output PNG file, or use the automatically generated name.

6. Click Create Map.

7. The messages window displays the coordinates found and their
   translated image positions.

8. Open the generated PNG to view the crosses and labels.

Expected input format
---------------------
The parser expects entries similar to:

    $Navpoint: "Example City"
    $Pos: <100.0 20.0 -300.0>

The parser accepts negative numbers, decimal values, and varying
amounts of whitespace.
"""
        )

    def show_acknowledgements(self):
        self.show_help_window(
            "Acknowledgements",
            """Acknowledgements

Credits

Rick Gibbed for GibbedTools, whose publicly available source code
was used to create this.

Thanks also to Thomas Jepp for JeppTools.
"""
        )

    def show_error(self, title, details):
        messagebox.showerror(title, details)


if __name__ == "__main__":
    app = CtsMapperApp()
    app.mainloop()
