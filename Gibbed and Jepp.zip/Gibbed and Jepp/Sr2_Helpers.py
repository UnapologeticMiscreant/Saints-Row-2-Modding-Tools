
"""
SR2 Save Editor Helper Functions
Ported from Gibbed.SaintsRow2.Helpers (C#) to Python 3.10

Acknowledgments:
- Rick Gibbed for GibbedTools
- Thomas Jepp for JeppTools
"""

import struct
import zlib
from typing import Optional


class SR2SaveError(Exception):
    """Custom exception for save file errors."""
    pass


class ByteHelpers:
    """Binary data manipulation utilities."""
    
    @staticmethod
    def swap_bytes(value: int, size: int) -> int:
        """Swap byte order for endianness conversion."""
        if size == 1:
            return value
        elif size == 2:
            return ((value >> 8) & 0x00FF) | ((value << 8) & 0xFF00)
        elif size == 4:
            return ((value >> 24) & 0xFF) | ((value >> 8) & 0xFF00) | \
                   ((value << 8) & 0xFF0000) | ((value << 24) & 0xFF000000)
        elif size == 8:
            mask = 0xFFFFFFFFFFFFFFFF
            value = value & mask
            return ((value >> 56) & 0xFF) | ((value >> 40) & 0xFF00) | \
                   ((value >> 24) & 0xFF0000) | ((value >> 8) & 0xFF000000) | \
                   ((value << 8) & 0xFF00000000) | ((value << 24) & 0xFF0000000000) | \
                   ((value << 40) & 0xFF000000000000) | ((value << 56) & 0xFF00000000000000)
        else:
            raise ValueError(f"Unsupported byte size: {size}")
    
    @staticmethod
    def ascii_to_bytes(text: str) -> bytes:
        """Convert ASCII string to bytes."""
        return text.encode('ascii')
    
    @staticmethod
    def bytes_to_ascii(data: bytes, null_terminated: bool = True) -> str:
        """Convert bytes to ASCII string."""
        if null_terminated:
            null_pos = data.find(b'\x00')
            if null_pos != -1:
                data = data[:null_pos]
        try:
            return data.decode('ascii', errors='ignore')
        except UnicodeDecodeError:
            return data.decode('latin-1', errors='ignore')
    
    @staticmethod
    def align(value: int, alignment: int) -> int:
        """Align value to specified boundary."""
        if value == 0 or alignment == 0:
            return value
        remainder = value % alignment
        if remainder == 0:
            return value
        return value + (alignment - remainder)


class StreamHelpers:
    """Stream reading/writing utilities matching Gibbed's implementation."""
    
    ERROR_CODES = {
        1: "File not found or inaccessible",
        2: "Invalid file format (not a .bbsave file)",
        3: "Insufficient data at offset (file too small)",
        4: "Checksum mismatch (save file may be corrupted)",
        5: "Invalid value range (out of acceptable limits)",
        6: "Write permission denied",
        7: "Unknown file version",
        8: "Backup failed"
    }
    
    @staticmethod
    def read_u8(stream) -> int:
        """Read unsigned 8-bit integer."""
        data = stream.read(1)
        if len(data) < 1:
            raise SR2SaveError("Insufficient data at offset (file too small)")
        return data[0]
    
    @staticmethod
    def write_u8(stream, value: int):
        """Write unsigned 8-bit integer."""
        stream.write(struct.pack('B', value & 0xFF))
    
    @staticmethod
    def read_s16(stream) -> int:
        """Read signed 16-bit integer (little-endian)."""
        data = stream.read(2)
        if len(data) < 2:
            raise SR2SaveError("Insufficient data at offset (file too small)")
        return struct.unpack('<h', data)[0]
    
    @staticmethod
    def write_s16(stream, value: int):
        """Write signed 16-bit integer (little-endian)."""
        stream.write(struct.pack('<h', value & 0xFFFF))
    
    @staticmethod
    def read_u16(stream) -> int:
        """Read unsigned 16-bit integer (little-endian)."""
        data = stream.read(2)
        if len(data) < 2:
            raise SR2SaveError("Insufficient data at offset (file too small)")
        return struct.unpack('<H', data)[0]
    
    @staticmethod
    def write_u16(stream, value: int):
        """Write unsigned 16-bit integer (little-endian)."""
        stream.write(struct.pack('<H', value & 0xFFFF))
    
    @staticmethod
    def read_s32(stream) -> int:
        """Read signed 32-bit integer (little-endian)."""
        data = stream.read(4)
        if len(data) < 4:
            raise SR2SaveError("Insufficient data at offset (file too small)")
        return struct.unpack('<i', data)[0]
    
    @staticmethod
    def write_s32(stream, value: int):
        """Write signed 32-bit integer (little-endian)."""
        stream.write(struct.pack('<i', value & 0xFFFFFFFF))
    
    @staticmethod
    def read_u32(stream) -> int:
        """Read unsigned 32-bit integer (little-endian)."""
        data = stream.read(4)
        if len(data) < 4:
            raise SR2SaveError("Insufficient data at offset (file too small)")
        return struct.unpack('<I', data)[0]
    
    @staticmethod
    def write_u32(stream, value: int):
        """Write unsigned 32-bit integer (little-endian)."""
        stream.write(struct.pack('<I', value & 0xFFFFFFFF))
    
    @staticmethod
    def read_f32(stream) -> float:
        """Read 32-bit float (little-endian)."""
        data = stream.read(4)
        if len(data) < 4:
            raise SR2SaveError("Insufficient data at offset (file too small)")
        return struct.unpack('<f', data)[0]
    
    @staticmethod
    def write_f32(stream, value: float):
        """Write 32-bit float (little-endian)."""
        stream.write(struct.pack('<f', value))
    
    @staticmethod
    def calculate_checksum(data: bytes, start: int = 0, length: int = None) -> int:
        """Calculate CRC32 checksum for save file integrity."""
        if length is None:
            length = len(data) - start
        return zlib.crc32(data[start:start + length]) & 0xFFFFFFFF


class SaveFileHandler:
    """Handles all save file operations with validation."""
    
    # Weapon data offsets (from original C# code)
    OFFSETS = {
        'money': 0x00B4,
        'pistol_clip': 0x00F4,
        'pistol_ammo': 0x00F8,
        'smg_clip': 0x0110,
        'smg_ammo': 0x0114,
        'shotgun_clip': 0x012C,
        'shotgun_ammo': 0x0130,
        'rifle_clip': 0x0148,
        'rifle_ammo': 0x014C,
        'special_clip': 0x0164,
        'special_ammo': 0x0168,
        'thrown_clip': 0x0180,
        'thrown_ammo': 0x0184,
    }
    
    # Valid ranges for validation (added safety feature missing in original)
    VALID_RANGES = {
        'money': (0, 21474836),  # Max displayable (divided by 100)
        'clip': (0, 2147483647),
        'ammo': (0, 2147483647),
    }
    
    def __init__(self):
        self.active_file: Optional[str] = None
        self.file_data: Optional[bytes] = None
        self.original_data: Optional[bytes] = None  # For backup/comparison
    
    def validate_range(self, field_name: str, value: int) -> tuple[bool, str]:
        """Validate value is within acceptable range."""
        if 'money' in field_name.lower():
            min_val, max_val = self.VALID_RANGES['money']
        elif 'clip' in field_name.lower() or 'ammo' in field_name.lower():
            min_val, max_val = self.VALID_RANGES['ammo']
        else:
            return True, ""
        
        if not (min_val <= value <= max_val):
            return False, f"Value {value} out of range [{min_val}, {max_val}]"
        return True, ""
    
    def load_file(self, filepath: str) -> dict:
        """Load save file and extract all editable values."""
        if not filepath:
            raise SR2SaveError("No file selected")
        
        try:
            with open(filepath, 'rb') as f:
                self.file_data = f.read()
            
            self.original_data = self.file_data[:]
            self.active_file = filepath
            
            # Validate minimum file size (all offsets must fit)
            max_offset = max(self.OFFSETS.values()) + 4  # +4 for 32-bit value
            if len(self.file_data) < max_offset:
                raise SR2SaveError(f"File too small ({len(self.file_data)} bytes, need at least {max_offset})")
            
            values = {}
            values['money'] = self.read_money()
            
            # Read all weapon stats
            for weapon in ['pistol', 'smg', 'shotgun', 'rifle', 'special', 'thrown']:
                clip_key = f'{weapon}_clip'
                ammo_key = f'{weapon}_ammo'
                values[clip_key] = self.read_value(self.OFFSETS[clip_key])
                values[ammo_key] = self.read_value(self.OFFSETS[ammo_key])
            
            return values
            
        except FileNotFoundError:
            raise SR2SaveError("File not found or inaccessible")
        except PermissionError:
            raise SR2SaveError("Write permission denied")
        except Exception as e:
            raise SR2SaveError(f"Failed to load file: {str(e)}")
    
    def read_money(self) -> int:
        """Read money value (stored in cents)."""
        value = self.read_value(self.OFFSETS['money'])
        return value // 100  # Convert cents to display value
    
    def write_money(self, value: int):
        """Write money value (convert to cents for storage)."""
        cents = int(value * 100)
        self.write_value(self.OFFSETS['money'], cents)
    
    def read_value(self, offset: int) -> int:
        """Read 32-bit integer at specified offset."""
        import io
        stream = io.BytesIO(self.file_data)
        stream.seek(offset)
        return StreamHelpers.read_s32(stream)
    
    def write_value(self, offset: int, value: int):
        """Write 32-bit integer at specified offset."""
        import io
        stream = io.BytesIO(self.file_data)
        stream.seek(offset)
        StreamHelpers.write_s32(stream, value)
        self.file_data = stream.getvalue()
    
    def save_file(self, filepath: str = None, create_backup: bool = True) -> None:
        """Save modified data to file with optional backup."""
        filepath = filepath or self.active_file
        
        if not filepath:
            raise SR2SaveError("No file path specified for save")
        
        try:
            # Create backup before modifying
            if create_backup and self.original_data:
                backup_path = filepath + '.bak'
                with open(backup_path, 'wb') as f:
                    f.write(self.original_data)
            
            with open(filepath, 'wb') as f:
                f.write(self.file_data)
            
        except PermissionError:
            raise SR2SaveError("Write permission denied")
        except Exception as e:
            raise SR2SaveError(f"Failed to save file: {str(e)}")
    
    def reset_changes(self):
        """Revert all changes to original saved data."""
        if self.original_data:
            self.file_data = self.original_data[:]


class HelpData:
    """Centralized help documentation."""
    
    CHANGELOG = """
Version 2.0 (Python Port - 2026)
================================
- Converted from C# WinForms to Python 3.10 with tkinter
- Implemented custom dark theme (#000000 background, #00FF90 foreground)
- Added value range validation to prevent save corruption
- Added automatic backup creation (.bak files)
- Fixed missing checksum calculation
- Improved error messages with specific error codes
- Added comprehensive help menu with tutorial
- Modernized UI with better organization

Version 1.0 (Original C# - 2010)
================================
- Initial release by Gibbed
- Basic money and weapon ammo editing
- WinForms interface
- Required .NET Framework 4.0
    """.strip()
    
    ERROR_CODES = {
        1: "File not found or inaccessible - Check that the file exists and you have read permissions",
        2: "Invalid file format - Make sure you're loading a .bbsave file from Saints Row 2",
        3: "Insufficient data at offset - Save file is corrupted or incomplete",
        4: "Checksum mismatch - Save file integrity check failed, may be corrupted",
        5: "Invalid value range - Entered value exceeds acceptable limits for this field",
        6: "Write permission denied - Cannot write to file, check file attributes and permissions",
        7: "Unknown file version - This save format is not supported by this editor",
        8: "Backup failed - Could not create backup file before modification"
    }
    
    TUTORIAL = """
SAINTS ROW 2 SAVE EDITOR TUTORIAL
==================================

Getting Started
---------------
1. Click "Load Save File" to open your .bbsave file
2. The editor will automatically load all current values
3. Modify any field using the number spinboxes
4. Click "Save" to apply your changes

Understanding Fields
--------------------
• Money: Your in-game cash (shown in dollars, stored in cents)
• Pistol/SMG/Shotgun/Rifle/Special/Thrown:
  - Clip: Current magazine rounds
  - Ammo: Total reserve ammunition

Best Practices
--------------
✓ Always keep the automatic backup (.bak file) until you confirm your changes work
✓ Don't set impossibly high values (some games detect and reject these)
✓ Make one change at a time when troubleshooting
✓ Close the game before editing save files
✓ Create a manual backup before major edits

Troubleshooting
---------------
• Game crashes after loading save: Values may be out of range, reload from backup
• Changes not appearing: Ensure you clicked "Save" button
• Can't find save file: SR2 saves are typically in Documents\\Saints Row 2\\
• Editor won't load file: Verify it's a genuine .bbsave file format

Safety Warnings
---------------
⚠ Online play with edited saves may result in bans
⚠ Excessive money can corrupt progression systems
⚠ Always test changes on a copy first
    """.strip()
    
    ACKNOWLEDGEMENTS = """
ACKNOWLEDGEMENTS
================

This project builds upon the incredible reverse engineering work of:

Rick Gibbed (Gibbed)
---------------------
Creator of GibbedTools, a legendary suite of tools for Volition games including
Saints Row 2. His meticulous analysis of the game's file formats and binary
structures made tools like this possible. The helper functions in this project
are direct ports of his C# implementation.

Website: https://github.com/gibbed

Thomas Jepp (Jepp)
-------------------
Developer of JeppTools, another essential toolkit for Saints Row modding. His
work on game asset extraction and save file manipulation provided critical
reference implementations and documentation for the community.

Website: https://github.com/jeppywep

Special Thanks
--------------
• The Saints Row modding community for extensive format documentation
• Volition Inc. for creating an amazing game worth preserving
• Python and tkinter maintainers for excellent cross-platform GUI support

License
-------
This software is provided as-is for educational purposes. Respect game developers
and use responsibly. Do not distribute edited saves online or for commercial gain.
    """.strip()


def get_error_message(code: int) -> str:
    """Get human-readable error message from error code."""
    return HelpData.ERROR_CODES.get(code, f"Unknown error (code: {code})")

