#!/usr/bin/env python3
"""
vint_tool.py - Combined Saints Row 2 vint_doc Decoder & Encoder
PySide6 GUI version - FIXED IMPORTS
"""

from __future__ import annotations

import os
import struct
import sys
import traceback
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional

# FIXED: QAction is in QtGui, not QtWidgets in PySide6 6.x
try:
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QLabel, QLineEdit, QPushButton, QTextEdit, QCheckBox,
        QFileDialog, QGroupBox, QMenuBar, QTabWidget, QDialog
    )
    from PySide6.QtGui import QAction, QColor, QPalette
    from PySide6.QtCore import Qt, Signal, QThread
except ImportError as e:
    print(f"PySide6 import failed: {e}")
    print(f"Python path: {sys.executable}")
    print(f"Try: {sys.executable} -m pip install --user PySide6")
    sys.exit(1)

# ============================================================================
# CONSTANTS
# ============================================================================

INPUT_DEC_EXT = ".vint_doc"
OUTPUT_DEC_EXT = ".vint_xdoc"
INPUT_ENC_EXT = [".vint_xdoc", ".xml"]
OUTPUT_ENC_EXT = ".vint_doc"
VINT_MAGIC = 0x3027
SUPPORTED_DOCUMENT_TYPE = 1

BG_COLOR = "#000000"
FG_COLOR = "#00FF90"
PURPLE_COLOR = "#6A0DAD"

_PROPERTY_NAME_TABLE = [
    "render_mode", "visible", "mask", "offset", "anchor", "tint", "alpha",
    "depth", "screen_size", "screen_nw", "screen_se", "rotation", "scale",
    "auto_offset", "unscaled_size", "screen_size", "screen_se", "screen_nw",
    "offset", "start_time", "is_paused", "target_handle", "target_handle",
    "target_name", "target_property", "state", "start_time", "duration",
    "start_value", "end_value", "loop_mode", "algorithm", "max_loops",
    "start_event", "end_event", "per_frame_event", "start_value_type",
    "end_value_type", "custom_source_coords", "image", "image_crc",
    "source_nw", "source_se", "gradient_nw", "gradient_ne", "gradient_sw",
    "gradient_se", "alpha_nw", "alpha_ne", "alpha_sw", "alpha_se", "font",
    "text_tag", "text_tag_crc", "text_scale", "word_wrap", "wrap_width",
    "vert_align", "horz_align", "force_case", "leading", "insert_values",
    "screen_size", "line_frame_enable", "line_frame_w", "line_frame_m",
    "line_frame_e", "screen_size", "clip_size", "clip_enabled", "image",
    "screen_size", "source_nw", "source_se", "start_angle", "end_angle",
    "num_wedges", "zoom", "map_mode", "vid_id_handle",
]

# ============================================================================
# CRC32
# ============================================================================

def _build_crc_table(polynomial=0xEDB88320):
    table = []
    for i in range(256):
        c = i
        for _ in range(8):
            c = (c >> 1) ^ polynomial if c & 1 else c >> 1
        table.append(c)
    return table

_CRC_TABLE = _build_crc_table()

def key_crc32(text):
    crc = 0
    for b in text.lower().encode("ascii"):
        crc = (crc >> 8) ^ _CRC_TABLE[(crc ^ b) & 0xFF]
    return crc & 0xFFFFFFFF

_PROPERTY_HASH_TO_NAME = {key_crc32(n): n for n in _PROPERTY_NAME_TABLE}
_PROPERTY_NAME_TO_HASH = {n: key_crc32(n) for n in _PROPERTY_NAME_TABLE}

def lookup_property_name(prop_hash):
    name = _PROPERTY_HASH_TO_NAME.get(prop_hash)
    if name is not None:
        return name, True
    return f"(unknown property : 0x{prop_hash:08X})", False

def get_property_hash(name):
    if name in _PROPERTY_NAME_TO_HASH:
        return _PROPERTY_NAME_TO_HASH[name], True
    h = key_crc32(name)
    return h, False

# ============================================================================
# EXCEPTIONS
# ============================================================================

class VintDocError(Exception): pass
class NotAVintDocFileError(VintDocError): pass
class UnsupportedVintDocVersionError(VintDocError): pass
class CorruptVintDocError(VintDocError): pass

# ============================================================================
# BINARY READER (DECODER)
# ============================================================================

class ByteReader:
    __slots__ = ("data", "pos")

    def __init__(self, data):
        self.data = data
        self.pos = 0

    def read(self, n):
        if n < 0 or self.pos + n > len(self.data):
            raise CorruptVintDocError("Unexpected end of file")
        b = self.data[self.pos:self.pos + n]
        self.pos += n
        return b

    def u8(self): return self.read(1)[0]
    def u16(self): return struct.unpack("<H", self.read(2))[0]
    def u32(self): return struct.unpack("<I", self.read(4))[0]
    def s32(self): return struct.unpack("<i", self.read(4))[0]
    def f32(self): return struct.unpack("<f", self.read(4))[0]

    @staticmethod
    def asciiz(buf, offset):
        end = buf.find(0, offset)
        if end < 0: end = len(buf)
        return buf[offset:end].decode("ascii", errors="replace")

class VintProperty:
    __slots__ = ("tag", "text")
    def __init__(self, tag, text):
        self.tag = tag
        self.text = text

class VintObject:
    def __init__(self):
        self.name = ""
        self.type = ""
        self.baseline = {}
        self.overrides = {}
        self.children = []

    @classmethod
    def parse(cls, r, vint):
        o = cls()
        o.name = vint.get_string(r.s32())
        o.type = vint.get_string(r.s32())
        child_count = r.u16()
        r.u8()
        r.u32()

        if r.u8() > 0:
            override_name = vint.get_string(r.s32())
            r.u32()
            if override_name in o.overrides:
                vint.warn(f"duplicate override name '{override_name}' on object '{o.name}'")
            o.overrides[override_name] = _read_properties(r, vint, o)

        o.baseline = _read_properties(r, vint, o)

        for _ in range(child_count):
            o.children.append(cls.parse(r, vint))
        return o

    def to_xml(self, parent):
        obj = ET.SubElement(parent, "object")
        ET.SubElement(obj, "name").text = self.name
        ET.SubElement(obj, "type").text = self.type

        baseline = ET.SubElement(obj, "baseline")
        for name, prop in self.baseline.items():
            _property_to_xml(baseline, name, prop)

        overrides = ET.SubElement(obj, "overrides")
        for res_name, props in self.overrides.items():
            res = ET.SubElement(overrides, "resolution")
            ET.SubElement(res, "name").text = res_name
            for name, prop in props.items():
                _property_to_xml(res, name, prop)

        children = ET.SubElement(obj, "children")
        for child in self.children:
            child.to_xml(children)

def _read_properties(r, vint, owner):
    props = {}
    while True:
        prop_type = r.u8()
        if prop_type == 0: break
        prop_hash = r.u32()
        name, known = lookup_property_name(prop_hash)
        if not known:
            vint.warn(f"unknown property hash 0x{prop_hash:08X} on object '{owner.name}'")
        if name in props:
            vint.warn(f"duplicate property '{name}' on object '{owner.name}'")
        props[name] = _read_value(r, prop_type, vint)
    return props

def _read_value(r, prop_type, vint):
    if prop_type == 1: return VintProperty("int", str(r.s32()))
    elif prop_type == 2: return VintProperty("uint", str(r.u32()))
    elif prop_type == 3: return VintProperty("float", str(r.f32()))
    elif prop_type == 4: return VintProperty("string", vint.get_string(r.s32()))
    elif prop_type == 5: return VintProperty("bool", "true" if r.u8() > 0 else "false")
    elif prop_type == 6:
        vals = (r.f32(), r.f32(), r.f32())
        return VintProperty("color", ",".join(str(v) for v in vals))
    elif prop_type == 7:
        vals = (r.f32(), r.f32())
        return VintProperty("vector2f", ",".join(str(v) for v in vals))
    raise CorruptVintDocError(f"Unknown property type byte {prop_type}")

def _property_to_xml(parent, name, prop):
    p = ET.SubElement(parent, "property")
    ET.SubElement(p, "name").text = name
    ET.SubElement(p, "type").text = prop.tag
    ET.SubElement(p, "value").text = prop.text

class VintFile:
    def __init__(self):
        self.document_type = 1
        self.animation_time = 0.0
        self.name = ""
        self.critical_resources = []
        self.metadata = {}
        self.strings = []
        self.elements = []
        self.animations = []
        self.warnings = []

    def warn(self, message):
        if message not in self.warnings:
            self.warnings.append(message)

    def get_string(self, index):
        if index < 0 or index >= len(self.strings):
            raise CorruptVintDocError(f"String index {index} out of range")
        return self.strings[index]

    @classmethod
    def parse(cls, data):
        v = cls()
        r = ByteReader(data)

        if r.u32() != VINT_MAGIC:
            raise NotAVintDocFileError("Not a vint_doc file (bad magic)")
        name_index = r.s32()
        v.document_type = r.u16()
        if v.document_type != SUPPORTED_DOCUMENT_TYPE:
            raise UnsupportedVintDocVersionError(f"Unsupported vint_doc version {v.document_type}")
        v.animation_time = r.f32()
        metadata_count = r.u32()
        critical_resource_count = r.u32()
        v._read_strings(r, r.u32())
        element_count = r.u16()
        animation_count = r.u16()

        if name_index != 0:
            raise CorruptVintDocError(f"Unexpected name index {name_index}")

        v.name = v.strings[name_index]

        for _ in range(critical_resource_count):
            unk1 = r.u8()
            index = r.s32()
            if unk1 == 0:
                v.critical_resources.append(v.get_string(index))

        for _ in range(metadata_count):
            key = r.s32()
            value = r.s32()
            v.metadata[v.get_string(key)] = v.get_string(value)

        v.elements = [VintObject.parse(r, v) for _ in range(element_count)]
        v.animations = [VintObject.parse(r, v) for _ in range(animation_count)]
        return v

    def _read_strings(self, r, offset):
        saved_pos = r.pos
        r.pos = offset
        count = r.u32()
        buffer_size = r.u32()
        if count > 0x100000 or buffer_size > 0x8000000:
            raise CorruptVintDocError("Implausible string table sizes")
        index_buffer = r.read(count * 4)
        string_buffer = r.read(buffer_size)
        offsets = struct.unpack(f"<{count}I", index_buffer) if count else ()
        r.pos = saved_pos
        self.strings = [ByteReader.asciiz(string_buffer, off) for off in offsets]

    def to_xml(self):
        root = ET.Element("root")
        ET.SubElement(root, "vint_doc_type").text = "vint_document"
        ET.SubElement(root, "name").text = os.path.splitext(self.name)[0] + OUTPUT_DEC_EXT
        ET.SubElement(root, "vint_doc_version").text = "2"
        ET.SubElement(root, "anim_time").text = str(self.animation_time)

        metadata_el = ET.SubElement(root, "metadata")
        for key, value in self.metadata.items():
            item = ET.SubElement(metadata_el, "metadata_item")
            ET.SubElement(item, "name").text = key
            ET.SubElement(item, "value").text = value

        crit = ET.SubElement(root, "critical_resources")
        pegs = ET.SubElement(crit, "pegs")
        for filename in self.critical_resources:
            ET.SubElement(pegs, "filename").text = filename

        elements_el = ET.SubElement(root, "elements")
        for element in self.elements:
            element.to_xml(elements_el)

        animations_el = ET.SubElement(root, "animations")
        for animation in self.animations:
            animation.to_xml(animations_el)

        return root

# ============================================================================
# BINARY WRITER (ENCODER)
# ============================================================================

class BinaryWriter:
    def __init__(self):
        self.buffer = bytearray()

    def write_bytes(self, data): self.buffer.extend(data)
    def write_u8(self, v): self.buffer.append(v & 0xFF)
    def write_u16(self, v): self.buffer.extend(struct.pack("<H", v))
    def write_u32(self, v): self.buffer.extend(struct.pack("<I", v))
    def write_s32(self, v): self.buffer.extend(struct.pack("<i", v))
    def write_f32(self, v): self.buffer.extend(struct.pack("<f", v))
    def to_bytes(self): return bytes(self.buffer)

class VintXDocEncoder:
    def __init__(self):
        self.strings = []
        self.string_to_idx = {}
        self.w = BinaryWriter()
        self.unknown_hashes = set()
        self.string_table_offset_pos = 0

    def add_string(self, s):
        if s in self.string_to_idx: return self.string_to_idx[s]
        idx = len(self.strings)
        self.strings.append(s)
        self.string_to_idx[s] = idx
        return idx

    def parse_and_encode(self, xml_path):
        tree = ET.parse(xml_path)
        root = tree.getroot()
        self._collect_strings(root)

        header_start = len(self.w.buffer)
        self._write_header_placeholder(root)
        self._write_metadata(root)
        self._write_critical_resources(root)
        string_table_offset = len(self.w.buffer)
        self._write_string_table()
        self._write_elements(root)
        self._write_animations(root)
        self._patch_string_table_offset(header_start, string_table_offset)

        return self.w.to_bytes()

    def _collect_strings(self, root):
        name_elem = root.find("name")
        if name_elem is not None and name_elem.text:
            self.add_string(name_elem.text)
        for item in root.findall(".//metadata_item"):
            name_el = item.find("name")
            val_el = item.find("value")
            if name_el is not None and name_el.text:
                self.add_string(name_el.text)
            if val_el is not None and val_el.text:
                self.add_string(val_el.text)
        for fname in root.findall(".//filename"):
            if fname.text: self.add_string(fname.text)
        for obj in root.findall(".//object"):
            self._collect_object_strings(obj)

    def _collect_object_strings(self, obj):
        name_el = obj.find("name")
        type_el = obj.find("type")
        if name_el is not None and name_el.text:
            self.add_string(name_el.text)
        if type_el is not None and type_el.text:
            self.add_string(type_el.text)
        baseline = obj.find("baseline")
        if baseline is not None:
            for prop in baseline.findall("property"):
                self._collect_property_string(prop)
        overrides = obj.find("overrides")
        if overrides is not None:
            for res in overrides.findall("resolution"):
                res_name = res.find("name")
                if res_name is not None and res_name.text:
                    self.add_string(res_name.text)
                for prop in res.findall("property"):
                    self._collect_property_string(prop)
        children = obj.find("children")
        if children is not None:
            for child in children.findall("object"):
                self._collect_object_strings(child)

    def _collect_property_string(self, prop):
        val_el = prop.find("value")
        if val_el is not None and val_el.text:
            self.add_string(val_el.text)

    def _write_header_placeholder(self, root):
        anim_time_elem = root.find("anim_time")
        anim_time = float(anim_time_elem.text) if anim_time_elem is not None else 0.0
        self.w.write_u32(VINT_MAGIC)
        self.w.write_s32(0)
        self.w.write_u16(SUPPORTED_DOCUMENT_TYPE)
        self.w.write_f32(anim_time)
        metadata_items = root.findall(".//metadata_item")
        self.w.write_u32(len(metadata_items))
        critical_res = root.findall(".//filename")
        self.w.write_u32(len(critical_res))
        self.string_table_offset_pos = len(self.w.buffer)
        self.w.write_u32(0)
        elements_el = root.find("elements")
        if elements_el is not None:
            top_level = elements_el.findall("object")
            self.w.write_u16(len(top_level))
        else:
            self.w.write_u16(0)
        animations_el = root.find("animations")
        if animations_el is not None:
            anim_list = animations_el.findall("object")
            self.w.write_u16(len(anim_list))
        else:
            self.w.write_u16(0)

    def _write_metadata(self, root):
        for item in root.findall(".//metadata_item"):
            name_el = item.find("name")
            val_el = item.find("value")
            if name_el is not None and val_el is not None:
                self.w.write_s32(self.add_string(name_el.text))
                self.w.write_s32(self.add_string(val_el.text))

    def _write_critical_resources(self, root):
        for fname in root.findall(".//filename"):
            if fname.text:
                self.w.write_u8(0)
                self.w.write_s32(self.add_string(fname.text))

    def _write_string_table(self):
        buffer_size = sum(len(s.encode("ascii")) + 1 for s in self.strings)
        self.w.write_u32(len(self.strings))
        self.w.write_u32(buffer_size)
        index_buffer = bytearray()
        string_data = bytearray()
        current_offset = 0
        for s in self.strings:
            encoded = s.encode("ascii") + b"\x00"
            index_buffer.extend(struct.pack("<I", current_offset))
            string_data.extend(encoded)
            current_offset += len(encoded)
        self.w.write_bytes(index_buffer)
        self.w.write_bytes(string_data)

    def _write_elements(self, root):
        elements_el = root.find("elements")
        if elements_el is None:
            self.w.write_u16(0)
            return
        top_level = elements_el.findall("object")
        self.w.write_u16(len(top_level))
        for elem in top_level:
            self._write_object(elem)

    def _write_object(self, obj):
        name_el = obj.find("name")
        type_el = obj.find("type")
        name_idx = self.add_string(name_el.text) if name_el is not None and name_el.text else 0
        type_idx = self.add_string(type_el.text) if type_el is not None and type_el.text else 0
        self.w.write_s32(name_idx)
        self.w.write_s32(type_idx)
        children_el = obj.find("children")
        child_list = children_el.findall("object") if children_el is not None else []
        self.w.write_u16(len(child_list))
        self.w.write_u8(0)
        self.w.write_u32(0)
        overrides_el = obj.find("overrides")
        override_exists = False
        override_name_idx = 0
        if overrides_el is not None:
            resolution = overrides_el.find("resolution")
            if resolution is not None:
                res_name = resolution.find("name")
                if res_name is not None and res_name.text:
                    override_exists = True
                    override_name_idx = self.add_string(res_name.text)
        if override_exists:
            self.w.write_u8(1)
            self.w.write_s32(override_name_idx)
            self.w.write_u32(0)
            self._write_properties(resolution)
        baseline = obj.find("baseline")
        self._write_properties(baseline)
        for child in child_list:
            self._write_object(child)

    def _write_properties(self, props_el):
        if props_el is None:
            self.w.write_u8(0)
            return
        for prop in props_el.findall("property"):
            name_el = prop.find("name")
            type_el = prop.find("type")
            val_el = prop.find("value")
            if name_el is None or type_el is None or val_el is None: continue
            prop_name = name_el.text
            prop_type = type_el.text
            prop_value = val_el.text
            prop_hash, is_known = get_property_hash(prop_name)
            if not is_known:
                self.unknown_hashes.add((prop_name, prop_hash))
            type_byte = self._get_type_byte(prop_type)
            self.w.write_u8(type_byte)
            self.w.write_u32(prop_hash)
            self._write_value(type_byte, prop_value)
        self.w.write_u8(0)

    def _get_type_byte(self, prop_type):
        type_map = {"int": 1, "uint": 2, "float": 3, "string": 4, "bool": 5, "color": 6, "vector2f": 7}
        return type_map.get(prop_type, 1)

    def _write_value(self, type_byte, value_str):
        if type_byte == 1: self.w.write_s32(int(value_str))
        elif type_byte == 2: self.w.write_u32(int(value_str))
        elif type_byte == 3: self.w.write_f32(float(value_str))
        elif type_byte == 4:
            self.w.write_s32(self.add_string(value_str))
        elif type_byte == 5:
            self.w.write_u8(1 if value_str.lower() == "true" else 0)
        elif type_byte == 6:
            parts = [float(x.strip()) for x in value_str.split(",")]
            if len(parts) >= 3:
                self.w.write_f32(parts[0])
                self.w.write_f32(parts[1])
                self.w.write_f32(parts[2])
        elif type_byte == 7:
            parts = [float(x.strip()) for x in value_str.split(",")]
            if len(parts) >= 2:
                self.w.write_f32(parts[0])
                self.w.write_f32(parts[1])

    def _write_animations(self, root):
        animations_el = root.find("animations")
        if animations_el is None:
            self.w.write_u16(0)
            return
        anim_list = animations_el.findall("object")
        self.w.write_u16(len(anim_list))
        for anim in anim_list:
            self._write_object(anim)

    def _patch_string_table_offset(self, header_start, string_table_offset):
        if hasattr(self, 'string_table_offset_pos') and self.string_table_offset_pos > 0:
            self.w.buffer[self.string_table_offset_pos:self.string_table_offset_pos + 4] = \
                struct.pack("<I", string_table_offset)

# ============================================================================
# CONVERSION FUNCTIONS
# ============================================================================

def find_files(directory, recursive, extension):
    pattern = "*" + extension
    iterator = directory.rglob(pattern) if recursive else directory.glob(pattern)
    return sorted(p for p in iterator if p.is_file() and p.suffix.lower() == extension.lower())

def convert_decode(src, dst, overwrite, report):
    if dst.exists() and not overwrite:
        report(f"SKIP   {dst.name} already exists")
        return "skipped"
    try:
        with open(src, "rb") as fh: data = fh.read()
    except OSError as e:
        report(f"ERROR  cannot read {src}: {e}")
        return "error"
    try:
        vint = VintFile.parse(data)
    except VintDocError as e:
        report(f"ERROR  {src.name}: {e}")
        return "error"
    except Exception:
        report(f"ERROR  {src.name}: unexpected failure\n{traceback.format_exc()}")
        return "error"
    for w in vint.warnings:
        report(f"WARN   {src.name}: {w}")
    try:
        tree = ET.ElementTree(vint.to_xml())
        ET.indent(tree, space="  ")
        dst.parent.mkdir(parents=True, exist_ok=True)
        with open(dst, "wb") as fh:
            tree.write(fh, encoding="utf-8", xml_declaration=True)
    except OSError as e:
        report(f"ERROR  cannot write {dst}: {e}")
        return "error"
    report(f"OK     {src.name} -> {dst}")
    return "ok"

def convert_encode(src, dst, overwrite, report):
    if dst.exists() and not overwrite:
        report(f"SKIP   {dst.name} already exists")
        return "skipped"
    try:
        encoder = VintXDocEncoder()
        binary_data = encoder.parse_and_encode(str(src))
        dst.parent.mkdir(parents=True, exist_ok=True)
        with open(dst, "wb") as f:
            f.write(binary_data)
        report(f"OK     {src.name} -> {dst}")
        if encoder.unknown_hashes:
            for name, h in encoder.unknown_hashes:
                report(f"WARN   unknown property {name} (hash 0x{h:08X})")
        return "ok"
    except Exception as e:
        report(f"ERROR  {src.name}: {e}\n{traceback.format_exc()}")
        return "error"

def convert_directory(mode, input_dir, output_dir, recursive, overwrite, report):
    directory = Path(input_dir).expanduser()
    if not directory.is_dir():
        report(f"ERROR  input directory not found: {directory}")
        return 0, 0, 1
    out_dir = Path(output_dir).expanduser() if output_dir else directory
    if not out_dir.is_dir():
        report(f"ERROR  output directory not found: {out_dir}")
        return 0, 0, 1

    ext = INPUT_DEC_EXT if mode == "decode" else INPUT_ENC_EXT[0]
    files = find_files(directory, recursive, ext)
    if not files:
        report(f"No *{ext} files found in {directory}")
        return 0, 0, 0

    report(f"Found {len(files)} file(s) to {'decode' if mode == 'decode' else 'encode'}.\n")
    converted = skipped = errors = 0
    for src in files:
        rel = src.relative_to(directory)
        if mode == "decode":
            dst = (out_dir / rel).with_suffix(OUTPUT_DEC_EXT)
            result = convert_decode(src, dst, overwrite, report)
        else:
            dst = (out_dir / rel).with_suffix(OUTPUT_ENC_EXT)
            result = convert_encode(src, dst, overwrite, report)
        if result == "ok": converted += 1
        elif result == "skipped": skipped += 1
        else: errors += 1
    report(f"\nDone. Converted: {converted}, skipped: {skipped}, errors: {errors}")
    return converted, skipped, errors

# ============================================================================
# WORKER THREAD
# ============================================================================

class ConversionWorker(QThread):
    finished_signal = Signal(tuple)
    
    def __init__(self, mode, input_dir, output_dir, recursive, overwrite):
        super().__init__()
        self.mode = mode
        self.input_dir = input_dir
        self.output_dir = output_dir
        self.recursive = recursive
        self.overwrite = overwrite
        self.messages = []

    def run(self):
        def report(msg): self.messages.append(msg)
        try:
            result = convert_directory(self.mode, self.input_dir, self.output_dir,
                                       self.recursive, self.overwrite, report)
            self.messages.append("__DONE__")
            self.finished_signal.emit((result, self.messages))
        except Exception as e:
            self.messages.append(f"INTERNAL ERROR:\n{traceback.format_exc()}")
            self.messages.append("__DONE__")
            self.finished_signal.emit((None, self.messages))

# ============================================================================
# GUI
# ============================================================================

CHANGES_TEXT = """\
LIST OF CHANGES MADE TO THE CODE
================================

1. Argument bug in Main() fixed
2. Overwrite check now works properly
3. Exception hierarchy fixed
4. CRC32 HashCore bug fixed
5. Unknown property hash crashes fixed
6. Duplicate property handling improved
7. File stream cleanup improved
8. Added recursive search and separate output dir
"""

ERRORS_TEXT = """\
ERRORS AND THEIR MEANINGS
=========================

"Not a vint_doc file (bad magic)"
    First 4 bytes are not 0x3027. Wrong file type.

"Unsupported vint_doc version N"
    Document type field is not 1.

"Unexpected end of file"
    File truncated or corrupt.

"String index N out of range"
    String-table reference outside table.

"Unknown property type byte N"
    Property type was not 1-7.

WARNINGS:
"unknown property hash 0x........" - CRC not in lookup table.
"duplicate property 'name'" - Same property twice, last kept.
"""

TUTORIAL_TEXT = """\
TUTORIAL: SAINTS ROW 2 UI DOCUMENTS
==================================

DECODING (vint_doc -> vint_xdoc):
1. Select DECODE tab
2. Browse to folder with .vint_doc files
3. Choose output folder
4. Click CONVERT

ENCODING (vint_xdoc -> vint_doc):
1. Select ENCODE tab
2. Browse to folder with .vint_xdoc or .xml files
3. Choose output folder
4. Click CONVERT
"""

ACK_TEXT = """\
ACKNOWLEDGEMENTS
================

Thanks to Rick (Gibbed) for GibbedTools.
Thanks to Thomas Jepp for Jepp Tools.

This is a community fan/modding tool.
"""

class VintGui(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SR2 vint_doc Converter (Decoder + Encoder)")
        self.resize(900, 700)
        self.converting = False
        self.worker = None
        self._setup_ui()

    def _setup_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        tabs = QTabWidget()
        decode_tab = self._create_decode_tab()
        encode_tab = self._create_encode_tab()
        tabs.addTab(decode_tab, "Decode (.vint_doc -> .vint_xdoc)")
        tabs.addTab(encode_tab, "Encode (.vint_xdoc/.xml -> .vint_doc)")
        layout.addWidget(tabs)

        log_label = QLabel("Conversion Log:")
        log_label.setStyleSheet(f"color: {FG_COLOR}; font-weight: bold;")
        layout.addWidget(log_label)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setStyleSheet(
            f"background-color: {BG_COLOR}; color: {FG_COLOR}; "
            f"selection-background-color: {PURPLE_COLOR}; "
            f"selection-color: {FG_COLOR};"
        )
        layout.addWidget(self.log)

        self.status_label = QLabel("Ready.")
        self.status_label.setStyleSheet(f"color: {FG_COLOR};")
        layout.addWidget(self.status_label)

        self._setup_menu()

    def _create_base_options(self, layout):
        input_label = QLabel("Input directory:")
        input_label.setStyleSheet(f"color: {FG_COLOR};")
        input_line = QLineEdit()
        input_line.setStyleSheet(
            f"background-color: {BG_COLOR}; color: {FG_COLOR}; "
            f"selection-background-color: {PURPLE_COLOR};"
        )
        browse_btn = QPushButton("Browse...")
        browse_btn.setStyleSheet(
            f"background-color: {PURPLE_COLOR}; color: {FG_COLOR};"
        )
        browse_btn.clicked.connect(lambda: self._browse_dir(input_line))

        opt_h = QHBoxLayout()
        opt_h.addWidget(input_label)
        opt_h.addWidget(input_line, 1)
        opt_h.addWidget(browse_btn)
        layout.addLayout(opt_h)

        output_label = QLabel("Output directory:")
        output_label.setStyleSheet(f"color: {FG_COLOR};")
        output_line = QLineEdit()
        output_line.setStyleSheet(
            f"background-color: {BG_COLOR}; color: {FG_COLOR}; "
            f"selection-background-color: {PURPLE_COLOR};"
        )
        output_browse_btn = QPushButton("Browse...")
        output_browse_btn.setStyleSheet(
            f"background-color: {PURPLE_COLOR}; color: {FG_COLOR};"
        )
        output_browse_btn.clicked.connect(lambda: self._browse_dir(output_line))

        opt_h2 = QHBoxLayout()
        opt_h2.addWidget(output_label)
        opt_h2.addWidget(output_line, 1)
        opt_h2.addWidget(output_browse_btn)
        layout.addLayout(opt_h2)

        output_empty = QLabel("(empty = same as input)")
        output_empty.setStyleSheet(f"color: {FG_COLOR};")
        layout.addWidget(output_empty)

        opts_group = QGroupBox("Options")
        opts_group.setStyleSheet(f"color: {FG_COLOR};")
        opts_layout = opts_group.layout() or QHBoxLayout(opts_group)

        self.recursive_check = QCheckBox("Search subdirectories")
        self.recursive_check.setStyleSheet(f"color: {FG_COLOR};")
        opts_layout.addWidget(self.recursive_check)

        self.overwrite_check = QCheckBox("Overwrite existing files")
        self.overwrite_check.setStyleSheet(f"color: {FG_COLOR};")
        opts_layout.addWidget(self.overwrite_check)

        layout.addWidget(opts_group)

        return input_line, output_line

    def _create_decode_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        self.dec_input, self.dec_output = self._create_base_options(layout)
        convert_btn = QPushButton("CONVERT (Decode)")
        convert_btn.setStyleSheet(
            f"background-color: {PURPLE_COLOR}; color: {FG_COLOR}; "
            f"font-size: 14px; font-weight: bold;"
        )
        convert_btn.clicked.connect(self._start_decode)
        layout.addWidget(convert_btn)
        return widget

    def _create_encode_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        self.enc_input, self.enc_output = self._create_base_options(layout)
        convert_btn = QPushButton("CONVERT (Encode)")
        convert_btn.setStyleSheet(
            f"background-color: {PURPLE_COLOR}; color: {FG_COLOR}; "
            f"font-size: 14px; font-weight: bold;"
        )
        convert_btn.clicked.connect(self._start_encode)
        layout.addWidget(convert_btn)
        return widget

    def _setup_menu(self):
        menubar = self.menuBar()
        file_menu = menubar.addMenu("File")
        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        help_menu = menubar.addMenu("Help")
        for label, text in [("Changes", CHANGES_TEXT), ("Errors", ERRORS_TEXT),
                            ("Tutorial", TUTORIAL_TEXT), ("Acknowledgements", ACK_TEXT)]:
            action = QAction(label, self)
            action.triggered.connect(lambda checked, t=text, l=label: self._show_help(l, t))
            help_menu.addAction(action)

    def _browse_dir(self, line):
        d = QFileDialog.getExistingDirectory(self, "Choose directory")
        if d: line.setText(d)

    def _start_decode(self):
        self._start_conversion("decode", self.dec_input.text(), self.dec_output.text())

    def _start_encode(self):
        self._start_conversion("encode", self.enc_input.text(), self.enc_output.text())

    def _start_conversion(self, mode, input_dir, output_dir):
        if self.converting: return
        if not input_dir.strip():
            QMessageBox.warning(self, "Missing input", "Please choose an input directory first.")
            return
        if not Path(input_dir).expanduser().is_dir():
            QMessageBox.warning(self, "Bad input", f"Directory not found:\n{input_dir}")
            return

        self.converting = True
        self.status_label.setText("Converting...")

        self.worker = ConversionWorker(mode, input_dir, output_dir,
                                       self.recursive_check.isChecked(),
                                       self.overwrite_check.isChecked())
        self.worker.finished_signal.connect(self._on_conversion_done)
        self.worker.start()

    def _on_conversion_done(self, result):
        messages = result[1] if result else ["Internal error occurred."]
        for msg in messages:
            if msg == "__DONE__":
                self.converting = False
                self.status_label.setText("Ready.")
                continue
            self.log.append(msg)

    def _show_help(self, title, text):
        win = QDialog(self)
        win.setWindowTitle(f"Help - {title}")
        win.resize(720, 520)
        win.setStyleSheet(f"background-color: {BG_COLOR};")
        layout = QVBoxLayout(win)
        txt = QTextEdit()
        txt.setReadOnly(True)
        txt.setPlainText(text)
        txt.setStyleSheet(
            f"background-color: {BG_COLOR}; color: {FG_COLOR}; "
            f"selection-background-color: {PURPLE_COLOR};"
        )
        layout.addWidget(txt)
        close_btn = QPushButton("Close")
        close_btn.setStyleSheet(f"background-color: {PURPLE_COLOR}; color: {FG_COLOR};")
        close_btn.clicked.connect(win.close)
        win.exec()

def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')

    palette = QPalette()
    palette.setColor(QPalette.Window, QColor(BG_COLOR))
    palette.setColor(QPalette.WindowText, QColor(FG_COLOR))
    palette.setColor(QPalette.Base, QColor(BG_COLOR))
    palette.setColor(QPalette.AlternateBase, QColor(BG_COLOR))
    palette.setColor(QPalette.Text, QColor(FG_COLOR))
    palette.setColor(QPalette.Button, QColor(PURPLE_COLOR))
    palette.setColor(QPalette.ButtonText, QColor(FG_COLOR))
    palette.setColor(QPalette.Highlight, QColor(PURPLE_COLOR))
    palette.setColor(QPalette.HighlightedText, QColor(FG_COLOR))
    app.setPalette(palette)

    win = VintGui()
    win.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
