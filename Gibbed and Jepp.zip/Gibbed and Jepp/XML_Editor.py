from __future__ import annotations

import json
import sys
import xml.etree.ElementTree as ET
from dataclasses import asdict, dataclass
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QFileDialog,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSplitter,
    QTabWidget,
    QTextEdit,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QHBoxLayout,
    QWidget,
)


# ---------------------------------------------------------------------
# Colors
# ---------------------------------------------------------------------

BACKGROUND = "#000000"
PANEL = "#050505"
TEXT = "#00CC78"
PURPLE = "#4B0082"
PURPLE_HOVER = "#351060"
PURPLE_DARK = "#260040"
SELECTION = "#301050"
BORDER = "#202020"
DISABLED = "#405040"


SUPPORTED_TYPES = {
    "String",
    "Int",
    "Float",
    "Vector",
    "Color",
    "Reference",
    "Filename",
    "Flags",
    "List",
    "ComboElement",
    "Selection",
    "Element",
    "Grid",
}


# ---------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------

@dataclass
class TableElement:
    name: str
    element_type: str
    attributes: dict[str, str]
    children: list[dict]


@dataclass
class TableDescription:
    name: str
    source: str
    attributes: dict[str, str]
    elements: list[TableElement]


# ---------------------------------------------------------------------
# XML parser
# ---------------------------------------------------------------------

class XmlTableParser:
    def __init__(self, require_empty_source: bool = True):
        self.require_empty_source = require_empty_source
        self.errors: list[str] = []
        self.warnings: list[str] = []

    @staticmethod
    def get_text(parent: ET.Element, tag: str) -> str | None:
        node = parent.find(tag)

        if node is None or node.text is None:
            return None

        return node.text.strip()

    @staticmethod
    def get_child_data(element: ET.Element) -> list[dict]:
        result = []

        for child in list(element):
            result.append(
                {
                    "tag": child.tag,
                    "text": (child.text or "").strip(),
                    "attributes": dict(child.attrib),
                }
            )

        return result

    def read_element(self, element: ET.Element) -> TableElement | None:
        name = self.get_text(element, "Name")
        element_type = self.get_text(element, "Type")

        if not name:
            self.errors.append(
                "An Element is missing a non-empty <Name> value."
            )
            return None

        if not element_type:
            self.errors.append(
                f"Element '{name}' is missing a non-empty <Type> value."
            )
            return None

        if element_type not in SUPPORTED_TYPES:
            self.errors.append(
                f"Element '{name}' has unknown type '{element_type}'."
            )
            return None

        return TableElement(
            name=name,
            element_type=element_type,
            attributes=dict(element.attrib),
            children=self.get_child_data(element),
        )

    def parse(self, filename: str) -> list[TableDescription]:
        self.errors.clear()
        self.warnings.clear()

        try:
            tree = ET.parse(filename)
        except FileNotFoundError:
            self.errors.append(f"File not found: {filename}")
            return []
        except ET.ParseError as error:
            self.errors.append(f"Invalid XML: {error}")
            return []
        except OSError as error:
            self.errors.append(f"Could not open file: {error}")
            return []

        root = tree.getroot()

        nodes = []

        if root.tag == "TableDescription":
            nodes.append(root)

        nodes.extend(root.findall(".//TableDescription"))

        descriptions = []
        seen_ids = set()

        for node in nodes:
            if id(node) in seen_ids:
                continue

            seen_ids.add(id(node))

            source = node.attrib.get("source", "")

            if self.require_empty_source and source != "":
                table_name = self.get_text(node, "Name") or "(unnamed)"
                self.warnings.append(
                    f"Skipped '{table_name}' because source='{source}'."
                )
                continue

            name = self.get_text(node, "Name")
            table_type = self.get_text(node, "Type")

            if not name:
                self.errors.append(
                    "A TableDescription is missing a non-empty <Name>."
                )
                continue

            if table_type != "TableDescription":
                self.errors.append(
                    f"TableDescription '{name}' has invalid Type "
                    f"'{table_type}'. Expected 'TableDescription'."
                )
                continue

            elements = []

            for child in node.findall("Element"):
                parsed = self.read_element(child)

                if parsed is not None:
                    elements.append(parsed)

            descriptions.append(
                TableDescription(
                    name=name,
                    source=source,
                    attributes=dict(node.attrib),
                    elements=elements,
                )
            )

        if not nodes:
            self.errors.append(
                "No <TableDescription> element was found."
            )

        return descriptions


# ---------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------

class XmlTableWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle(
            "Gibbed Saints Row 2 XML Table Inspector"
        )
        self.resize(1200, 750)

        self.descriptions: list[TableDescription] = []

        self.build_interface()
        self.build_menus()

    def build_interface(self):
        central = QWidget()
        central.setObjectName("centralWidget")
        self.setCentralWidget(central)

        main_layout = QVBoxLayout(central)

        file_layout = QHBoxLayout()

        file_label = QLabel("XML file:")
        self.filename_edit = QLineEdit()
        self.filename_edit.setPlaceholderText(
            "Select an XML table file..."
        )

        browse_button = QPushButton("Browse...")
        read_button = QPushButton("Read XML")

        browse_button.clicked.connect(self.open_file)
        read_button.clicked.connect(self.read_xml)

        file_layout.addWidget(file_label)
        file_layout.addWidget(self.filename_edit, 1)
        file_layout.addWidget(browse_button)
        file_layout.addWidget(read_button)

        main_layout.addLayout(file_layout)

        self.source_checkbox = QCheckBox(
            'Only process TableDescription elements with source=""'
        )
        self.source_checkbox.setChecked(True)

        main_layout.addWidget(self.source_checkbox)

        splitter = QSplitter(Qt.Orientation.Vertical)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(
            [
                "Name",
                "Type",
                "Attributes",
                "Child Nodes",
            ]
        )
        self.tree.setColumnWidth(0, 300)
        self.tree.setColumnWidth(1, 180)
        self.tree.setColumnWidth(2, 350)

        self.messages = QTextEdit()
        self.messages.setReadOnly(True)

        tabs = QTabWidget()
        tabs.addTab(self.tree, "Parsed Table")
        tabs.addTab(self.messages, "Messages")

        splitter.addWidget(tabs)
        splitter.setSizes([550, 180])

        main_layout.addWidget(splitter)

        self.statusBar().showMessage("Ready")

    def build_menus(self):
        file_menu = self.menuBar().addMenu("File")
        help_menu = self.menuBar().addMenu("Help")

        open_action = QAction("Open XML...", self)
        open_action.triggered.connect(self.open_file)
        file_menu.addAction(open_action)

        save_action = QAction("Save Report...", self)
        save_action.triggered.connect(self.save_report)
        file_menu.addAction(save_action)

        file_menu.addSeparator()

        clear_action = QAction("Clear", self)
        clear_action.triggered.connect(self.clear_output)
        file_menu.addAction(clear_action)

        file_menu.addSeparator()

        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        changes_action = QAction("Changes Made", self)
        changes_action.triggered.connect(self.show_changes)
        help_menu.addAction(changes_action)

        errors_action = QAction("Errors and Meanings", self)
        errors_action.triggered.connect(self.show_errors)
        help_menu.addAction(errors_action)

        tutorial_action = QAction("Tutorial", self)
        tutorial_action.triggered.connect(self.show_tutorial)
        help_menu.addAction(tutorial_action)

        acknowledgements_action = QAction("Acknowledgements", self)
        acknowledgements_action.triggered.connect(
            self.show_acknowledgements
        )
        help_menu.addAction(acknowledgements_action)

        help_menu.addSeparator()

        about_action = QAction("About", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    def open_file(self):
        filename, _ = QFileDialog.getOpenFileName(
            self,
            "Open XML Table",
            "",
            "XML files (*.xml);;All files (*)",
        )

        if filename:
            self.filename_edit.setText(filename)
            self.read_xml()

    def read_xml(self):
        filename = self.filename_edit.text().strip()

        if not filename:
            QMessageBox.warning(
                self,
                "No file selected",
                "Choose an XML file first.",
            )
            return

        parser = XmlTableParser(
            require_empty_source=self.source_checkbox.isChecked()
        )

        self.descriptions = parser.parse(filename)

        self.tree.clear()
        self.messages.clear()

        for description in self.descriptions:
            table_item = QTreeWidgetItem(
                [
                    description.name,
                    "TableDescription",
                    json.dumps(description.attributes),
                    str(len(description.elements)),
                ]
            )

            self.tree.addTopLevelItem(table_item)

            for element in description.elements:
                element_item = QTreeWidgetItem(
                    [
                        element.name,
                        element.element_type,
                        json.dumps(element.attributes),
                        str(len(element.children)),
                    ]
                )
                table_item.addChild(element_item)

            table_item.setExpanded(True)

        self.write_messages(parser)

        if parser.errors:
            self.statusBar().showMessage(
                f"Finished with {len(parser.errors)} error(s)"
            )
        elif parser.warnings:
            self.statusBar().showMessage(
                f"Finished with {len(parser.warnings)} warning(s)"
            )
        else:
            self.statusBar().showMessage(
                f"Read {len(self.descriptions)} table description(s)"
            )

    def write_messages(self, parser: XmlTableParser):
        output = [
            f"Table descriptions read: {len(self.descriptions)}",
            "",
        ]

        if parser.errors:
            output.append("ERRORS")
            output.append("=" * 60)

            for error in parser.errors:
                output.append(f"- {error}")

            output.append("")

        if parser.warnings:
            output.append("WARNINGS")
            output.append("=" * 60)

            for warning in parser.warnings:
                output.append(f"- {warning}")

            output.append("")

        if not parser.errors and not parser.warnings:
            output.append("No errors or warnings were reported.")

        self.messages.setPlainText("\n".join(output))

    def save_report(self):
        filename, selected_filter = QFileDialog.getSaveFileName(
            self,
            "Save Report",
            "",
            "Text files (*.txt);;JSON files (*.json);;All files (*)",
        )

        if not filename:
            return

        try:
            if filename.lower().endswith(".json"):
                data = {
                    "source_file": self.filename_edit.text(),
                    "tables": [
                        asdict(description)
                        for description in self.descriptions
                    ],
                    "messages": self.messages.toPlainText(),
                }

                Path(filename).write_text(
                    json.dumps(data, indent=2),
                    encoding="utf-8",
                )
            else:
                Path(filename).write_text(
                    self.messages.toPlainText(),
                    encoding="utf-8",
                )

            self.statusBar().showMessage(
                f"Report saved: {filename}"
            )

        except OSError as error:
            QMessageBox.critical(
                self,
                "Save failed",
                str(error),
            )

    def clear_output(self):
        self.tree.clear()
        self.messages.clear()
        self.filename_edit.clear()
        self.descriptions.clear()
        self.statusBar().showMessage("Ready")

    def show_help(self, title: str, text: str):
        dialog = QMessageBox(self)
        dialog.setWindowTitle(title)
        dialog.setText(text)
        dialog.setStandardButtons(QMessageBox.StandardButton.Close)
        dialog.exec()

    def show_changes(self):
        self.show_help(
            "Changes Made",
            """Changes made to the original C# program:

1. Rewritten using Python 3.10 and PySide6.
2. Added a complete graphical interface.
3. Added XML file browsing and loading.
4. Added validation for missing Name and Type elements.
5. Added unknown-type validation.
6. Added invalid XML and file error handling.
7. Added support for all original element types.
8. Added source attribute filtering.
9. Added a parsed table tree view.
10. Added TXT and JSON report saving.
11. Added a Help menu.
12. Applied a fixed dark theme with 15-point text.
""",
        )

    def show_errors(self):
        self.show_help(
            "Errors and Meanings",
            """No file selected
Choose an XML file before clicking Read XML.

File not found
The selected file does not exist.

Invalid XML
The XML is not correctly formatted.

No TableDescription element was found
The required XML structure is missing.

Missing Name
A TableDescription or Element does not have a valid Name.

Missing Type
A TableDescription or Element does not have a valid Type.

Unknown element type
The Type is not recognized by the original program.

Skipped because source is not empty
The source filtering option is enabled and the source attribute
contains a value.
""",
        )

    def show_tutorial(self):
        self.show_help(
            "Tutorial",
            """1. Start the program.

2. Click Browse and select an XML file.

3. Click Read XML.

4. View parsed tables and elements on the Parsed Table tab.

5. View errors and warnings on the Messages tab.

6. Disable the source option if you want to process every
   TableDescription element.

7. Use File > Save Report to save a TXT or JSON report.

Example XML:

<root>
  <TableDescription source="">
    <Name>ExampleTable</Name>
    <Type>TableDescription</Type>

    <Element>
      <Name>Health</Name>
      <Type>Int</Type>
    </Element>
  </TableDescription>
</root>
""",
        )

    def show_acknowledgements(self):
        self.show_help(
            "Acknowledgements",
            """Thanks to Rick Gibbed for GibbedTools and the original
source code that inspired this program.

Thanks also to Thomas Jepp for Jepp Tools and related modding tools.

This is an independent PySide6 rewrite of the supplied C# XML
reader. Check the original project's license before redistributing
source code or derivative work.
""",
        )

    def show_about(self):
        self.show_help(
            "About",
            """Gibbed Saints Row 2 XML Table Inspector

PySide6 rewrite of the original SerializationBuilder program.

Interface text size: 15 points
Theme: fixed dark theme
""",
        )


# ---------------------------------------------------------------------
# Application styling
# ---------------------------------------------------------------------

def apply_dark_theme(app: QApplication):
    app.setStyle("Fusion")

    app.setFont(QFont("Segoe UI", 15))

    app.setStyleSheet(
        f"""
        QWidget {{
            background-color: {BACKGROUND};
            color: {TEXT};
            font-size: 15pt;
        }}

        QMainWindow,
        QDialog,
        QFrame,
        QTabWidget::pane {{
            background-color: {BACKGROUND};
            color: {TEXT};
        }}

        QLabel,
        QCheckBox,
        QGroupBox {{
            color: {TEXT};
        }}

        QLineEdit,
        QTextEdit,
        QPlainTextEdit,
        QTreeWidget {{
            background-color: {PANEL};
            color: {TEXT};
            border: 1px solid {BORDER};
            selection-background-color: {SELECTION};
            selection-color: {TEXT};
        }}

        QPushButton {{
            background-color: {PURPLE};
            color: {TEXT};
            border: 1px solid {PURPLE_HOVER};
            padding: 8px 14px;
        }}

        QPushButton:hover {{
            background-color: {PURPLE_HOVER};
            color: {TEXT};
        }}

        QPushButton:pressed {{
            background-color: {PURPLE_DARK};
            color: {TEXT};
        }}

        QPushButton:disabled {{
            background-color: {PANEL};
            color: {DISABLED};
        }}

        QMenuBar,
        QMenu {{
            background-color: {PANEL};
            color: {TEXT};
        }}

        QMenuBar::item:selected,
        QMenu::item:selected {{
            background-color: {SELECTION};
            color: {TEXT};
        }}

        QTabBar::tab {{
            background-color: {PURPLE_DARK};
            color: {TEXT};
            padding: 8px 16px;
        }}

        QTabBar::tab:selected {{
            background-color: {PURPLE};
            color: {TEXT};
        }}

        QHeaderView::section {{
            background-color: {PURPLE_DARK};
            color: {TEXT};
            border: 1px solid {BORDER};
            padding: 6px;
        }}

        QStatusBar {{
            background-color: {PURPLE_DARK};
            color: {TEXT};
        }}

        QScrollBar {{
            background-color: {PANEL};
        }}

        QScrollBar::handle {{
            background-color: {PURPLE};
            border-radius: 4px;
        }}

        QToolTip {{
            background-color: {PANEL};
            color: {TEXT};
            border: 1px solid {PURPLE};
        }}

        QMessageBox {{
            background-color: {BACKGROUND};
            color: {TEXT};
        }}
        """
    )


def main():
    app = QApplication(sys.argv)

    apply_dark_theme(app)

    window = XmlTableWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
