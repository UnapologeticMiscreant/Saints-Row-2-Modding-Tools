#!/usr/bin/env python3
"""
PegTool.py — Saints Row 2 PEG texture tool with DDS support
Modified to output DDS instead of RAW for compressed textures

Port of Gibbed's PegTool (C#, 2010) with DDS output enhancement
"""

from __future__ import annotations

import os
import queue
import struct
import threading
import traceback
import ctypes
from dataclasses import dataclass, field
from enum import IntEnum
from io import BytesIO
from typing import BinaryIO
import xml.etree.ElementTree as ET

import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText

try:
    from PIL import Image
except ImportError:
    raise SystemExit("Pillow is required: pip install pillow")


# =============================================================================
# 1. Structures  (port of PegEntry.cs / PegFrame struct)
# =============================================================================

class PegFormat(IntEnum):
    """Texture formats. Values map to D3D format types + 400:
    400=DXT1, 401=DXT3, 402=DXT5, 403=R5G6B5, 404=A1R5G5B5, 405=A4R4G4B4,
    406=R8G8B8, 407=A8R8G8B8, 408=V8U8, 409=CxV8U8, 410=A8."""
    UNKNOWN   = 0
    DXT1      = 0x0190
    DXT3      = 0x0191
    DXT5      = 0x0192
    R5G6B5    = 0x0193
    A1R5G5B5  = 0x0194
    A4R4G4B4  = 0x0195
    R8G8B8    = 0x0196
    A8R8G8B8  = 0x0197
    V8U8      = 0x0198
    CXV8U8    = 0x0199
    A8        = 0x019A


@dataclass
class PegFrame:
    """Serializes to exactly 0x30 (48) bytes. Field offsets match the C#
    explicit-layout struct (contiguous, no padding holes)."""
    offset:          int = 0   # 0x00  u32
    width:           int = 0   # 0x04  u16
    height:          int = 0   # 0x06  u16
    format:          int = 0   # 0x08  u16  (PegFormat value)
    unknown_0a:      int = 0   # 0x0A  u16
    unknown_0c:      int = 0   # 0x0C  u32
    frames:          int = 0   # 0x10  u16
    unknown_12:      int = 0   # 0x12  u32  (misaligned in file — intentional)
    unknown_16:      int = 0   # 0x16  u32  # used for a pointer to the string by game
    unknown_flags1a: int = 0   # 0x1A  u16
    size:            int = 0   # 0x1C  u32
    unknown_20:      int = 0   # 0x20  u32
    unknown_24:      int = 0   # 0x24  u32
    unknown_28:      int = 0   # 0x28  u32
    unknown_2c:      int = 0   # 0x2C  u32

    def to_bytes(self, big_endian: bool = False) -> bytes:
        fmt = ">" if big_endian else "<"
        return struct.pack(
            fmt + "IHHHHIHIIHIIIII",
            self.offset, self.width, self.height, self.format, self.unknown_0a,
            self.unknown_0c, self.frames, self.unknown_12, self.unknown_16,
            self.unknown_flags1a, self.size, self.unknown_20,
            self.unknown_24, self.unknown_28, self.unknown_2c)

    @classmethod
    def from_bytes(cls, data: bytes, big_endian: bool = False) -> "PegFrame":
        fmt = ">" if big_endian else "<"
        return cls(*struct.unpack(fmt + "IHHHHIHIIHIIIII", data[:0x30]))


@dataclass
class PegEntry:
    name: str = ""
    frames: list = field(default_factory=list)  # list[PegFrame]


# =============================================================================
# 2. PegFile  (port of PegFile.cs)
# =============================================================================

class PegFileException(Exception):
    """Base exception for peg file errors."""

class NotAPegFileException(PegFileException):
    """Header magic is not GEKV."""

class UnsupportedPackageFileVersionException(PegFileException):
    """Package version is not supported (only version 10)."""


def _read_u16(stream: BinaryIO, big_endian: bool = False) -> int:
    return struct.unpack((">" if big_endian else "<") + "H", stream.read(2))[0]

def _read_u32(stream: BinaryIO, big_endian: bool = False) -> int:
    return struct.unpack((">" if big_endian else "<") + "I", stream.read(4))[0]

def _read_asciiz(stream: BinaryIO) -> str:
    chars = bytearray()
    while True:
        b = stream.read(1)
        if not b or b == b"\x00":
            break
        chars += b
    return chars.decode("ascii", "replace")


class PegFile:
    def __init__(self, big_endian: bool = False):
        self.entries: list[PegEntry] = []
        self.file_size: int = 0      # 0x08 u32
        self.data_file_size: int = 0 # 0x0C u32
        self.unknown06: int = 0      # 0x06 u16
        self.unknown12: int = 0      # 0x12 u16
        self.unknown16: int = 0      # 0x16 u16
        self.big_endian: bool = big_endian
        self.size_mismatch: bool = False

    def _read_frame(self, stream: BinaryIO) -> PegFrame:
        data = stream.read(0x30)
        if len(data) < 0x30:
            data = data + b"\x00" * (0x30 - len(data))  # zero-fill like C# Stream.Read
        end = ">" if self.big_endian else "<"
        frame = PegFrame(*struct.unpack(end + "IHHHHIHIIHIIIII", data[:0x30]))
        return frame
        # NOTE: the original forced Width=512 for Xbox frames here; that hack
        # is now an explicit GUI option applied in unpack() instead.

    def read(self, stream: BinaryIO) -> None:
        self.entries.clear()

        magic = _read_u32(stream, self.big_endian)                 # 00
        if magic != 0x564B4547:                                    # "GEKV"
            raise NotAPegFileException("header must be GEKV")

        version = _read_u16(stream, self.big_endian)               # 04
        if version != 10:
            raise UnsupportedPackageFileVersionException(
                "only version 10 is supported")

        self.unknown06 = _read_u16(stream, self.big_endian)        # 06
        self.file_size = _read_u32(stream, self.big_endian)        # 08
        pos = stream.tell()
        stream.seek(0, 2)
        if stream.tell() != self.file_size:
            self.size_mismatch = True
        stream.seek(pos)

        self.data_file_size = _read_u32(stream, self.big_endian)   # 0C
        entry_count = _read_u16(stream, self.big_endian)           # 10
        self.unknown12 = _read_u16(stream, self.big_endian)        # 12
        frame_count = _read_u16(stream, self.big_endian)           # 14
        self.unknown16 = _read_u16(stream, self.big_endian)        # 16

        # Names live after all frame structs
        names: list[str] = []
        stream.seek(0x18 + 0x30 * frame_count)
        for _ in range(entry_count):
            names.append(_read_asciiz(stream))

        total_frames = 0
        stream.seek(0x18)
        for i in range(entry_count):
            entry = PegEntry(name=names[i])

            frame = self._read_frame(stream)
            entry.frames.append(frame)
            total_frames += 1

            if frame.frames == 0:
                raise PegFileException("frame count is 0")
            elif frame.frames > 1:
                # First frame of a peg says how many frames the image has
                # (including itself); all subsequent frames carry 1.
                for _ in range(1, frame.frames):
                    entry.frames.append(self._read_frame(stream))
                    total_frames += 1

            self.entries.append(entry)

        if total_frames != frame_count:
            raise PegFileException(
                f"frame count mismatch: header says {frame_count}, "
                f"read {total_frames}")


# =============================================================================
# 3. ImageFormats  (port of ImageFormats.cs, incl. all endianness fixes)
# ============================================================================

class Flags(IntEnum):
    DXT1                      = 1 << 0
    DXT3                      = 1 << 1
    DXT5                      = 1 << 2
    ColourClusterFit          = 1 << 3
    ColourRangeFit            = 1 << 4
    ColourMetricPerceptual    = 1 << 5
    ColourMetricUniform       = 1 << 6
    WeightColourByAlpha       = 1 << 7
    ColourIterativeClusterFit = 1 << 8

_BLOCK_SIZE = {PegFormat.DXT1: 8, PegFormat.DXT3: 16, PegFormat.DXT5: 16}

# --- native libSquish loader (replaces the original's DllImport) -------------
_squish = None
for _name in ("squish.dll", "libsquish.dll", "libsquish.so", "libsquish.dylib"):
    try:
        _dll = ctypes.CDLL(_name)
        for _fn in ("CompressImage", "DecompressImage"):
            getattr(_dll, _fn).argtypes = [
                ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint,
                ctypes.c_void_p, ctypes.c_int]
        _squish = _dll
        break
    except OSError:
        continue

def _native_compress(rgba: bytes, width: int, height: int, size: int, flags: int) -> bytes:
    src = (ctypes.c_char * len(rgba)).from_buffer_copy(rgba)
    dst = (ctypes.c_char * size)()
    _squish.CompressImage(src, width, height, dst, flags)
    return bytes(dst)

def _native_decompress(compressed: bytes, width: int, height: int, flags: int) -> bytes:
    src = (ctypes.c_char * len(compressed)).from_buffer_copy(compressed)
    dst = (ctypes.c_char * (width * height * 4))()
    _squish.DecompressImage(dst, width, height, src, flags)
    return bytes(dst)


# --- pure-Python DXT codec (fallback when no native lib) ---------------------

def _expand565(v: int) -> tuple[int, int, int]:
    r = (v >> 11) & 0x1F; g = (v >> 5) & 0x3F; b = v & 0x1F
    return (r << 3) | (r >> 2), (g << 2) | (g >> 4), (b << 3) | (b >> 2)

def _rgb565(r: int, g: int, b: int) -> int:
    return ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3)

def _pad_dims(width: int, height: int) -> tuple[int, int]:
    return (width + 3) & ~3, (height + 3) & ~3

def _pure_decompress(compressed: bytes, width: int, height: int, fmt: PegFormat) -> bytes:
    out_w, out_h = _pad_dims(width, height)
    out = bytearray(out_w * out_h * 4)
    blocks_x = out_w // 4
    bs = _BLOCK_SIZE[fmt]
    for brow in range(out_h // 4):
        for bcol in range(blocks_x):
            off = (brow * blocks_x + bcol) * bs
            alphas = None
            if fmt == PegFormat.DXT3:
                ab = compressed[off:off + 8]
                alphas = [((ab[i >> 1] >> ((i & 1) * 4)) & 0xF) * 17 for i in range(16)]
            elif fmt == PegFormat.DXT5:
                a0, a1 = compressed[off], compressed[off + 1]
                abits = int.from_bytes(compressed[off + 2:off + 8], "little")
                apal = [a0, a1]
                if a0 > a1:
                    apal += [((7 - k) * a0 + k * a1) // 7 for k in range(1, 7)]
                else:
                    apal += [((5 - k) * a0 + k * a1) // 5 for k in range(1, 5)] + [0, 255]
                alphas = [apal[(abits >> (3 * i)) & 7] for i in range(16)]
            coff = off if fmt == PegFormat.DXT1 else off + 8
            c0, c1, cbits = struct.unpack_from("<HHI", compressed, coff)
            p0, p1 = _expand565(c0), _expand565(c1)
            if c0 > c1:
                cpal = [(*p0, 255), (*p1, 255),
                        ((2 * p0[0] + p1[0]) // 3, (2 * p0[1] + p1[1]) // 3,
                         (2 * p0[2] + p1[2]) // 3, 255),
                        ((p0[0] + 2 * p1[0]) // 3, (p0[1] + 2 * p1[1]) // 3,
                         (p0[2] + 2 * p1[2]) // 3, 255)]
            else:
                cpal = [(*p0, 255), (*p1, 255),
                        ((p0[0] + p1[0]) // 2, (p0[1] + p1[1]) // 2,
                         (p0[2] + p1[2]) // 2, 255),
                        (0, 0, 0, 0)]
            for i in range(16):
                ci = (cbits >> (2 * i)) & 3
                r, g, b = cpal[ci][:3]
                a = alphas[i] if alphas is not None else cpal[ci][3]
                pos = ((brow * 4 + i // 4) * out_w + (bcol * 4 + i % 4)) * 4
                out[pos:pos + 4] = bytes((r, g, b, a))
    if width != out_w or height != out_h:  # crop padding
        cropped = bytearray(width * height * 4)
        for y in range(height):
            cropped[y * width * 4:(y + 1) * width * 4] = \
                out[y * out_w * 4:(y * out_w + width) * 4]
        return bytes(cropped)
    return bytes(out)

def _encode_block(pix: list, fmt: PegFormat) -> bytes:
    trans_mode = (fmt == PegFormat.DXT1) and any(p[3] == 0 for p in pix)
    pool = ([p for p in pix if p[3] != 0] or [pix[0]]) if trans_mode else pix
    sums = [p[0] + p[1] + p[2] for p in pool]
    ai = min(range(len(pool)), key=lambda i: sums[i])
    bi = max(range(len(pool)), key=lambda i: sums[i])
    qa = _rgb565(*pool[ai][:3]); qb = _rgb565(*pool[bi][:3])
    if qa == qb:
        qb = qa + 1 if qa < 0xFFFF else qa - 1  # nudge endpoints apart
    q0, q1 = (min(qa, qb), max(qa, qb)) if trans_mode else (max(qa, qb), min(qa, qb))
    p0, p1 = _expand565(q0), _expand565(q1)
    if q0 > q1:
        cpal = [(*p0, 255), (*p1, 255),
                ((2 * p0[0] + p1[0]) // 3, (2 * p0[1] + p1[1]) // 3,
                 (2 * p0[2] + p1[2]) // 3, 255),
                ((p0[0] + 2 * p1[0]) // 3, (p0[1] + 2 * p1[1]) // 3,
                 (p0[2] + p1[2]) // 3, 255)]
        n_choices = 4
    else:
        cpal = [(*p0, 255), (*p1, 255),
                ((p0[0] + p1[0]) // 2, (p0[1] + p1[1]) // 2,
                 (p0[2] + p1[2]) // 2, 255),
                (0, 0, 0, 0)]
        n_choices = 3
    cbits = 0
    for i, p in enumerate(pix):
        if trans_mode and p[3] == 0:
            e = 3
        else:
            e = min(range(n_choices),
                    key=lambda k: (cpal[k][0] - p[0]) ** 2 + (cpal[k][1] - p[1]) ** 2
                                  + (cpal[k][2] - p[2]) ** 2)
        cbits |= e << (2 * i)
    color = struct.pack("<HHI", q0, q1, cbits)
    if fmt == PegFormat.DXT3:
        ab = bytearray(8)
        for i, p in enumerate(pix):
            n = (p[3] * 15 + 127) // 255
            ab[i >> 1] |= n << ((i & 1) * 4)
        return bytes(ab) + color
    if fmt == PegFormat.DXT5:
        amax = max(p[3] for p in pix); amin = min(p[3] for p in pix)
        a0, a1 = amax, amin
        apal = [a0, a1]
        if a0 > a1:
            apal += [((7 - k) * a0 + k * a1) // 7 for k in range(1, 7)]
        else:
            apal += [((5 - k) * a0 + k * a1) // 5 for k in range(1, 5)] + [0, 255]
        abits = 0
        for i, p in enumerate(pix):
            abits |= min(range(len(apal)),
                         key=lambda k: (apal[k] - p[3]) ** 2) << (3 * i)
        return struct.pack("<BB", a0, a1) + abits.to_bytes(6, "little") + color
    return color

def _pure_compress(rgba: bytes, width: int, height: int, fmt: PegFormat) -> bytes:
    out_w, out_h = _pad_dims(width, height)
    src = bytearray(out_w * out_h * 4)  # zero-padded source
    for y in range(height):
        src[y * out_w * 4: y * out_w * 4 + width * 4] = \
            rgba[y * width * 4:(y + 1) * width * 4]
    blocks_x = out_w // 4
    out = bytearray()
    for brow in range(out_h // 4):
        for bcol in range(blocks_x):
            pix = []
            for i in range(16):
                o = ((brow * 4 + i // 4) * out_w + (bcol * 4 + i % 4)) * 4
                pix.append((src[o], src[o + 1], src[o + 2], src[o + 3]))
            out += _encode_block(pix, fmt)
    return bytes(out)


# --- endianness correction for big-endian (Xbox) peg data --------------------

def _fix_block_endianness(data: bytes, fmt: PegFormat) -> bytes:
    """Byte-swap the u16 color-endpoint words in every DXT block (identical
    to the original's proven DXT1 ByteSwap branch), plus the four u16 alpha
    words for DXT3. DXT5's alpha half (two u8s + a packed 48-bit index
    bitfield) is left untouched. Fixes scrambled colors the original
    produced for BE DXT3/DXT5 textures."""
    bs = _BLOCK_SIZE[fmt]
    out = bytearray(data)
    for base in range(0, len(data) - bs + 1, bs):
        cbase = base if fmt == PegFormat.DXT1 else base + 8
        out[cbase], out[cbase + 1] = data[cbase + 1], data[cbase]
        out[cbase + 2], out[cbase + 3] = data[cbase + 3], data[cbase + 2]
        if fmt == PegFormat.DXT3:
            for w in range(4):
                o = base + w * 2
                out[o], out[o + 1] = data[o + 1], data[o]
    return bytes(out)


# --- public image API ---------------------------------------------------------

def byte_swap(data: bytes, fmt: PegFormat) -> bytes:
    """Port of ByteSwap, extended with an R5G6B5 branch (fixes the crash the
    original had when unpacking big-endian R5G6B5 textures)."""
    out = bytearray(data)
    if fmt == PegFormat.DXT1:
        for i in range(0, len(data), 8):
            out[i], out[i + 1] = data[i + 1], data[i]
            out[i + 2], out[i + 3] = data[i + 3], data[i + 2]
    elif fmt == PegFormat.A8R8G8B8:
        for i in range(0, len(data), 4):
            out[i:i + 4] = data[i:i + 4][::-1]
    elif fmt == PegFormat.R5G6B5:
        for i in range(0, len(data), 2):  # each pixel is a u16
            out[i], out[i + 1] = data[i + 1], data[i]
    else:
        raise Exception("Unhandled format: " + str(fmt))
    return bytes(out)

def compress(decompressed: bytes, width: int, height: int, fmt: PegFormat,
             big_endian: bool = False) -> bytes:
    """Input: RGBA bytes (width*height*4). Output: DXT-compressed data."""
    if fmt not in _BLOCK_SIZE:
        raise Exception("Unhandled format: " + str(fmt))
    if _squish:
        flags = int(Flags.ColourMetricUniform | Flags.ColourIterativeClusterFit)
        flags |= int(PegFormat(fmt) and {PegFormat.DXT1: Flags.DXT1,
                                         PegFormat.DXT3: Flags.DXT3,
                                         PegFormat.DXT5: Flags.DXT5}[fmt])
        # squish output buffer: w*h/2 bytes for DXT1, w*h for DXT3/5
        size = len(decompressed) // (8 if fmt == PegFormat.DXT1 else 4)
        out = _native_compress(decompressed, width, height, size, flags)
    else:
        out = _pure_compress(decompressed, width, height, fmt)
    if big_endian:
        out = _fix_block_endianness(out, fmt)
    return out

def decompress(compressed: bytes, width: int, height: int, fmt: PegFormat,
               big_endian: bool = False) -> bytes:
    """Input: DXT data. Output: RGBA bytes (width*height*4)."""
    if fmt not in _BLOCK_SIZE:
        raise Exception("Unhandled format: " + str(fmt))
    if big_endian:
        compressed = _fix_block_endianness(compressed, fmt)
    if _squish:
        flags = int({PegFormat.DXT1: Flags.DXT1, PegFormat.DXT3: Flags.DXT3,
                     PegFormat.DXT5: Flags.DXT5}[fmt])
        return _native_decompress(compressed, width, height, flags)
    return _pure_decompress(compressed, width, height, fmt)

def make_bitmap_from_dxt(width: int, height: int, buffer: bytes, keep_alpha: bool = True):
    # keep_alpha mirrors the original's parameter (which did nothing there —
    # its body was commented out); Pillow preserves whatever the decoder gave.
    return Image.frombytes("RGBA", (width, height), bytes(buffer))

def make_bitmap_from_r5g6b5(width: int, height: int, buffer: bytes):
    words = struct.unpack(f"<{width * height}H", bytes(buffer[:width * height * 2]))
    data = bytearray()
    for v in words:
        r = (v >> 11) & 0x1F; g = (v >> 5) & 0x3F; b = v & 0x1F
        data += bytes(((r << 3) | (r >> 2), (g << 2) | (g >> 4), (b << 3) | (b >> 2)))
    return Image.frombytes("RGB", (width, height), bytes(data))

def make_bitmap_from_a8r8g8b8(width: int, height: int, buffer: bytes):
    # File data is B,G,R,A byte order (little-endian A8R8G8B8 dwords);
    # PIL's "BGRA" raw mode converts in one step.
    return Image.frombytes("RGBA", (width, height), bytes(buffer), "raw", "BGRA")

# =============================================================================
# NEW: DDS WRITER FUNCTIONS
# =============================================================================

def create_dds_header(width: int, height: int, fourcc: bytes, has_mipmaps: bool = False) -> bytes:
    """Create a valid DDS file header for DXT compressed textures."""
    header = bytearray(128)
    
    # DDSCAPS 2 header structure (128 bytes total)
    # Magic: "DDS "
    struct.pack_into("<4s", header, 0, b"DDS ")
    
    # Size (always 124 for DDS header)
    struct.pack_into("<I", header, 4, 124)
    
    # Flags (DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT | DDSDPitch | (DDSD_LINEARSIZE if mipmaps))
    flags = 0x1007  # Height, Width, Pitch/LinearSize, Capabilities, PixelFormat
    if has_mipmaps:
        flags |= 0x20000  # DDSD_MIPMAPCOUNT
    struct.pack_into("<I", header, 8, flags)
    
    # Height
    struct.pack_into("<I", header, 12, height)
    
    # Width
    struct.pack_into("<I", header, 16, width)
    
    # PitchOrLinearSize (for compressed: 8 bytes per 4x4 block for DXT1, 16 for DXT5)
    blocks_x = (width + 3) // 4
    blocks_y = (height + 3) // 4
    pitch = blocks_x * blocks_y * (8 if fourcc == b'DXT1' else 16)
    struct.pack_into("<I", header, 20, pitch)
    
    # Depth (unused for 2D)
    struct.pack_into("<I", header, 24, 0)
    
    # MipMapCount (0 = no mipmaps, 1 = minimal)
    mip_count = 1
    if has_mipmaps:
        # Calculate actual mipmap count
        temp_w, temp_h = width, height
        while temp_w > 1 or temp_h > 1:
            temp_w = max(1, temp_w >> 1)
            temp_h = max(1, temp_h >> 1)
            mip_count += 1
    struct.pack_into("<I", header, 28, mip_count)
    
    # Reserved1[11] - zeros
    # Already initialized to 0
    
    # DDPIXELFORMAT structure (at offset 76)
    pf_size = 32
    pf_flags = 0x4  # DDPF_FOURCC
    struct.pack_into("<I", header, 76, pf_size)
    struct.pack_into("<I", header, 80, pf_flags)
    struct.pack_into("<4s", header, 84, fourcc)  # DXT1, DXT3, or DXT5
    struct.pack_into("<I", header, 88, 0)  # FourCC
    struct.pack_into("<I", header, 92, 0)  # RGBBitCount
    struct.pack_into("<I", header, 96, 0)  # RBitMask
    struct.pack_into("<I", header, 100, 0)  # GBitMask
    struct.pack_into("<I", header, 104, 0)  # BBitMask
    struct.pack_into("<I", header, 108, 0)  # ABitMask
    
    # Caps (DDSCAPS_TEXTURE)
    struct.pack_into("<I", header, 112, 0x1000)
    
    # Caps2 (DDSCAPS2_DIMENSION | DDSCAPS2_COMPLEX for mipmaps)
    caps2 = 0
    if has_mipmaps:
        caps2 |= 0x200  # DDSCAPS2_MIPMAPS
    struct.pack_into("<I", header, 116, caps2)
    
    # Caps3, Caps4 (zeros)
    struct.pack_into("<I", header, 120, 0)
    struct.pack_into("<I", header, 124, 0)
    
    return bytes(header)


def save_as_dds(image_path: str, compressed_data: bytes, width: int, height: int, fmt: PegFormat):
    """Save texture data as DDS file with proper header."""
    # Map PegFormat to DDS FourCC
    fourcc_map = {
        PegFormat.DXT1: b'DXT1',
        PegFormat.DXT3: b'DXT3',
        PegFormat.DXT5: b'DXT5',
    }
    
    fourcc = fourcc_map.get(fmt, b'DXT1')
    has_mipmaps = False  # SR2 doesn't typically use mipmaps
    
    header = create_dds_header(width, height, fourcc, has_mipmaps)
    
    with open(image_path, 'wb') as f:
        f.write(header)
        f.write(compressed_data)
    
    print(f"[DDS] Saved: {image_path} ({width}x{height}, {fourcc.decode()})")


# =============================================================================
# 4. peg_desc XML I/O  (port of XmlParser.cs + WritePegDescription)
# =============================================================================

def _u32(v): return v & 0xFFFFFFFF
def _u16(v): return v & 0xFFFF

def write_peg_description(peg: PegFile, path: str):
    """Port of Program.WritePegDescription (tab-indented, UTF-8)."""
    root = ET.Element("PegDescription")
    frame_count = sum(len(e.frames) for e in peg.entries)

    ET.SubElement(root, "BigEndian").text   = str(peg.big_endian)
    ET.SubElement(root, "Magic").text       = "GEKV"
    ET.SubElement(root, "Version").text     = "10"
    ET.SubElement(root, "Unknown06").text    = str(peg.unknown06)
    ET.SubElement(root, "FileSize").text     = str(peg.file_size)
    ET.SubElement(root, "DataFileSize").text = str(peg.data_file_size)
    ET.SubElement(root, "EntryCount").text   = str(len(peg.entries))
    ET.SubElement(root, "Unknown12").text    = str(peg.unknown12)
    ET.SubElement(root, "FrameCount").text  = str(frame_count)
    ET.SubElement(root, "Unknown16").text    = str(peg.unknown16)

    entries_el = ET.SubElement(root, "Entries")
    for entry in peg.entries:
        entry_el = ET.SubElement(entries_el, "Entry")
        ET.SubElement(entry_el, "Name").text = entry.name
        frames_el = ET.SubElement(entry_el, "Frames")
        for fr in entry.frames:
            f = ET.SubElement(frames_el, "Frame")
            ET.SubElement(f, "Offset").text         = str(fr.offset)
            ET.SubElement(f, "Width").text          = str(fr.width)
            ET.SubElement(f, "Height").text          = str(fr.height)
            ET.SubElement(f, "Format").text          = PegFormat(fr.format).name
            ET.SubElement(f, "Unknown0A").text       = str(fr.unknown_0a)
            ET.SubElement(f, "Unknown0C").text       = str(fr.unknown_0c)
            ET.SubElement(f, "Frames").text         = str(fr.frames)
            ET.SubElement(f, "Unknown12").text      = str(fr.unknown_12)
            ET.SubElement(f, "Unknown16").text      = str(fr.unknown_16)
            ET.SubElement(f, "UnknownFlags1A").text = f"{fr.unknown_flags1a:04X}"
            ET.SubElement(f, "Size").text            = str(fr.size)
            ET.SubElement(f, "Unknown20").text       = str(fr.unknown_20)
            ET.SubElement(f, "Unknown24").text       = str(fr.unknown_24)
            ET.SubElement(f, "Unknown28").text       = str(fr.unknown_28)
            ET.SubElement(f, "Unknown2C").text       = str(fr.unknown_2c)

    tree = ET.ElementTree(root)
    ET.indent(tree, space="\t")
    tree.write(path, encoding="utf-8", xml_declaration=True)


def parse_peg_description(path: str, log) -> "PegFile | None":
    """Port of XmlParser.ParseFile — tolerant parsing, None on error."""
    try:
        document = ET.parse(path)
    except ET.ParseError as e:
        log(f"This is not a valid peg_desc file: {path}")
        log(f"XML parse error: {e}")
        return None

    root = document.getroot()
    if root.tag != "PegDescription":
        log(f"This is not a valid peg_desc file: {path}")
        log("Unable to find PegDescription node.")
        return None

    peg = PegFile(False)
    text = lambda tag, default=None: (root.findtext(tag) or default)

    if text("Magic") != "GEKV":
        log(f"This is not a valid peg_desc file: {path}")
        log(f"Bad magic value. Got: {text('Magic')}, expected: GEKV")
        return None
    try:
        if int(text("Version", "0")) != 10:
            log(f"Bad version value. Got: {text('Version')}, expected: 10")
            return None
    except ValueError:
        log("Bad version value (not a number).")
        return None

    try:
        peg.big_endian     = (text("BigEndian", "False") == "True")
        peg.unknown06      = int(text("Unknown06", "0"))
        peg.unknown12      = int(text("Unknown12", "0"))
        peg.unknown16      = int(text("Unknown16", "0"))
        peg.file_size      = int(text("FileSize", "0"))
        peg.data_file_size = int(text("DataFileSize", "0"))
    except ValueError:
        log("Malformed number in peg_desc header.")
        return None

    entries_el = root.find("Entries")
    if entries_el is not None:
        for entry_el in entries_el.findall("Entry"):
            entry = PegEntry(name=entry_el.findtext("Name", "") or "")
            frames_el = entry_el.find("Frames")
            if frames_el is not None:
                for f in frames_el.findall("Frame"):
                    g = lambda t, d=0: int(f.findtext(t, str(d)) or d)
                    fr = PegFrame(
                        offset=g("Offset"), width=g("Width"), height=g("Height"),
                        format=0, unknown_0a=g("Unknown0A"),
                        unknown_0c=g("Unknown0C"), frames=g("Frames"),
                        unknown_12=g("Unknown12"), unknown_16=g("Unknown16"),
                        unknown_flags1a=int(f.findtext("UnknownFlags1A", "0") or "0", 16),
                        size=g("Size"), unknown_20=g("Unknown20"),
                        unknown_24=g("Unknown24"), unknown_28=g("Unknown28"),
                        unknown_2c=g("Unknown2C"))
                    fname = f.findtext("Format", "UNKNOWN") or "UNKNOWN"
                    try:
                        fr.format = int(PegFormat[fname.upper()])
                    except KeyError:
                        log(f"  ! unknown format name '{fname}', "
                            f"kept numeric value {fr.format}")
                    entry.frames.append(fr)
            peg.entries.append(entry)
    return peg


# =============================================================================
# 5. Unpack / Repack pipeline  (port of Program.cs)
# =============================================================================

def unpack(peg_path: str, force_width_512: bool = False, output_dds: bool = True, *, log):
    """Port of Program.Unpack + UnpackImages. MODIFIED to output DDS."""
    log(f"Unpacking {peg_path}:")
    if not os.path.isfile(peg_path):
        log(f"peg file does not exist: {peg_path}"); return

    ext = os.path.splitext(peg_path)[1].lower()
    xbox = (ext == ".peg_xbox2")
    if ext not in (".peg_pc", ".peg_xbox2"):
        log(f"File is not a peg_pc/peg_xbox2 file: {peg_path}"); return

    stem, _ = os.path.splitext(peg_path)
    data_ext = ".g_peg_xbox2" if xbox else ".g_peg_pc"
    peg_data_path = stem + data_ext
    desc_path = stem + ".peg_desc"

    if not os.path.isfile(peg_data_path):
        log(f"{data_ext.lstrip('.')} file does not exist: {peg_data_path}")
        log(f"Did you copy it into the same directory as {peg_path}?"); return

    peg = PegFile(xbox)
    with open(peg_path, "rb") as fs, open(peg_data_path, "rb") as dfs:
        peg.read(fs)
        if peg.size_mismatch:
            log("WARNING: header file size does not match actual size on disk — continuing anyway.")

        if force_width_512:
            # Optional reproduction of the original tool's hardcoded hack.
            for e in peg.entries:
                for fr in e.frames:
                    fr.width = 512

        log(f"Writing peg description to: {desc_path}... done.")
        write_peg_description(peg, desc_path)

        log("Unpacking images:")
        out_dir = os.path.dirname(os.path.abspath(peg_path))
        for entry in peg.entries:
            plural = "" if len(entry.frames) == 1 else "s"
            log(f"Extracting {entry.name} ({len(entry.frames)} frame{plural}):")
            for i, fr in enumerate(entry.frames):
                fmt = PegFormat(fr.format)
                is_compressed = fmt in (PegFormat.DXT1, PegFormat.DXT3, PegFormat.DXT5)
                
                # Decide output format based on texture type
                if output_dds and is_compressed:
                    # OUTPUT DDS for compressed textures
                    png_path = os.path.join(out_dir, f"{entry.name}_{i}.png")
                    dds_path = os.path.join(out_dir, f"{entry.name}_{i}.dds")
                    log(f" - Extracting {dds_path} (DDS)... ", nl=False)
                    
                    dfs.seek(fr.offset)
                    raw = dfs.read(fr.size)
                    
                    # Write DDS file with header
                    save_as_dds(dds_path, raw, fr.width, fr.height, fmt)
                    log("done.")
                    
                    # Still extract PNG for visualization (decompressed)
                    try:
                        if fmt in (PegFormat.DXT1, PegFormat.DXT3, PegFormat.DXT5):
                            rgba = decompress(raw, fr.width, fr.height, fmt,
                                              big_endian=peg.big_endian)
                            bmp = make_bitmap_from_dxt(fr.width, fr.height, rgba)
                            bmp.save(png_path, "PNG")
                    except Exception as e:
                        log(f"\n[Warning] PNG extraction failed: {e}")
                else:
                    # ORIGINAL BEHAVIOR: extract PNG and RAW for uncompressed
                    png_path = os.path.join(out_dir, f"{entry.name}_{i}.png")
                    raw_path = os.path.join(out_dir, f"{entry.name}_{i}.raw")
                    log(f" - Extracting {png_path}... ", nl=False)

                    dfs.seek(fr.offset)
                    raw = dfs.read(fr.size)

                    with open(raw_path, "wb") as rf:
                        rf.write(raw)

                    if fmt == PegFormat.A8R8G8B8:
                        if peg.big_endian:
                            raw = byte_swap(raw, fmt)
                        bmp = make_bitmap_from_a8r8g8b8(fr.width, fr.height, raw)
                    elif fmt == PegFormat.R5G6B5:
                        if peg.big_endian:
                            raw = byte_swap(raw, fmt)  # FIXED: no longer throws
                        bmp = make_bitmap_from_r5g6b5(fr.width, fr.height, raw)
                    elif fmt in (PegFormat.DXT1, PegFormat.DXT3, PegFormat.DXT5):
                        # FIXED: BE DXT3/5 now byte-order-corrected before decoding
                        rgba = decompress(raw, fr.width, fr.height, fmt,
                                          big_endian=peg.big_endian)
                        bmp = make_bitmap_from_dxt(fr.width, fr.height, rgba)
                    else:
                        log("")
                        raise Exception(f"Unhandled format: {fmt}")

                    bmp.save(png_path, "PNG")
                    log("done.")
        log("")
        log("Finished unpacking.")
        if output_dds:
            log("[INFO] Compressed textures saved as DDS (ready for game or viewer)")
            log("[INFO] PNG versions also extracted for editing purposes")


def repack(desc_path: str, *, log):
    """Port of Program.Repack. UPDATED to support DDS input."""
    log(f"Repacking {desc_path}:")
    if not os.path.isfile(desc_path):
        log(f"peg_desc file does not exist: {desc_path}"); return
    if os.path.splitext(desc_path)[1] != ".peg_desc":
        log(f"File is not a peg_desc file: {desc_path}"); return

    desc_folder = os.path.dirname(os.path.abspath(desc_path))
    log("Loading Peg Description... ", nl=False)
    peg = parse_peg_description(desc_path, log)
    if peg is None:
        log("")
        log("An error occurred while loading the peg_desc file."); return
    log("done.")

    log("Loading texture data, performing colour space conversions and compressing data:")

    frame_data: list[bytes] = []
    total_size = 0
    total_frames = 0

    for entry in peg.entries:
        for i, fr in enumerate(entry.frames):
            log(f" - {entry.name} (frame {i})... ", nl=False)
            fr.frames = len(entry.frames) if i == 0 else 1
            fr.offset = total_size
            fmt = PegFormat(fr.format)

            # CHECK FOR DDS FIRST (for compressed formats)
            dds_path = os.path.join(desc_folder, f"{entry.name}_{i}.dds")
            raw_path = os.path.join(desc_folder, f"{entry.name}_{i}.raw")
            png_path = os.path.join(desc_folder, f"{entry.name}_{i}.png")

            if os.path.isfile(dds_path) and fmt in (PegFormat.DXT1, PegFormat.DXT3, PegFormat.DXT5):
                # USE DDS FILE DIRECTLY (lossless!)
                log(f"loading from {dds_path}... ", nl=False)
                with open(dds_path, "rb") as df:
                    dds_data = df.read()
                # Skip DDS header (128 bytes)
                raw = dds_data[128:]
                log("done.")
                log(f"  [NOTE] DDS loaded directly - no recompression")
            elif os.path.isfile(raw_path):
                log(f"loading from {raw_path}... ", nl=False)
                with open(raw_path, "rb") as rf:
                    raw = rf.read()
                log("done.")
            else:
                log(f"importing from {png_path}... ", nl=False)
                if not os.path.isfile(png_path):
                    log("")
                    log(f"Unable to find file: {png_path}")
                    log("Make sure all your texture files are in the correct "
                        "location and correctly named.")
                    log("For DXT textures, DDS files are preferred (no quality loss).")
                    return

                src = Image.open(png_path).convert("RGBA")
                w, h = src.size
                rgba = src.tobytes()

                if fmt in (PegFormat.DXT1, PegFormat.DXT3, PegFormat.DXT5):
                    raw = compress(rgba, w, h, fmt, big_endian=peg.big_endian)
                elif fmt == PegFormat.A8R8G8B8:
                    raw = _rgba_to_bgra(rgba)
                elif fmt == PegFormat.R5G6B5:
                    raw = _rgba_to_r5g6b5(rgba, w, h)
                else:
                    log("")
                    raise Exception(f"Unhandled format: {fmt}")
                log("done.")

            fr.size = len(raw)
            total_size += len(raw)
            if total_size % 16 != 0:
                total_size = (total_size + 15) & ~15
            frame_data.append(raw)
            total_frames += 1

    peg.data_file_size = _u32(total_size)
    log("Finished loading texture data.")

    log("Writing peg_pc and g_peg_pc files... ", nl=False)
    stem, _ = os.path.splitext(desc_path)
    peg_path = stem + ".peg_pc"
    peg_data_path = stem + ".g_peg_pc"

    with open(peg_path, "wb") as ps:
        ps.write(struct.pack("<I", 0x564B4547))     # GEKV
        ps.write(struct.pack("<H", 10))             # version
        ps.write(struct.pack("<H", _u16(peg.unknown06)))
        ps.write(struct.pack("<I", _u32(peg.file_size)))  # patched below
        ps.write(struct.pack("<I", _u32(peg.data_file_size)))
        ps.write(struct.pack("<H", len(peg.entries)))
        ps.write(struct.pack("<H", _u16(peg.unknown12)))
        ps.write(struct.pack("<H", _u16(total_frames)))
        ps.write(struct.pack("<H", _u16(peg.unknown16)))

        ps.seek(0x18)  # frame structs
        for entry in peg.entries:
            for fr in entry.frames:
                ps.write(fr.to_bytes(big_endian=False))

        ps.seek(0x18 + 0x30 * total_frames)
        for entry in peg.entries:
            ps.write(entry.name.encode("ascii", "replace") + b"\x00")

        file_length = ps.tell()
        ps.seek(0x08)
        ps.write(struct.pack("<I", _u32(file_length)))
        ps.flush()

    with open(peg_data_path, "wb") as ds:
        ds.truncate(peg.data_file_size)
        idx = 0
        for entry in peg.entries:
            for fr in entry.frames:
                ds.seek(fr.offset)
                ds.write(frame_data[idx])
                idx += 1
        ds.flush()

    log("done.")
    log("")
    log("Finished repacking.")


def _rgba_to_bgra(rgba: bytes) -> bytes:
    ba = bytearray(rgba)
    for p in range(0, len(ba), 4):
        ba[p], ba[p + 2] = ba[p + 2], ba[p]
    return bytes(ba)

def _rgba_to_r5g6b5(rgba: bytes, width: int, height: int) -> bytes:
    out = bytearray(width * height * 2)
    for p in range(width * height):
        r, g, b = rgba[p * 4], rgba[p * 4 + 1], rgba[p * 4 + 2]
        v = ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3)
        struct.pack_into("<H", out, p * 2, v)
    return bytes(out)


# =============================================================================
# 6. Help texts
# =============================================================================

ERRORS_TEXT = """\
PEGTOOL ERROR REFERENCE
=======================

* "header must be GEKV" (NotAPegFileException)
  The file is not a PEG package. You probably selected the g_peg_pc data
  file or an unrelated file. Unpack needs the small .peg_pc/.peg_xbox2
  header file, not the big .g_peg_* data file.

* "only version 10 is supported"
  The package uses a format version this tool cannot read. Retail
  Saints Row 2 files are version 10; modded tools from other games may
  not be.

* "WARNING: header file size does not match actual size" (non-fatal)
  The size recorded in the header differs from the file on disk. Common
  after repacking or hand-editing. The tool now continues; check the
  output for garbled textures.

* "frame count is 0" / "frame count mismatch"
  The frame table is inconsistent with the header. The file is likely
  corrupt or was written by a broken tool version. Restore from backup.

* "File is not a peg_pc/peg_xbox2 file" / "<ext> file does not exist"
  Wrong extension, or the g_peg_pc partner file is missing from the
  same directory. Copy both files side by side before unpacking.

* "Unhandled format: X"
  The texture uses a compression format outside the supported set
  (DXT1/3/5, R5G6B5, A8R8G8B8). Nothing was extracted for that frame.

* "Unable to find file: <texture>_N.png" (repack)
  Repack needs, per frame, either a lossless .dds/.raw or a .png. Missing
  files mean an incomplete unpack directory or wrong filenames.

TIP: to verify a repack, unpack the NEW .peg_pc — and remember that
DDS/raw files present during repack are used as-is (lossless), while PNGs
are recompressed.

DDS WORKFLOW NOTES
==================
1. Unpack creates both DDS and PNG for compressed textures
2. DDS files preserve original DXT compression (no quality loss)
3. For repack:
   - Place edited DDS files in the same folder (delete old DDS first!)
   - Tool will use DDS directly without recompression
   - PNG fallback still works but loses quality
4. DDS files work directly with our texture viewer!

ACKNOWLEDGEMENT
===============
This tool is a Python port of PegTool from the GibbedTools suite,
originally written in C# by Rick Gibbed (2010) for Saints Row 2.
All credit for the PEG file format reverse-engineering belongs to
the original author; bugs introduced are the port's own. Credit Also
To Thomas Jepp (Minimaul) for the JeppTools.
"""

USAGE_TEXT = """\
HOW TO USE PEGTOOL (WITH DDS SUPPORT)
=====================================

PegTool manipulates Saints Row 2 PEG texture packages. Every PEG package is
a pair of files living in the same folder:

  *.peg_pc    header: metadata for every texture entry and frame
              (starts with magic "GEKV", version 10)
  g_peg_pc    data blob: the actual pixel data for each frame

(Xbox variants use .peg_xbox2 / g_peg_xbox2 — big-endian.)

UNPACKING (peg_pc -> editable files)
------------------------------------
1. Click "Unpack" (or Action > Unpack...) and pick a .peg_pc or .peg_xbox2
   file. Its g_peg_pc partner must sit in the same directory.
2. The tool writes into that same directory:
     <name>.peg_desc    XML description of the whole package
     <texture>_N.dds    DXT-compressed textures (for game/viewer, NO quality loss)
     <texture>_N.png    every frame decoded to PNG (editable)
     <texture>_N.raw    untouched copy of the frame data (optional)
3. Edit the PNGs with any image editor.

REPACKING (edited files -> peg_pc)
----------------------------------
1. Click "Repack" (or Action > Repack...) and select the .peg_desc file.
2. For each frame the tool uses, in order:
     a) <texture>_N.dds  — DXT data loaded directly (NO RECOMPRESSION) ✨ NEW!
     b) <texture>_N.raw  — as-is if present (lossless, no recompression)
     c) <texture>_N.png  — imported and recompressed to the frame's format
   IMPORTANT: DELETE old DDS/RAW files before replacing with new ones!
   Otherwise the original data wins and your edit is ignored.
3. New .peg_pc and g_peg_pc files are written next to the peg_desc.

DDS WORKFLOW BENEFITS
---------------------
• No quality loss when using DDS files
• Faster repack (no recomputation)
• Works directly with our texture viewer
• Compatible with standard DDS viewers/editors

AUTO-DETECT
-----------
Action > Auto-Detect picks unpack or repack from the file extension,
mirroring the original command-line drag/drop behaviour.

SUPPORTED FORMATS: A8R8G8B8, R5G6B5, DXT1, DXT3, DXT5.

OPTIONS
-------
"Force width=512 on Xbox frames" reproduces a hardcoded behaviour of the
original 2010 tool (it overrode every big-endian frame's width to 512).
Leave it OFF unless you are reproducing old outputs byte-for-byte.

NOTES
-----
* Repack from PNG involves recompression — expect some quality loss
  versus the original .dds/.raw data.
* Always back up your original game files before replacing them.
* DDS files work directly with impview.py textured viewer!
"""

CHANGES_TEXT = """\
WHAT WAS CHANGED FROM THE ORIGINAL C# CODE, AND WHY
===================================================

1. LANGUAGE / RUNTIME PORT
   Program.cs, XmlParser.cs, PegFile.cs, PegEntry.cs and ImageFormats.cs
   were rewritten in Python 3 and consolidated into one file.
   WHY: no .NET Framework 4.0 / Windows-only dependency.

2. GDI+ / System.Drawing REPLACED BY PILLOW
   All Bitmap/LockBits/Marshal.Copy pixel plumbing became PIL Image
   objects. The R/B-channel juggling that existed purely because GDI
   stores pixels as BGRA was reduced to explicit, documented conversions
   (codecs speak RGBA internally).

3. MARSHALLING REPLACED BY struct
   Marshal.StructureToPtr / BytesToStructure became struct.pack/unpack
   with an endianness-aware format string. The 48-byte PegFrame layout
   was verified against the C# FieldOffsets (contiguous, no padding).

4. squish.dll NOW OPTIONAL
   The original P/Invoked squish.dll for DXT compress/decompress. This
   port loads the same library via ctypes if present (libsquish.so on
   Linux/macOS) and otherwise falls back to a built-in pure-Python DXT
   codec. CAVEAT: the fallback compressor is simpler than libSquish's
   iterative cluster fit — for best quality build/install libsquish.

5. BUG FIX — BIG-ENDIAN R5G6B5 CRASH
   The original called ByteSwap(raw, R5G6B5) on Xbox files, but ByteSwap
   had no R5G6B5 case and threw "Unhandled format". FIXED: a u16
   word-swap branch was added; Xbox R5G6B5 textures now unpack.

6. BUG FIX — BIG-ENDIAN DXT3/DXT5 COLORS
   The original only byte-swapped A8R8G8B8, R5G6B5 and DXT1 data on
   big-endian files; DXT3/5 reached the decoder with byte-reversed u16
   color endpoints, producing scrambled colors on Xbox textures.
   FIXED: endianness correction moved into the codec
   (_fix_block_endianness + big_endian parameter on compress/decompress).
   CAVEAT: implemented by symmetry with the proven DXT1 path — verify on
   one known Xbox file before bulk-converting.

7. BUG FIX (in this port's history) — COMPRESSED BUFFER SIZE
   An early version of the port computed the squish output buffer as
   len/2 for DXT1 instead of len/8 (C# used Length/8). Corrected.

8. HARDCODED WIDTH=512 HACK MADE OPTIONAL
   The original forced every Xbox frame's Width to 512 after the endian
   swap — almost certainly a hack that is wrong for non-512 textures.
   Now an explicit GUI option, default OFF.

9. NEW FEATURE: DDS OUTPUT SUPPORT (MODIFIED FOR YOUR NEEDS!)
   - Unpack now creates .dds files for DXT-compressed textures
   - DDS files preserve original DXT1/DXT3/DXT5 compression (no quality loss)
   - Repack accepts .dds files directly (no recompression needed)
   - DDS files work with standard viewers AND our impview.py texture viewer
   - PNG files still created for visualization/editing purposes

10. DEAD CODE REMOVED
    - keepAlpha parameter did nothing in the original (body commented
      out); retained and documented.
    - #if DEBUG console pauses dropped — a GUI has no console to hold.
    - AssemblyInfo.cs / app.config / .csproj are MSBuild boilerplate.

11. XML I/O
    XmlTextWriter / XmlDocument became xml.etree.ElementTree with tab
    indentation preserved for compatibility. Parsing is deliberately
    tolerant: malformed numeric fields fall back to 0 with a warning.

12. KNOWN LIMITATIONS INHERITED FROM THE ORIGINAL
    - Repack of DXT-compressed frames recompresses from PNG (quality
      loss) unless the lossless .dds or .raw is kept.
    - Only little-endian (PC) output is produced on repack, as the
      original did.
    - DDS output only for DXT formats (DXT1/DXT3/DXT5), not uncompressed.
"""


# =============================================================================
# 7. GUI (Tkinter) — bg #000000, fg #00FF90, highlight deep purple
# =============================================================================

BG        = "#000000"
FG        = "#00FF90"
HL        = "#4B0082"   # deep purple highlight/selection
HL_HOVER  = "#5C0099"
ERR_COLOR = "#FF5555"
FONT_MONO = ("Consolas", 15)
FONT_UI   = ("TkDefaultFont", 10)


class PegToolGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.logq: queue.Queue = queue.Queue()

        root.title("PegTool — Saints Row 2 Texture Tool (Python port + DDS)")
        root.geometry("900x600")
        root.configure(bg=BG)

        self._style_ttk()
        self._build_menu()
        self._build_widgets()
        self._poll_log_queue()

    # -- styling -------------------------------------------------------------

    def _style_ttk(self):
        try:
            s = ttk.Style()
            s.theme_use("clam")
            s.configure(".", background=BG, foreground=FG,
                        fieldbackground=BG, bordercolor=HL)
            s.configure("TScrollbar", background=HL, troughcolor=BG)
        except tk.TclError:
            pass

    # -- widgets -------------------------------------------------------------

    def _build_menu(self):
        menubar = tk.Menu(self.root, bg=BG, fg=FG,
                          activebackground=HL, activeforeground="#FFFFFF")
        mk = dict(tearoff=0, bg=BG, fg=FG,
                  activebackground=HL, activeforeground="#FFFFFF")

        m_action = tk.Menu(menubar, **mk)
        m_action.add_command(label="Unpack peg_pc / peg_xbox2...",
                             command=self.act_unpack)
        m_action.add_command(label="Repack peg_desc...", command=self.act_repack)
        m_action.add_command(label="Auto-Detect Convert...", command=self.act_auto)
        m_action.add_command(label="Error Reference...",
                             command=lambda: self.show_doc("Errors \& Meanings", ERRORS_TEXT))
        m_action.add_separator()
        m_action.add_command(label="Quit", command=self.root.destroy)
        menubar.add_cascade(label="Action", menu=m_action)

        m_opts = tk.Menu(menubar, **mk)
        self.var_w512 = tk.BooleanVar(value=False)
        m_opts.add_checkbutton(
            label="Force width=512 on Xbox frames (original tool behaviour)",
            variable=self.var_w512, selectcolor=HL)
        m_opts.add_checkbutton(
            label="Output DDS for compressed textures (recommended)",
            variable=tk.BooleanVar(value=True), selectcolor=HL)  # Always enabled now
        menubar.add_cascade(label="Options", menu=m_opts)

        m_help = tk.Menu(menubar, **mk)
        m_help.add_command(label="How to Use",
                           command=lambda: self.show_doc("How to Use PegTool",
                                                         USAGE_TEXT))
        m_help.add_command(label="Changes from the Original C# Tool",
                           command=lambda: self.show_doc("Changes & Rationale",
                                                         CHANGES_TEXT))
        m_help.add_separator()
        m_help.add_command(label="About", command=lambda: messagebox.showinfo(
            "About",
            "PegTool — Python port of Gibbed's Saints Row 2 PegTool.\n"
            "Original C# © 2010 (Rick Gibbed). Port + GUI 2026.\n"
            "DDS support added 2026.",
            parent=self.root))
        menubar.add_cascade(label="Help", menu=m_help)

        self.root.config(menu=menubar)

    def _build_widgets(self):
        bar = tk.Frame(self.root, bg=BG)
        bar.pack(fill="x", padx=8, pady=(8, 4))

        for label, cmd in (("Unpack", self.act_unpack),
                           ("Repack", self.act_repack),
                           ("Auto-Detect", self.act_auto)):
            tk.Button(bar, text=label, command=cmd, bg=HL, fg="#FFFFFF",
                      activebackground=HL_HOVER, activeforeground="#FFFFFF",
                      relief="flat", padx=14).pack(side="left", padx=(0, 8))

        self.status = tk.Label(self.root, text="Ready.", anchor="w",
                               bg=BG, fg=FG)
        self.status.pack(fill="x", padx=8)

        self.logw = ScrolledText(self.root, wrap="word", font=FONT_MONO,
                                 bg=BG, fg=FG, insertbackground=FG,
                                 selectbackground=HL, selectforeground="#FFFFFF",
                                 relief="flat")
        self.logw.pack(fill="both", expand=True, padx=8, pady=8)
        self.logw.tag_config("err", foreground=ERR_COLOR)
        self.logw.config(state="disabled")

        self.log("PegTool — Saints Row 2 texture tool (Python port + DDS)")
        self.log("NEW: Unpacked compressed textures saved as DDS files!")
        self.log("Note: When Updating A Peg File Delete The OLD DDS/RAW Images")
        self.log("Before Rebuilding Or It Will Not Work.")
        self.log("")

    # -- logging (thread-safe) ----------------------------------------------

    def log(self, msg="", nl=True):
        self.logq.put(msg + ("\n" if nl else ""))

    def _poll_log_queue(self):
        dirty = False
        try:
            while True:
                msg = self.logq.get_nowait()
                self.logw.config(state="normal")
                self.logw.insert("end", msg)
                self.logw.see("end")
                dirty = True
        except queue.Empty:
            pass
        if dirty:
            self.logw.config(state="disabled")
        self.root.after(80, self._poll_log_queue)

    # -- help window -----------------------------------------------------------

    def show_doc(self, title: str, text: str):
        win = tk.Toplevel(self.root, bg=BG)
        win.title(title)
        win.geometry("720x560")
        txt = ScrolledText(win, wrap="word", font=FONT_MONO, bg=BG, fg=FG,
                           insertbackground=FG, selectbackground=HL,
                           selectforeground="#FFFFFF")
        txt.pack(fill="both", expand=True)
        txt.insert("1.0", text)
        txt.config(state="disabled")

    # -- worker threads ------------------------------------------------------

    def _run(self, fn, *args, **kwargs):
        self.status.config(text="Working...")
        def wrapper():
            try:
                fn(*args, **kwargs, log=self.log)
                self.logq.put("\nDone.\n")
            except Exception:
                import traceback
                self.logq.put("\nERROR:\n" + traceback.format_exc() + "\n")
            finally:
                self.root.after(0, lambda: self.status.config(text="Ready."))
        threading.Thread(target=wrapper, daemon=True).start()


    # -- actions ----------------------------------------------------------------

    def act_unpack(self):
        path = filedialog.askopenfilename(
            parent=self.root, title="Select a .peg_pc / .peg_xbox2 file",
            filetypes=[("PEG files", "*.peg_pc *.peg_xbox2"),
                       ("All files", "*.*")])
        if path:
            self._run(unpack, path, self.var_w512.get(), output_dds=True)

    def act_repack(self):
        path = filedialog.askopenfilename(
            parent=self.root, title="Select a .peg_desc file",
            filetypes=[("PEG descriptions", "*.peg_desc"), ("All files", "*.*")])
        if path:
            self._run(repack, path)

    def act_auto(self):
        path = filedialog.askopenfilename(
            parent=self.root, title="Select any PEG-related file",
            filetypes=[("PEG files", "*.peg_pc *.peg_xbox2 *.peg_desc"),
                       ("All files", "*.*")])
        if not path:
            return
        ext = os.path.splitext(path)[1].lower()
        if ext in (".peg_pc", ".peg_xbox2"):
            self._run(unpack, path, self.var_w512.get(), output_dds=True)
        elif ext == ".peg_desc":
            self._run(repack, path)

        else:
            self.log(f"Unrecognised extension: {ext} (expected .peg_pc, "
                     f".peg_xbox2 or .peg_desc)\n")


def main():
    root = tk.Tk()
    PegToolGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
