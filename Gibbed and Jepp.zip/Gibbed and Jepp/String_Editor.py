#!/usr/bin/env python3.10
# -*- coding: utf-8 -*-
"""
StringHashTool — Python port of Rick Gibbed's Saints Row 2 String Hash Tool.

v1.2: added le_strings writer, in-place string editing, and themed widgets.

Acknowledgements:
  Created from source provided by Rick Gibbed (Gibbed Tools for Saints Row 2).
  Also acknowledges Thomas Jepp (JeppTools).
"""

import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext

BG_COLOR = "#000000"      # background
FG_COLOR = "#00FF90"      # foreground
HL_BG    = "#4B0082"      # selection background (deep purple)
FONT     = ("Consolas", 10)

ERROR_CODES = {
    "ERR-001": "Invalid file magic: not a valid le_strings file.",
    "ERR-002": "Unsupported version field in file header (expected 1).",
    "ERR-003": "Duplicate hash while loading: file index is corrupt.",
    "ERR-004": "Malformed hexadecimal or decimal number.",
    "ERR-005": "String exceeded the 4096-byte safety buffer.",
    "ERR-006": "Truncated or unreadable file.",
    "ERR-007": "Empty input: hashing requires at least one character.",
}

class ToolError(Exception):
    def __init__(self, code, detail=""):
        self.code = code
        self.detail = detail
        super().__init__(code + ": " + detail)

# ================================================================ hash logic
def _get_crc_table():
    global _CRC_TABLE
    try:
        return _CRC_TABLE
    except NameError:
        t = []
        for i in range(256):
            crc = i
            for _ in range(8):
                crc = (crc >> 1) ^ 0xEDB88320 if crc & 1 else crc >> 1
            t.append(crc)
        _CRC_TABLE = t
        return t

def crc32_standard(data):
    table = _get_crc_table()
    crc = 0xFFFFFFFF
    for b in data:
        crc = (crc >> 8) ^ table[(crc ^ b) & 0xFF]
    return crc ^ 0xFFFFFFFF

def crc32_broken(data):
    table = _get_crc_table()
    crc = 0x00000000
    for b in data:
        crc = (crc >> 8) ^ table[(crc ^ b) & 0xFF]
    return crc

def crc_volition(text):
    table = _get_crc_table()
    h = 0
    for ch in text.lower():
        h = table[(h ^ (ord(ch) & 0xFF)) & 0xFF] ^ (h >> 8)
    return h & 0xFFFFFFFF

def hash_volition(text):
    h = 0
    for ch in text:
        c = ord(ch)
        if 0x41 <= c <= 0x5A:
            c += 0x20
        h = ((h << 6) | (h >> 26)) & 0xFFFFFFFF
        h ^= c & 0xFFFFFFFF
    return h & 0xFFFFFFFF

def parse_hex_u32(text):
    s = text.strip()
    try:
        v = int(s[2:], 16) if s.lower().startswith("0x") else int(s, 10)
    except ValueError:
        raise ToolError("ERR-004", "'" + text + "' is not a valid 32-bit number")
    if not 0 <= v <= 0xFFFFFFFF:
        raise ToolError("ERR-004", "'" + s + "' out of UInt32 range")
    return v

def parse_hex_u64(text):
    s = text.strip()
    try:
        v = int(s[2:], 16) if s.lower().startswith("0x") else int(s, 10)
    except ValueError:
        raise ToolError("ERR-004", "'" + text + "' is not a valid 64-bit number")
    if not 0 <= v <= 0xFFFFFFFFFFFFFFFF:
        raise ToolError("ERR-004", "'" + s + "' out of UInt64 range")
    return v

# ======================================================== le_strings reader
def read_le_strings(source):
    """
    Read a Saints Row 2 .le_strings file.

    Returns:
        (header, strings)

    strings maps:
        big-endian uint32 hash -> decoded text
    """
    if hasattr(source, "read"):
        data = source.read()
    else:
        with open(source, "rb") as f:
            data = f.read()

    HEADER_SIZE = 12
    INDEX_SLOTS = 1024
    INDEX_ENTRY_SIZE = 8
    DATA_OFFSET = HEADER_SIZE + INDEX_SLOTS * INDEX_ENTRY_SIZE

    if len(data) < DATA_OFFSET:
        raise ValueError(
            "File is too short for the header and 1024 index entries"
        )

    header = data[:HEADER_SIZE]

    if header[:4] != b"\x73\x7f\x4c\xa8":
        raise ValueError(
            f"Invalid .le_strings signature: {header[:4].hex(' ')}"
        )

    # The slot count is unsigned.
    slot_count = int.from_bytes(data[6:8], "little", signed=False)

    if slot_count != INDEX_SLOTS:
        raise ValueError(
            f"Expected {INDEX_SLOTS} index slots, got {slot_count}"
        )

    strings = {}

    for slot in range(INDEX_SLOTS):
        index_pos = HEADER_SIZE + slot * INDEX_ENTRY_SIZE

        block_count = int.from_bytes(
            data[index_pos:index_pos + 4],
            "little",
            signed=False,
        )
        block_offset = int.from_bytes(
            data[index_pos + 4:index_pos + 8],
            "little",
            signed=False,
        )

        # Unused index entries are zero-filled.
        if block_count == 0 or block_offset == 0:
            continue

        table_end = block_offset + block_count * 4

        if block_offset < DATA_OFFSET or table_end > len(data):
            raise ValueError(
                f"Invalid pointer table in index slot {slot}: "
                f"offset=0x{block_offset:x}, count={block_count}"
            )

        for pointer_index in range(block_count):
            pointer_pos = block_offset + pointer_index * 4

            record_offset = int.from_bytes(
                data[pointer_pos:pointer_pos + 4],
                "little",
                signed=False,
            )

            # A zero pointer is an unused record.
            if record_offset == 0:
                continue

            if record_offset + 4 > len(data):
                raise ValueError(
                    f"Invalid record offset 0x{record_offset:x}"
                )

            hash_value = int.from_bytes(
                data[record_offset:record_offset + 4],
                "big",
                signed=False,
            )

            text_start = record_offset + 4
            text_pos = text_start

            while True:
                if text_pos + 2 > len(data):
                    raise ValueError(
                        f"Unterminated UTF-16-BE string at "
                        f"0x{record_offset:x}"
                    )

                if data[text_pos:text_pos + 2] == b"\x00\x00":
                    break

                text_pos += 2

            text = data[text_start:text_pos].decode("utf-16-be")
            strings[hash_value] = text

    return header, strings

# ======================================================== le_strings writer
def write_le_strings(destination, header, strings):
    """
    Write a Saints Row 2 .le_strings file.

    The header must be the original 12-byte header. Exactly 1024
    eight-byte index entries are written after it.
    """
    HEADER_SIZE = 12
    INDEX_SLOTS = 1024
    INDEX_ENTRY_SIZE = 8
    BLOCK_SIZE = 256
    DATA_OFFSET = HEADER_SIZE + INDEX_SLOTS * INDEX_ENTRY_SIZE

    if len(header) != HEADER_SIZE:
        raise ValueError("The header must be exactly 12 bytes")

    if header[:4] != b"\x73\x7f\x4c\xa8":
        raise ValueError("Invalid .le_strings signature")

    # The original header already contains the slot count.
    slot_count = int.from_bytes(header[6:8], "little", signed=False)

    if slot_count != INDEX_SLOTS:
        raise ValueError(
            f"Expected {INDEX_SLOTS} index slots, got {slot_count}"
        )

    # Preserve all 12 header bytes. Do not append another count.
    out = bytearray(header)

    # Reserve exactly 1024 index entries.
    index_start = len(out)
    out += b"\x00" * (INDEX_SLOTS * INDEX_ENTRY_SIZE)

    if len(out) != DATA_OFFSET:
        raise AssertionError(
            f"First data offset is 0x{len(out):x}, "
            f"expected 0x{DATA_OFFSET:x}"
        )

    items = list(strings.items())

    blocks = [
        items[i:i + BLOCK_SIZE]
        for i in range(0, len(items), BLOCK_SIZE)
    ]

    if len(blocks) > INDEX_SLOTS:
        raise ValueError(
            f"Too many strings: {len(blocks)} blocks required, "
            f"but only {INDEX_SLOTS} index slots are available"
        )

    index_entries = []

    for block in blocks:
        pointer_table_offset = len(out)

        # Reserve the pointer table.
        out += b"\x00" * (len(block) * 4)

        record_offsets = []

        for hash_value, text in block:
            if not 0 <= hash_value <= 0xffffffff:
                raise ValueError(
                    f"Hash is outside uint32 range: {hash_value!r}"
                )

            if not isinstance(text, str):
                raise TypeError("String values must be str")

            record_offset = len(out)
            record_offsets.append(record_offset)

            out += int(hash_value).to_bytes(4, "big", signed=False)
            out += text.encode("utf-16-be")
            out += b"\x00\x00"

        # Fill this block's pointer table with absolute offsets.
        for pointer_index, record_offset in enumerate(record_offsets):
            pointer_pos = pointer_table_offset + pointer_index * 4

            out[pointer_pos:pointer_pos + 4] = int(
                record_offset
            ).to_bytes(4, "little", signed=False)

        index_entries.append((len(block), pointer_table_offset))

    # Write only the used entries. The remaining entries stay zero-filled.
    for slot, (block_count, block_offset) in enumerate(index_entries):
        index_pos = index_start + slot * INDEX_ENTRY_SIZE

        out[index_pos:index_pos + 4] = int(
            block_count
        ).to_bytes(4, "little", signed=False)

        out[index_pos + 4:index_pos + 8] = int(
            block_offset
        ).to_bytes(4, "little", signed=False)

    if hasattr(destination, "write"):
        destination.write(out)
    else:
        with open(destination, "wb") as f:
            f.write(out)

def roundtrip_selftest(game_path):
    """Read the real file, rewrite it, read the rewrite back, compare.
    Returns (ok, detail)."""
    original = read_le_strings(game_path)
    tmp = "/tmp/lestrings_roundtrip_test.le_strings"
    write_le_strings(tmp, original)
    rewritten = read_le_strings(tmp)
    if original == rewritten and len(rewritten) == len(original):
        return True, "%d strings identical" % len(original)
    diffs = sum(1 for k in original
                if k not in rewritten or rewritten[k] != original[k])
    return False, "%d of %d strings differ" % (diffs, len(original))

# ==================================================================== the GUI
class StringHashTool(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("String Hash Tool — SR2 (Gibbed port)")
        self.geometry("760x640")
        self.configure(bg=BG_COLOR)
        self._strings = {}          # hash -> text (editable)
        self._key_order = []        # hashes in listbox order
        self._open_path = None
        self._orig_head = None
        self._dirty = False
        self._build_menu()
        self._build_widgets()

    # ---------------------------------------------------------------- menu bar
    def _build_menu(self):
        m = tk.Menu(self, bg=BG_COLOR, fg=FG_COLOR,
                    activebackground=HL_BG, activeforeground=FG_COLOR)
        self.config(menu=m)

        file_m = tk.Menu(m, tearoff=0, bg=BG_COLOR, fg=FG_COLOR,
                         activebackground=HL_BG, activeforeground=FG_COLOR)
        file_m.add_command(label="Open strings file…", command=self.open_file)
        file_m.add_command(label="Save strings file as…", command=self.save_file)
        file_m.add_command(label="Clear", command=self.clear_input)
        file_m.add_separator()
        file_m.add_command(label="Exit", command=self.confirm_exit)
        m.add_cascade(label="File", menu=file_m)

        help_m = tk.Menu(m, tearoff=0, bg=BG_COLOR, fg=FG_COLOR,
                         activebackground=HL_BG, activeforeground=FG_COLOR)
        help_m.add_command(label="Help / Overview",
                           command=lambda: self._help_win("Help", _TXT_HELP))
        help_m.add_command(label="Code Changes Explained",
                           command=lambda: self._help_win("Code Changes",
                                                          _TXT_CHANGES))
        help_m.add_command(label="How To Use",
                           command=lambda: self._help_win("How To Use",
                                                          _TXT_USAGE))
        help_m.add_command(label="Error Codes",
                           command=lambda: self._help_win("Error Codes",
                                                          _TXT_ERRORS))
        help_m.add_separator()
        help_m.add_command(label="Acknowledgements",
                           command=lambda: self._help_win("Acknowledgements",
                                                          _TXT_ACK))
        m.add_cascade(label="Help", menu=help_m)

    # ------------------------------------------------------------- main frame
    def _build_widgets(self):
        # --- hash input -----------------------------------------------------
        tk.Label(self, text="String:", bg=BG_COLOR, fg=FG_COLOR,
                 font=FONT).grid(row=0, column=0, sticky="nw", padx=8, pady=6)
        self.input_txt = tk.Text(self, height=5, width=60, font=FONT,
                                 bg=BG_COLOR, fg=FG_COLOR,
                                 insertbackground=FG_COLOR,
                                 selectbackground=HL_BG,
                                 selectforeground=FG_COLOR)
        self.input_txt.grid(row=0, column=1, columnspan=2, sticky="nsew",
                            padx=8, pady=6)
        self.input_txt.bind("<KeyRelease>", lambda e: self.update_hashes())

        self.outputs = {}
        row = 1
        for name, fn in (("CRC32", crc32_standard),
                         ("KeyCRC32 (broken)", crc32_broken),
                         ("CrcVolition", crc_volition),
                         ("HashVolition", hash_volition)):
            tk.Label(self, text=name + ":", bg=BG_COLOR, fg=FG_COLOR,
                     font=FONT).grid(row=row, column=0, sticky="e",
                                     padx=12, pady=2)
            box = tk.Entry(self, font=FONT, bg=BG_COLOR, fg=FG_COLOR,
                           insertbackground=FG_COLOR, selectbackground=HL_BG,
                           selectforeground=FG_COLOR,
                           readonlybackground=BG_COLOR)
            box.configure(state="readonly")
            box.grid(row=row, column=1, columnspan=2, sticky="ew",
                     padx=12, pady=2)
            self.outputs[name] = box
            row += 1

        # --- editor ----------------------------------------------------------
        tk.Label(self, text="Strings:", bg=BG_COLOR, fg=FG_COLOR,
                 font=FONT).grid(row=row, column=0, sticky="ne",
                                 padx=12, pady=(12, 2))
        self.strings_list = tk.Listbox(self, height=12, font=FONT,
                                       bg=BG_COLOR, fg=FG_COLOR,
                                       selectbackground=HL_BG,
                                       selectforeground=FG_COLOR,
                                       activestyle="none",
                                       exportselection=False)
        self.strings_list.grid(row=row, column=1, sticky="nsew",
                               padx=(12, 4), pady=(12, 2))
        sb = tk.Scrollbar(self, command=self.strings_list.yview,
                          troughcolor=BG_COLOR, bg=BG_COLOR,
                          activebackground=HL_BG)
        self.strings_list.configure(yscrollcommand=sb.set)
        sb.grid(row=row, column=2, sticky="ns", padx=(0, 12), pady=(12, 2))
        self.strings_list.bind("<<ListboxSelect>>",
                               lambda e: self.load_selected())
        row += 1

        tk.Label(self, text="Edit text:", bg=BG_COLOR, fg=FG_COLOR,
                 font=FONT).grid(row=row, column=0, sticky="ne",
                                 padx=12, pady=2)
        self.edit_txt = tk.Text(self, height=3, font=FONT,
                                bg=BG_COLOR, fg=FG_COLOR,
                                insertbackground=FG_COLOR,
                                selectbackground=HL_BG,
                                selectforeground=FG_COLOR)
        self.edit_txt.grid(row=row, column=1, columnspan=2, sticky="nsew",
                           padx=12, pady=2)
        row += 1

        tk.Button(self, text="Apply change to selected string",
                  command=self.apply_change, bg=BG_COLOR, fg=FG_COLOR,
                  activebackground=HL_BG, activeforeground=FG_COLOR,
                  highlightbackground=BG_COLOR
                  ).grid(row=row, column=1, sticky="w", padx=12, pady=4)
        row += 1

        # --- hex parser -------------------------------------------------------
        tk.Label(self, text="Hex / decimal:", bg=BG_COLOR, fg=FG_COLOR,
                 font=FONT).grid(row=row, column=0, sticky="e",
                                 padx=12, pady=(8, 2))
        self.hex_in = tk.Entry(self, font=FONT, bg=BG_COLOR, fg=FG_COLOR,
                               insertbackground=FG_COLOR,
                               selectbackground=HL_BG,
                               selectforeground=FG_COLOR)
        self.hex_in.grid(row=row, column=1, sticky="ew", padx=12, pady=(12, 2))
        self.hex_in.bind("<Return>", lambda e: self.parse_number())
        row += 1

        tk.Button(self, text="Parse as UInt32 / UInt64",
                  command=self.parse_number, bg=BG_COLOR, fg=FG_COLOR,
                  activebackground=HL_BG, activeforeground=FG_COLOR,
                  highlightbackground=BG_COLOR
                  ).grid(row=row, column=1, sticky="w", padx=12, pady=4)
        row += 1

        self.status = tk.Label(self, text="Ready.", anchor="w",
                               bg=BG_COLOR, fg=FG_COLOR, font=FONT)
        self.status.grid(row=row, column=0, columnspan=3, sticky="ew",
                         padx=12, pady=8)

        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        self.rowconfigure(row - 4, weight=2)

    # --------------------------------------------------------------- actions
    def update_hashes(self):
        text = self.input_txt.get("1.0", "end").rstrip("\n")
        for name, fn in (("CRC32", crc32_standard),
                         ("KeyCRC32 (broken)", crc32_broken),
                         ("CrcVolition", crc_volition),
                         ("HashVolition", hash_volition)):
            box = self.outputs[name]
            box.configure(state="normal")
            box.delete(0, "end")
            if text:
                box.insert(0, "0x%08X" % fn(text))
            box.configure(state="readonly")

    def parse_number(self):
        s = self.hex_in.get()
        try:
            u32 = parse_hex_u32(s)
            msg = "UInt32: 0x%08X (%d)" % (u32, u32)
            try:
                u64 = parse_hex_u64(s)
                msg += "   |   UInt64: 0x%016X (%d)" % (u64, u64)
            except ToolError:
                pass
            self.status.configure(text=msg)
        except ToolError as err:
            self.show_error(err)

    def clear_input(self):
        self.input_txt.delete("1.0", "end")
        self.update_hashes()
        self.edit_txt.delete("1.0", "end")
        self.status.configure(text="Ready.")

    # ---- strings file editing ---------------------------------------------
    def refresh_list(self, keep=None):
        self.strings_list.delete(0, "end")
        self._key_order = sorted(self._strings)
        for h in self._key_order:
            self.strings_list.insert("end", "0x%08X -> %s" %
                                     (h, self._strings[h]))
        if keep is not None and keep in self._key_order:
            idx = self._key_order.index(keep)
            self.strings_list.selection_set(idx)
            self.strings_list.see(idx)

    def load_selected(self):
        sel = self.strings_list.curselection()
        if not sel:
            return
        h = self._key_order[sel[0]]
        self.edit_txt.delete("1.0", "end")
        self.edit_txt.insert("1.0", self._strings[h])

    def apply_change(self):
        sel = self.strings_list.curselection()
        if not sel or not self._key_order:
            self.status.configure(
                text="Select a string in the list first, then edit and apply.")
            return
        h = self._key_order[self.strings_list.curselection()[0]]
        new_text = self.edit_txt.get("1.0", "end").rstrip("\n")
        if self._strings[h] == new_text:
            self.status.configure(text="No change for 0x%08X." % h)
            return
        self._strings[h] = new_text
        self._dirty = True
        self.refresh_list(keep=h)
        self.status.configure(
            text="Updated 0x%08X. Use File -> Save to write the file." % h)

    def open_file(self):
        path = filedialog.askopenfilename(
            title="Open Saints Row 2 strings file", parent=self,
            filetypes=[("LE strings files", "*.le_strings"),
                       ("All files", "*.*")])
        if not path:
            return
        try:
            self._orig_head, self._strings = read_le_strings(path)
        except ToolError as err:
            self.show_error(err)
            return
        except Exception as e:
            self.show_error(ToolError("ERR-006", repr(e)))
            return
        self._open_path = path
        self._dirty = False
        self.refresh_list()
        self.status.configure(
            text="Loaded %d strings from %s." %
                 (len(self._strings), path.rsplit("/", 1)[-1]))

    def save_file(self):
        if not self._strings:
            self.status.configure(
                text="Nothing to save - open a strings file first.")
            return
        path = filedialog.asksaveasfilename(
            title="Save strings file as", parent=self,
            initialfile=(self._open_path.rsplit("/", 1)[-1]
                         if self._open_path else "strings.le_strings"),
            defaultextension=".le_strings",
            filetypes=[("LE strings files", "*.le_strings")])
        if not path:
            return
        try:
            write_le_strings(path, self._orig_head, self._strings)
        except Exception as e:
            self.show_error(ToolError("ERR-006", repr(e)))
            return
        self._dirty = False
        self.status.configure(text="Saved %d strings to %s." %
                                 (len(self._strings), path.rsplit("/", 1)[-1]))

    def confirm_exit(self):
        if self._dirty:
            if not messagebox.askyesno(
                    "Unsaved changes",
                    "You have unsaved string edits. Quit anyway?",
                    parent=self):
                return
        self.destroy()

    def show_error(self, err):
        desc = ERROR_CODES.get(err.code, "Unknown error.")
        try:
            messagebox.showerror(err.code, desc + "\n\nDetails: " + err.detail,
                                 parent=self)
        except tk.TclError:
            print(err.code, desc, err.detail)
        self.status.configure(text=err.code + ": " + desc)

    def _help_win(self, title, body):
        win = tk.Toplevel(self)
        win.title(title)
        win.configure(bg=BG_COLOR)
        txt = scrolledtext.ScrolledText(
            win, wrap="word", font=FONT, bg=BG_COLOR, fg=FG_COLOR,
            insertbackground=FG_COLOR, selectbackground=HL_BG,
            selectforeground=FG_COLOR, padx=12, pady=10)
        txt.insert("1.0", body)
        txt.configure(state="disabled")
        txt.pack(fill="both", expand=True)
        win.geometry("700x560")

# ------------------------------------------------------------- help contents
_TXT_CHANGES = """CHANGES MADE TO THE ORIGINAL C# CODE
=====================================

1. CRC32.HashCore loop bound (Gibbed CRC32.cs)
   Original: for (int i = offset; i < count; i++)
   Fixed: iterate [offset, offset + count). The original read the wrong
   bytes when offset > 0. The Python port iterates the byte sequence,
   so the bug cannot recur.

2. Impossible file magic (LeStringsFile.cs)
   The literal 0x0A84C7F73 is 33 bits and cannot come from a 32-bit read.
   The accepted signature (73 7F 4C A8) was confirmed against a real
   Saints Row 2 strings file with a hex dump.

3. Signed Int16 swap (NumberHelpers.cs)
   The Int16 overload computed uvalue but shifted the signed value.
   All swaps in the port use int.to_bytes/from_bytes.

4. Stream read validation (StreamHelpers.cs)
   Stream.Read return values were ignored; short reads produced silent
   zeros. All file access validates lengths and raises ERR-006.

5. Endianness fix (v1.0.1)
   String text is UTF-16 big-endian on disk (Gibbed's .Swap() chain);
   decoding it little-endian produced CJK garbage. Fixed to utf-16-be.

6. NEW: le_strings writer (no equivalent in Gibbed's source)
   Serializes a hash->text mapping back to Volition's format: signature,
   version, index of count/offset pairs, per-block pointer tables
   (absolute file offsets) and records (big-endian hash + UTF-16-BE
   text + zero terminator). Verified by round-trip test.

7. In-place editing (new)
   Click a string in the list, edit it in the text pane, Apply commits
   it to the in-memory table, File -> Save writes a new le_strings file.
   The original header (including unknown 4 bytes) is preserved.

8. Colour scheme enforced on all widgets
   Every text widget, entry, listbox, scrollbar and menu now uses the
   specified scheme: black #000000 background, green #00FF90 text,
   deep-purple #4B0082 selection. Note: native file-open/file-save
   dialogs are drawn by the operating system and cannot be re-themed
   from within the program.
"""

_TXT_USAGE = """HOW TO USE THE STRING HASH TOOL
===============================

Hashing a string
  1. Type or paste text into the box labelled 'String:'.
  2. All four hashes update on every keystroke:
       CRC32 / KeyCRC32 / CrcVolition / HashVolition
  3. Results show as 0x-prefixed 8-digit hex.

Editing a strings file
  1. File -> Open strings file... and pick a .le_strings file.
  2. The strings list (lower pane) shows HASH -> text pairs.
  3. Click a line: the text appears in the Edit box below.
  4. Change the text, then click 'Apply change to selected string'.
     The list updates and the file is marked as modified.
  5. File -> Save strings file as... writes your edited table to a
     NEW le_strings file. Your original on disk is never touched by
     editing - only by saving over it, so keep backups.
  6. If you try to exit with unsaved edits, you will be warned.

Searching tip
  Click into the list and type the first letters of a string, or
  scroll; the list is sorted by hash value.

Encoding note
  Text is stored as UTF-16 big-endian, exactly as Volition's format
  requires. Ordinary letters, digits and punctuation round-trip
  perfectly; exotic symbols may depend on the fonts the game uses.
"""

_TXT_ERRORS = """ERROR CODES
===========

ERR-001  Invalid file magic. The file does not begin with the expected
         le_strings signature (real signature: 73 7F 4C A8).

ERR-002  Unsupported version. The header version field is not 1.

ERR-003  Duplicate hash. Two entries resolved to the same key while
         loading; the file index is corrupt.

ERR-004  Malformed number. Valid forms: 0xDEADBEEF, DEADBEEF (hex),
         3735928559 (decimal).

ERR-005  String too long. A string exceeded the 4096-byte safety
         buffer; the file is malformed.

ERR-006  Truncated stream. The file ended before its headers/index
         claimed, or it could not be read from disk.

ERR-007  Empty input. Hashing was attempted with no text supplied.
"""

_TXT_ACK = """ACKNOWLEDGEMENTS
================

This tool was created from source code provided by Rick Gibbed,
from his Gibbed Tools for Saints Row 2
(CrcVolition, HashVolition, CRC32/BrokenCRC32, the le_strings reader
and the associated helper classes).

Also acknowledged: Thomas Jepp, for JeppTools
(his independent Saints Row tooling has long served the modding
community).

All porting work, bug corrections, the Python GUI, and the le_strings
writer are new work built on top of that original, freely shared
source.
"""

if __name__ == "__main__":
    app = StringHashTool()
    app.mainloop()
