from __future__ import annotations

import os
import struct
import threading
import traceback
from dataclasses import dataclass
from pathlib import Path
from tkinter import (
    Tk, Toplevel, Text, StringVar, BooleanVar, Listbox, END,
    filedialog, messagebox, ttk
)

MAGIC = 0x51890ACE
VERSION = 4

BG = "#000000"
FG = "#00FF90"
PURPLE = "#4B0082"
PURPLE_ACTIVE = "#6A0DAD"
DISABLED = "#303030"

HEADER_SIZE = 384
ALIGN_TABLE = 2048
ALIGN_DATA = 16
INDEX_ENTRY_SIZE = 28


def align(value: int, boundary: int) -> int:
    return (value + boundary - 1) // boundary * boundary


def read_exact(stream, size: int) -> bytes:
    data = stream.read(size)
    if len(data) != size:
        raise ValueError(
            f"Unexpected end of file: expected {size} bytes, got {len(data)}."
        )
    return data


def read_aligned(stream, size: int, boundary: int) -> bytes:
    data = read_exact(stream, size)
    padding = align(size, boundary) - size
    if padding:
        read_exact(stream, padding)
    return data


def write_aligned(stream, data: bytes, boundary: int) -> None:
    stream.write(data)
    padding = align(len(data), boundary) - len(data)
    if padding:
        stream.write(b"\x00" * padding)


def c_string(data: bytes, offset: int) -> str:
    if offset < 0 or offset >= len(data):
        raise ValueError(f"Invalid string-table offset: {offset}")

    end = data.find(b"\x00", offset)
    if end < 0:
        raise ValueError("Unterminated string in package string table.")

    return data[offset:end].decode("ascii", errors="replace")


@dataclass
class Entry:
    name: str
    extension: str
    offset: int
    uncompressed_size: int
    unknown08: int = 0
    compressed_size: int = -1
    unknown1c: int = 0

    @property
    def filename(self) -> str:
        if self.extension:
            return f"{self.name}.{self.extension}"
        return self.name


def collect_files(
    directories: list[Path],
    recursive: bool,
    log
) -> dict[str, Path]:
    files: dict[str, Path] = {}

    for directory in directories:
        if not directory.is_dir():
            raise FileNotFoundError(f"Input directory does not exist: {directory}")

        iterator = directory.rglob("*") if recursive else directory.glob("*")

        for path in iterator:
            if not path.is_file():
                continue

            if path.suffix.lower() == ".vpp_pc":
                continue

            # VPP_PC stores only a name and extension, not a relative path.
            package_name = path.name

            if package_name in files:
                log(f"Duplicate skipped: {package_name}")
                continue

            files[package_name] = path
            log(f"Added: {path}")

    return files


def build_package(
    output: Path,
    directories: list[Path],
    recursive: bool,
    log
) -> None:
    output = output.expanduser().resolve()

    if output.exists() and output.is_dir():
        raise IsADirectoryError(f"The output path is a directory, not a file:\n{output}")

    output.parent.mkdir(parents=True, exist_ok=True)

    files = collect_files(directories, recursive, log)

    if not files:
        raise ValueError("No files were found to add to the package.")

    # The original program sorts by filename through SortedDictionary.
    ordered = sorted(files.items(), key=lambda item: item[0].lower())

    entries: list[Entry] = []
    file_sources: list[Path] = []

    offset = 0

    for filename, source in ordered:
        file_size = source.stat().st_size

        if file_size > 0x7FFFFFFF:
            raise ValueError(f"File is too large for the VPP_PC format: {source}")

        stem = Path(filename).stem
        extension = Path(filename).suffix[1:]

        entries.append(
            Entry(
                name=stem,
                extension=extension,
                offset=offset,
                uncompressed_size=file_size,
            )
        )

        file_sources.append(source)
        offset += align(file_size, ALIGN_DATA)

    names = sorted({entry.name for entry in entries})
    extensions = sorted({entry.extension for entry in entries})

    name_offsets: dict[str, int] = {}
    extension_offsets: dict[str, int] = {}

    names_buffer = bytearray()
    for name in names:
        name_offsets[name] = len(names_buffer)
        names_buffer.extend(name.encode("ascii", errors="replace"))
        names_buffer.append(0)

    extensions_buffer = bytearray()
    for extension in extensions:
        extension_offsets[extension] = len(extensions_buffer)
        extensions_buffer.extend(extension.encode("ascii", errors="replace"))
        extensions_buffer.append(0)

    index_buffer = bytearray()

    for entry in entries:
        index_buffer.extend(
            struct.pack(
                "<iiIi iiI".replace(" ", ""),
                name_offsets[entry.name],
                extension_offsets[entry.extension],
                entry.unknown08,
                entry.offset,
                entry.uncompressed_size,
                entry.compressed_size,
                entry.unknown1c,
            )
        )

    if len(index_buffer) != len(entries) * INDEX_ENTRY_SIZE:
        raise ValueError("Internal error: invalid index size.")

    uncompressed_data_size = sum(
        align(entry.uncompressed_size, ALIGN_DATA)
        for entry in entries
    )

    package_size = (
        ALIGN_TABLE
        + align(len(index_buffer), ALIGN_TABLE)
        + align(len(names_buffer), ALIGN_TABLE)
        + align(len(extensions_buffer), ALIGN_TABLE)
        + uncompressed_data_size
    )

    # PackageHeader is 384 bytes, followed by padding to 2048 bytes.
    header = bytearray(HEADER_SIZE)

    struct.pack_into("<I", header, 0x00, MAGIC)
    struct.pack_into("<I", header, 0x04, VERSION)
    struct.pack_into("<I", header, 0x14C, 2)  # preload flag used by original builder
    struct.pack_into("<i", header, 0x154, len(entries))
    struct.pack_into("<i", header, 0x158, package_size)
    struct.pack_into("<i", header, 0x15C, len(index_buffer))
    struct.pack_into("<i", header, 0x160, len(names_buffer))
    struct.pack_into("<i", header, 0x164, len(extensions_buffer))
    struct.pack_into("<i", header, 0x168, uncompressed_data_size)
    struct.pack_into("<I", header, 0x16C, 0xFFFFFFFF)

    temporary = output.with_suffix(output.suffix + ".tmp")

    try:
        with temporary.open("wb") as stream:
            write_aligned(stream, header, ALIGN_TABLE)
            write_aligned(stream, bytes(index_buffer), ALIGN_TABLE)
            write_aligned(stream, bytes(names_buffer), ALIGN_TABLE)
            write_aligned(stream, bytes(extensions_buffer), ALIGN_TABLE)
            for entry, source in zip(entries, file_sources):
                log(f"Writing: {source}")

                remaining = entry.uncompressed_size

                with source.open("rb") as input_stream:
                    while remaining:
                        chunk = input_stream.read(
                            min(1024 * 1024, remaining)
                        )

                        if not chunk:
                            raise IOError(
                                f"File changed while building package: {source}"
                            )

                        stream.write(chunk)
                        remaining -= len(chunk)

                padding = (
                    align(entry.uncompressed_size, ALIGN_DATA)
                    - entry.uncompressed_size
                )

                if padding:
                    stream.write(b"\x00" * padding)


        temporary.replace(output)

    except Exception:
        if temporary.exists():
            temporary.unlink()
        raise

    log(f"Created: {output}")
    log(f"Entries: {len(entries)}")
    log(f"Package size: {package_size:,} bytes")


def read_package(path: Path) -> tuple[dict, list[Entry]]:
    with path.open("rb") as stream:
        header_data = read_aligned(stream, HEADER_SIZE, ALIGN_TABLE)

        magic, version = struct.unpack_from("<II", header_data, 0)

        big_endian = False

        if magic == 0xCE0A8951:
            big_endian = True
            endian = ">"
            magic, version = struct.unpack_from(">II", header_data, 0)
        elif magic != MAGIC:
            raise ValueError("The file is not a recognized VPP_PC package.")
        else:
            endian = "<"

        if version != VERSION:
            raise ValueError(f"Unsupported VPP_PC version: {version}")

        flags = struct.unpack_from(f"{endian}I", header_data, 0x14C)[0]
        index_count = struct.unpack_from(f"{endian}i", header_data, 0x154)[0]
        package_size = struct.unpack_from(f"{endian}i", header_data, 0x158)[0]
        index_size = struct.unpack_from(f"{endian}i", header_data, 0x15C)[0]
        names_size = struct.unpack_from(f"{endian}i", header_data, 0x160)[0]
        extensions_size = struct.unpack_from(f"{endian}i", header_data, 0x164)[0]

        if index_count < 0 or index_size < 0:
            raise ValueError("Invalid VPP_PC index values.")

        if index_size != index_count * INDEX_ENTRY_SIZE:
            raise ValueError(
                f"Invalid index size: {index_size}; "
                f"expected {index_count * INDEX_ENTRY_SIZE}."
            )

        index_data = read_aligned(stream, index_size, ALIGN_TABLE)
        names_data = read_aligned(stream, names_size, ALIGN_TABLE)
        extensions_data = read_aligned(stream, extensions_size, ALIGN_TABLE)

        data_base = stream.tell()
        entries: list[Entry] = []
        compressed = (flags & 1) == 1
        compressed_base = data_base

        for i in range(index_count):
            offset = i * INDEX_ENTRY_SIZE

            values = struct.unpack_from(
                f"{endian}iiIiiiI",
                index_data,
                offset
            )

            (
                name_offset,
                extension_offset,
                unknown08,
                entry_offset,
                uncompressed_size,
                compressed_size,
                unknown1c,
            ) = values

            if compressed:
                if compressed_size < 0:
                    raise ValueError("Compressed entry has an invalid size.")

                actual_offset = compressed_base
                compressed_base += align(compressed_size, ALIGN_TABLE)
            else:
                actual_offset = data_base + entry_offset

            name = c_string(names_data, name_offset)
            extension = c_string(extensions_data, extension_offset)

            entries.append(
                Entry(
                    name=name,
                    extension=extension,
                    offset=actual_offset,
                    uncompressed_size=uncompressed_size,
                    unknown08=unknown08,
                    compressed_size=compressed_size,
                    unknown1c=unknown1c,
                )
            )

    metadata = {
        "version": version,
        "flags": flags,
        "index_count": index_count,
        "package_size": package_size,
        "compressed": compressed,
        "data_base": data_base,
        "big_endian": big_endian,
    }

    return metadata, entries


def extract_package(path: Path, destination: Path, log) -> None:
    metadata, entries = read_package(path)

    if metadata["compressed"]:
        raise NotImplementedError(
            "This program can read compressed package metadata, "
            "but zlib/Xbox compressed entry extraction is not implemented."
        )

    destination.mkdir(parents=True, exist_ok=True)

    with path.open("rb") as stream:
        for entry in entries:
            if entry.uncompressed_size < 0:
                raise ValueError(f"Invalid size for {entry.filename}")

            stream.seek(entry.offset)
            data = read_exact(stream, entry.uncompressed_size)

            output = destination / entry.filename
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(data)

            log(f"Extracted: {output}")

    log(f"Extracted {len(entries)} files to {destination}")


class App:
    def __init__(self, root: Tk):
        self.root = root
        self.root.title("Saints Row VPP_PC Builder")
        self.root.geometry("900x600")
        self.root.configure(bg=BG)

        self.output_var = StringVar()
        self.package_var = StringVar()
        self.recursive_var = BooleanVar(value=True)

        self.input_directories: list[Path] = []

        self.configure_styles()
        self.create_menu()
        self.create_widgets()

    def configure_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        style.configure(
            "TFrame",
            background=BG
        )
        style.configure(
            "TLabel",
            background=BG,
            foreground=FG
        )
        style.configure(
            "TButton",
            background=PURPLE,
            foreground=FG,
            padding=6
        )
        style.map(
            "TButton",
            background=[("active", PURPLE_ACTIVE)]
        )
        style.configure(
            "TCheckbutton",
            background=BG,
            foreground=FG
        )
        style.map(
            "TCheckbutton",
            background=[("active", BG)],
            foreground=[("active", FG)]
        )

    def create_menu(self):
        menu = ttk.Frame(self.root)
        menu.pack(fill="x", padx=8, pady=8)

        ttk.Button(menu, text="Help", command=self.show_help).pack(
            side="left", padx=4
        )
        ttk.Button(menu, text="Tutorial", command=self.show_tutorial).pack(
            side="left", padx=4
        )
        ttk.Button(menu, text="Acknowledgements",
                   command=self.show_acknowledgements).pack(
            side="left", padx=4
        )
        ttk.Button(menu, text="Errors",
                   command=self.show_errors).pack(
            side="left", padx=4
        )

    def create_widgets(self):
        main = ttk.Frame(self.root)
        main.pack(fill="both", expand=True, padx=10, pady=5)

        ttk.Label(main, text="Input directories").pack(anchor="w")

        directory_frame = ttk.Frame(main)
        directory_frame.pack(fill="x")

        self.directory_list = Listbox(
            directory_frame,
            height=6,
            bg=BG,
            fg=FG,
            selectbackground=PURPLE,
            selectforeground=FG,
            highlightbackground=PURPLE,
            highlightcolor=PURPLE
        )
        self.directory_list.pack(side="left", fill="both", expand=True)

        buttons = ttk.Frame(directory_frame)
        buttons.pack(side="right", padx=8)

        ttk.Button(
            buttons,
            text="Add directory",
            command=self.add_directory
        ).pack(fill="x", pady=2)

        ttk.Button(
            buttons,
            text="Remove selected",
            command=self.remove_directory
        ).pack(fill="x", pady=2)

        ttk.Button(
            buttons,
            text="Clear",
            command=self.clear_directories
        ).pack(fill="x", pady=2)

        ttk.Checkbutton(
            main,
            text="Scan subdirectories recursively",
            variable=self.recursive_var
        ).pack(anchor="w", pady=5)

        ttk.Label(main, text="Output VPP_PC file").pack(anchor="w")

        output_frame = ttk.Frame(main)
        output_frame.pack(fill="x")

        ttk.Entry(
            output_frame,
            textvariable=self.output_var
        ).pack(side="left", fill="x", expand=True)

        ttk.Button(
            output_frame,
            text="Browse",
            command=self.choose_output
        ).pack(side="right", padx=5)

        operation_frame = ttk.Frame(main)
        operation_frame.pack(fill="x", pady=10)

        ttk.Button(
            operation_frame,
            text="Build VPP_PC",
            command=self.start_build
        ).pack(side="left", padx=4)

        ttk.Label(main, text="Package to inspect or extract").pack(anchor="w")

        package_frame = ttk.Frame(main)
        package_frame.pack(fill="x")

        ttk.Entry(
            package_frame,
            textvariable=self.package_var
        ).pack(side="left", fill="x", expand=True)

        ttk.Button(
            package_frame,
            text="Browse",
            command=self.choose_package
        ).pack(side="right", padx=5)

        ttk.Button(
            operation_frame,
            text="Inspect",
            command=self.inspect
        ).pack(side="left", padx=4)

        ttk.Button(
            operation_frame,
            text="Extract",
            command=self.extract
        ).pack(side="left", padx=4)

        ttk.Label(main, text="Log").pack(anchor="w")

        self.log_box = Text(
            main,
            bg=BG,
            fg=FG,
            insertbackground=FG,
            selectbackground=PURPLE,
            selectforeground=FG,
            highlightbackground=PURPLE,
            wrap="word"
        )
        self.log_box.pack(fill="both", expand=True)

    def log(self, message: str):
        self.root.after(
            0,
            lambda: (
                self.log_box.insert(END, message + "\n"),
                self.log_box.see(END)
            )
        )

    def add_directory(self):
        selected = filedialog.askdirectory()
        if not selected:
            return

        path = Path(selected)

        if path not in self.input_directories:
            self.input_directories.append(path)
            self.directory_list.insert(END, str(path))

    def remove_directory(self):
        selected = list(self.directory_list.curselection())

        for index in reversed(selected):
            self.directory_list.delete(index)
            del self.input_directories[index]

    def clear_directories(self):
        self.input_directories.clear()
        self.directory_list.delete(0, END)

    def choose_output(self):
        selected = filedialog.asksaveasfilename(
            defaultextension=".vpp_pc",
            filetypes=[("VPP_PC files", "*.vpp_pc"), ("All files", "*.*")]
        )

        if selected:
            self.output_var.set(selected)

    def choose_package(self):
        selected = filedialog.askopenfilename(
            filetypes=[("VPP_PC files", "*.vpp_pc"), ("All files", "*.*")]
        )

        if selected:
            self.package_var.set(selected)

    def start_build(self):
        if not self.input_directories:
            messagebox.showerror("Build error", "Add at least one input directory.")
            return

        if not self.output_var.get():
            messagebox.showerror("Build error", "Choose an output package.")
            return

        output = Path(self.output_var.get())
        directories = list(self.input_directories)
        recursive = self.recursive_var.get()

        threading.Thread(
            target=self.run_build,
            args=(output, directories, recursive),
            daemon=True
        ).start()

    def run_build(self, output, directories, recursive):
        try:
            build_package(output, directories, recursive, self.log)
            self.root.after(
                0,
                lambda: messagebox.showinfo(
                    "Build complete",
                    f"Created:\n{output}"
                )
            )
        except Exception as error:
            self.log(traceback.format_exc())
            self.root.after(
                0,
                lambda: messagebox.showerror("Build error", str(error))
            )

    def inspect(self):
        if not self.package_var.get():
            messagebox.showerror("Inspect error", "Choose a VPP_PC file.")
            return

        try:
            metadata, entries = read_package(Path(self.package_var.get()))

            text = (
                f"Version: {metadata['version']}\n"
                f"Flags: {metadata['flags']}\n"
                f"Entries: {metadata['index_count']}\n"
                f"Package size: {metadata['package_size']:,}\n"
                f"Compressed: {metadata['compressed']}\n\n"
            )

            for entry in entries:
                text += (
                    f"{entry.filename} | "
                    f"offset={entry.offset} | "
                    f"size={entry.uncompressed_size}\n"
                )

            self.show_text("Package contents", text)

        except Exception as error:
            messagebox.showerror("Inspect error", str(error))

    def extract(self):
        if not self.package_var.get():
            messagebox.showerror("Extract error", "Choose a VPP_PC file.")
            return

        destination = filedialog.askdirectory(
            title="Select extraction directory"
        )

        if not destination:
            return

        package = Path(self.package_var.get())

        threading.Thread(
            target=self.run_extract,
            args=(package, Path(destination)),
            daemon=True
        ).start()

    def run_extract(self, package, destination):
        try:
            extract_package(package, destination, self.log)
            self.root.after(
                0,
                lambda: messagebox.showinfo(
                    "Extraction complete",
                    f"Extracted files to:\n{destination}"
                )
            )
        except Exception as error:
            self.log(traceback.format_exc())
            self.root.after(
                0,
                lambda: messagebox.showerror("Extraction error", str(error))
            )

    def show_text(self, title: str, content: str):
        window = Toplevel(self.root)
        window.title(title)
        window.geometry("850x600")
        window.configure(bg=BG)

        text = Text(
            window,
            bg=BG,
            fg=FG,
            insertbackground=FG,
            selectbackground=PURPLE,
            selectforeground=FG,
            wrap="word"
        )
        text.pack(fill="both", expand=True, padx=10, pady=10)
        text.insert("1.0", content)
        text.configure(state="disabled")

    def show_help(self):
        self.show_text(
            "Help",
            """Saints Row VPP_PC Tool

Build VPP_PC:
1. Add one or more input directories.
2. Choose an output .vpp_pc filename.
3. Enable recursive scanning if required.
4. Click Build VPP_PC.

Inspect:
Choose a package and click Inspect to display its header and entries.

Extract:
Choose a package, click Extract, and select an output directory.

Important:
VPP_PC entries store a filename stem and extension separately.
Two files with the same filename are treated as duplicates.
The first occurrence is retained.
"""
        )

    def show_tutorial(self):
        self.show_text(
            "Tutorial",
            """Basic Saints Row VPP_PC workflow

1. Extract an original VPP_PC archive into a working directory.
2. Copy the files you want to modify into a separate mod directory.
3. Edit those files without changing their filenames.
4. Add the mod directory to this program.
5. Build a new VPP_PC archive.
6. Back up the original game archive.
7. Install the rebuilt archive according to your Saints Row modding setup.
8. Test the game and restore the backup if necessary.

Do not place the output package inside an input directory.
Avoid duplicate filenames across input directories.
"""
        )

    def show_errors(self):
        self.show_text(
            "Errors and meanings",
            """The file is not a recognized VPP_PC package
The magic value at the beginning of the file is invalid.

Unsupported VPP_PC version
The package version is not version 4.

Invalid index size
The index size does not equal entry count multiplied by 28.

Unexpected end of file
The package is truncated or damaged.

Invalid string-table offset
An index entry points outside the names or extensions table.

No files were found
The selected input directories contain no usable files.

Duplicate skipped
Another input directory already supplied a file with the same filename.

Compressed extraction is not implemented
The package uses the compressed/Xbox-style layout. This builder creates
uncompressed Saints Row VPP_PC packages, matching the original builder.
"""
        )

    def show_acknowledgements(self):
        self.show_text(
            "Acknowledgements",
            """This project is an independent Python rewrite based on the
Saints Row VPP_PC format handling present in the original source.

Acknowledgement to Rick Gibbed for the use and study of his
GibbedTools source code.

Thanks to Thomas Jepp for JeppTools.

The original Gibbed source was released under a permissive license.
Retain the original license and attribution when redistributing derived work.
"""
        )


def main():
    root = Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
